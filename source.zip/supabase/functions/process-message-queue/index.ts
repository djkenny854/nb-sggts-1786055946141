
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('🔄 process-message-queue function invoked');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    // Recover stuck 'processing' items older than 5 minutes
    const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString()
    await supabase
      .from('message_queue')
      .update({ 
        status: 'queued', 
        updated_at: new Date().toISOString(), 
        error_message: 'Recovered from stuck processing' 
      })
      .eq('status', 'processing')
      .lt('updated_at', fiveMinAgo)

    // Get messages from queue that are ready to be processed
    const { data: queueItems, error: queueError } = await supabase
      .from('message_queue')
      .select('*')
      .eq('status', 'queued')
      .or(`scheduled_at.is.null,scheduled_at.lte.${new Date().toISOString()}`)
      .lt('attempt_count', 3)
      .order('scheduled_at', { ascending: true })
      .limit(10)

    if (queueError) throw queueError

    console.log(`📦 Found ${queueItems?.length || 0} messages to process`);

    const results = []

    for (const item of queueItems || []) {
      console.log(`📨 Processing message ${item.id} via ${item.channel} to ${item.recipient_contact}`);
      try {
        // Update status to processing
        await supabase
          .from('message_queue')
          .update({
            status: 'processing',
            attempt_count: item.attempt_count + 1,
            updated_at: new Date().toISOString()
          })
          .eq('id', item.id)

        let response
        const baseUrl = Deno.env.get('SUPABASE_URL')

        // Ensure branding for all non-email channels
        const contentWithBrand = `${item.message_content}\n\n— Powered by ClassPilot`;

        // Send message based on channel
        switch (item.channel) {
          case 'sms':
            response = await supabase.functions.invoke('send-sms', {
              body: {
                to: item.recipient_contact,
                message: contentWithBrand,
              }
            })
            break

          case 'email':
            response = await supabase.functions.invoke('send-email', {
              body: {
                to: item.recipient_contact,
                subject: item.subject || 'School Notification',
                message: item.message_content, // HTML function already includes ClassPilot footer
              }
            })
            break

          case 'whatsapp':
            // Ensure phone number is in international format (add + if missing)
            let phoneNumber = item.recipient_contact.trim()
            if (!phoneNumber.startsWith('+')) {
              phoneNumber = '+' + phoneNumber
            }
            
            response = await supabase.functions.invoke('send-whatsapp', {
              body: {
                to: phoneNumber,
                message: contentWithBrand,
              }
            })
            break

          default:
            throw new Error(`Unknown channel: ${item.channel}`)
        }

        const result = response.data
        const isSuccess = !response.error && (result?.success !== false)

        if (isSuccess) {
          console.log(`✅ Message ${item.id} sent successfully`);
          
          // Update queue item as sent
          await supabase
            .from('message_queue')
            .update({
              status: 'sent',
              processed_at: new Date().toISOString(),
              provider_response: result,
              updated_at: new Date().toISOString()
            })
            .eq('id', item.id)

          // Create message log (using type assertion until types update)
          await (supabase as any)
            .from('message_logs')
            .insert({
              message_id: item.message_id,
              recipient_id: item.message_id, // Using message_id as recipient_id for now
              recipient_contact: item.recipient_contact,
              channel: item.channel,
              status: 'sent',
              provider_response: result || {},
              delivery_time: new Date().toISOString(),
              cost_amount: 0.1, // Default cost
            })

          results.push({ id: item.id, status: 'sent', success: true })
        } else {
          throw new Error(response.error?.message || result?.error || 'Failed to send message')
        }

      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error'
        console.error(`❌ Failed to send message ${item.id}:`, errorMessage);
        
        // Update queue item as failed
        await supabase
          .from('message_queue')
          .update({
            status: item.attempt_count + 1 >= 3 ? 'failed' : 'queued',
            error_message: errorMessage,
            updated_at: new Date().toISOString()
          })
          .eq('id', item.id)

        // Create message log for failed attempt (using type assertion)
        await (supabase as any)
          .from('message_logs')
          .insert({
            message_id: item.message_id,
            recipient_id: item.message_id,
            recipient_contact: item.recipient_contact,
            channel: item.channel,
            status: 'failed',
            error_message: errorMessage,
            cost_amount: 0,
          })

        results.push({ id: item.id, status: 'failed', error: error instanceof Error ? error.message : 'Unknown error' })
      }
    }

    console.log(`✅ Processing complete. Processed ${results.length} messages`);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        processed: results.length,
        results 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('❌ Error in process-message-queue:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400
      }
    )
  }
})
