
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { prompt, type, category } = await req.json();
    const openrouterApiKey = Deno.env.get('OPENROUTER_API_KEY');

    if (!openrouterApiKey) {
      throw new Error('OpenRouter API key not configured');
    }

    // Create system prompt based on type and category
    let systemPrompt = 'You are an AI assistant that helps generate professional school communication messages.';
    
    if (type === 'subject') {
      systemPrompt = 'Generate concise, professional subject lines for school communications. Keep them under 50 characters and include relevant variables in {{variable_name}} format when appropriate.';
    } else if (type === 'content') {
      systemPrompt = 'Generate professional, clear, and friendly school communication content. Use appropriate variables in {{variable_name}} format like {{parent_name}}, {{student_name}}, {{amount}}, {{date}} etc. Keep the tone respectful and informative.';
    }

    // Add category-specific context
    if (category === 'fee_reminder') {
      systemPrompt += ' Focus on fee payment reminders with a polite but urgent tone.';
    } else if (category === 'attendance_alert') {
      systemPrompt += ' Focus on attendance notifications with concern for student safety.';
    } else if (category === 'exam_result') {
      systemPrompt += ' Focus on exam results communication with encouraging tone.';
    } else if (category === 'event_reminder') {
      systemPrompt += ' Focus on event reminders with excitement and clear details.';
    }

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openrouterApiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://nwaeyguvhidayxctdvpy.supabase.co',
        'X-Title': 'ClassPilot School Management System',
      },
      body: JSON.stringify({
        model: 'google/gemma-3n-e4b-it:free',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt }
        ],
        max_tokens: type === 'subject' ? 100 : 500,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('OpenRouter API error:', errorData);
      throw new Error(`OpenRouter API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedText = data.choices[0].message.content;

    return new Response(JSON.stringify({ 
      generatedText: generatedText.trim(),
      success: true 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in generate-ai-message function:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error occurred',
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
