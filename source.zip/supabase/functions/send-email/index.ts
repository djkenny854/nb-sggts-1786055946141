
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    const { to, subject, message, from } = await req.json()
    
    console.log('📧 send-email function invoked for:', to)

    // Get SendGrid settings from database
    const { data: settings } = await supabase
      .from('communication_settings')
      .select('*')
      .eq('setting_type', 'email_provider')
      .eq('is_active', true)
      .single()

    if (!settings) {
      console.error('❌ Email provider not configured')
      throw new Error('Email provider not configured')
    }

    const config = settings.configuration
    const apiKey = config.api_key
    const senderEmail = config.sender_email || from
    const senderName = config.sender_name || 'School'
    
    console.log('✅ Email settings loaded, sending via SendGrid...')

    // Send email using SendGrid
    const sendGridResponse = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [
          {
            to: [{ email: to }],
            subject: subject,
          },
        ],
        from: {
          email: senderEmail,
          name: senderName,
        },
        content: [
          {
            type: 'text/html',
            value: `
              <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2563eb; border-bottom: 2px solid #2563eb; padding-bottom: 10px;">
                  ${subject}
                </h2>
                <div style="margin-top: 20px; white-space: pre-wrap;">
                  ${message.replace(/\n/g, '<br>')}
                </div>
                <hr style="margin: 30px 0; border: none; border-top: 1px solid #e5e7eb;">
                <p style="font-size: 12px; color: #6b7280;">
                  This is an automated message from ${senderName}. Please do not reply to this email.
                </p>
                
                <!-- ClassPilot Branding -->
                <div style="text-align: center; margin-top: 30px; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px;">
                  <p style="margin: 0; color: #ffffff; font-size: 14px; font-weight: 600;">
                    ⚡ Powered by <span style="font-size: 16px; letter-spacing: 1px;">ClassPilot</span>
                  </p>
                  <p style="margin: 5px 0 0 0; color: #e0e7ff; font-size: 11px;">
                    Smart School Management System
                  </p>
                </div>
              </div>
            `
          },
          {
            type: 'text/plain',
            value: message,
          },
        ],
      }),
    })

    if (sendGridResponse.ok) {
      const messageId = sendGridResponse.headers.get('X-Message-Id');
      console.log('✅ Email sent successfully, Message ID:', messageId);
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          messageId,
          status: 'sent' 
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    } else {
      const error = await sendGridResponse.json()
      console.error('❌ SendGrid error:', error);
      throw new Error(error.errors?.[0]?.message || 'Failed to send email')
    }

  } catch (error) {
    console.error('❌ Error in send-email function:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400
      }
    )
  }
})
