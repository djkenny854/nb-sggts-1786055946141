
-- Ensure student_fees table has proper RLS policies
DROP POLICY IF EXISTS "Allow all operations on student_fees" ON student_fees;

-- Create comprehensive RLS policies for student_fees
CREATE POLICY "student_fees_select_policy" 
ON student_fees FOR SELECT 
USING (true);

CREATE POLICY "student_fees_insert_policy" 
ON student_fees FOR INSERT 
WITH CHECK (true);

CREATE POLICY "student_fees_update_policy" 
ON student_fees FOR UPDATE 
USING (true);

CREATE POLICY "student_fees_delete_policy" 
ON student_fees FOR DELETE 
USING (true);

-- Ensure RLS is enabled
ALTER TABLE student_fees ENABLE ROW LEVEL SECURITY;

-- Add index for better performance on common queries
CREATE INDEX IF NOT EXISTS idx_student_fees_student_academic 
ON student_fees(student_id, academic_year, academic_term);

CREATE INDEX IF NOT EXISTS idx_student_fees_structure 
ON student_fees(fee_structure_id);

-- Ensure balance column is properly updated when not provided
ALTER TABLE student_fees 
ALTER COLUMN balance SET DEFAULT 0;

-- Add trigger to automatically calculate balance
CREATE OR REPLACE FUNCTION calculate_student_fee_balance()
RETURNS TRIGGER AS $$
BEGIN
  -- Automatically calculate balance if not provided
  IF NEW.balance IS NULL THEN
    NEW.balance = NEW.total_assigned_fees - NEW.total_paid;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_calculate_balance ON student_fees;
CREATE TRIGGER trigger_calculate_balance
  BEFORE INSERT OR UPDATE ON student_fees
  FOR EACH ROW
  EXECUTE FUNCTION calculate_student_fee_balance();
