
-- Fix student balance tracking by ensuring proper triggers and data consistency

-- Create a trigger to automatically create student_fees record when student is created
CREATE OR REPLACE FUNCTION create_student_fees_record()
RETURNS TRIGGER AS $$
DECLARE
  current_year TEXT := EXTRACT(YEAR FROM NOW())::TEXT;
  current_term TEXT := 'Term 1';
  fee_amount NUMERIC := 0;
BEGIN
  -- Calculate fees based on student status
  -- Base day student fee (you can adjust these amounts)
  fee_amount := 500000; -- Base tuition
  
  -- Add boarding fee if applicable
  IF NEW.boarding_status = 'Boarding' THEN
    fee_amount := fee_amount + 300000;
  END IF;
  
  -- Add transport fee if applicable  
  IF NEW.transport = 'Yes' THEN
    fee_amount := fee_amount + 50000;
  END IF;
  
  -- Add activity fees
  fee_amount := fee_amount + 25000;
  
  -- Create student_fees record
  INSERT INTO student_fees (
    student_id,
    total_assigned_fees,
    total_paid,
    balance,
    academic_year,
    academic_term,
    payment_status
  ) VALUES (
    NEW.id,
    fee_amount,
    0,
    fee_amount,
    current_year,
    current_term,
    'Unpaid'
  ) ON CONFLICT (student_id, academic_year, academic_term) 
  DO UPDATE SET
    total_assigned_fees = fee_amount,
    balance = fee_amount - student_fees.total_paid,
    updated_at = NOW();
    
  -- Update student fee_status
  UPDATE students 
  SET fee_status = 'Unpaid'
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new students
DROP TRIGGER IF EXISTS trigger_create_student_fees ON students;
CREATE TRIGGER trigger_create_student_fees
  AFTER INSERT ON students
  FOR EACH ROW
  EXECUTE FUNCTION create_student_fees_record();

-- Create function to update student fees when payment is made
CREATE OR REPLACE FUNCTION update_student_fees_on_transaction()
RETURNS TRIGGER AS $$
BEGIN
  -- Update student_fees table with new totals
  UPDATE student_fees 
  SET 
    total_paid = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_id = NEW.student_id 
      AND academic_year = NEW.academic_year 
      AND academic_term = NEW.academic_term
      AND status = 'completed'
    ),
    balance = total_assigned_fees - (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_id = NEW.student_id 
      AND academic_year = NEW.academic_year 
      AND academic_term = NEW.academic_term
      AND status = 'completed'
    ),
    payment_status = CASE 
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_id = NEW.student_id 
        AND academic_year = NEW.academic_year 
        AND academic_term = NEW.academic_term
        AND status = 'completed'
      ) >= total_assigned_fees THEN 'Paid'
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_id = NEW.student_id 
        AND academic_year = NEW.academic_year 
        AND academic_term = NEW.academic_term
        AND status = 'completed'
      ) > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    updated_at = NOW()
  WHERE student_id = NEW.student_id 
  AND academic_year = NEW.academic_year 
  AND academic_term = NEW.academic_term;
  
  -- Update student fee_status for quick reference
  UPDATE students 
  SET fee_status = (
    SELECT payment_status 
    FROM student_fees 
    WHERE student_id = NEW.student_id 
    AND academic_year = NEW.academic_year 
    AND academic_term = NEW.academic_term
    LIMIT 1
  )
  WHERE id = NEW.student_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for fee transactions
DROP TRIGGER IF EXISTS trigger_update_student_fees_transaction ON fee_transactions;
CREATE TRIGGER trigger_update_student_fees_transaction
  AFTER INSERT OR UPDATE ON fee_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_student_fees_on_transaction();

-- Backfill existing students with fee records
INSERT INTO student_fees (
  student_id,
  total_assigned_fees, 
  total_paid,
  balance,
  academic_year,
  academic_term,
  payment_status
)
SELECT 
  s.id,
  CASE 
    WHEN s.boarding_status = 'Boarding' AND s.transport = 'Yes' THEN 875000
    WHEN s.boarding_status = 'Boarding' AND s.transport = 'No' THEN 825000  
    WHEN s.boarding_status = 'Day' AND s.transport = 'Yes' THEN 575000
    ELSE 525000
  END as total_fees,
  0 as total_paid,
  CASE 
    WHEN s.boarding_status = 'Boarding' AND s.transport = 'Yes' THEN 875000
    WHEN s.boarding_status = 'Boarding' AND s.transport = 'No' THEN 825000
    WHEN s.boarding_status = 'Day' AND s.transport = 'Yes' THEN 575000  
    ELSE 525000
  END as balance,
  EXTRACT(YEAR FROM NOW())::TEXT as academic_year,
  'Term 1' as academic_term,
  'Unpaid' as payment_status
FROM students s
WHERE NOT EXISTS (
  SELECT 1 FROM student_fees sf 
  WHERE sf.student_id = s.id 
  AND sf.academic_year = EXTRACT(YEAR FROM NOW())::TEXT 
  AND sf.academic_term = 'Term 1'
);
