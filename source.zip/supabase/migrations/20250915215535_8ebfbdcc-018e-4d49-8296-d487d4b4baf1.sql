-- Create assessment types enum
CREATE TYPE assessment_type AS ENUM ('exam', 'assignment', 'test', 'quiz', 'project', 'presentation', 'practical', 'homework', 'classwork', 'other');

-- Create assessment categories table
CREATE TABLE public.assessment_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  weight NUMERIC DEFAULT 1.0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create assessments table
CREATE TABLE public.assessments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  subject_id UUID REFERENCES enhanced_subjects(id),
  class_name TEXT NOT NULL,
  assessment_type assessment_type NOT NULL,
  category_id UUID REFERENCES assessment_categories(id),
  total_marks NUMERIC NOT NULL DEFAULT 100,
  due_date DATE,
  assessment_date DATE NOT NULL,
  is_published BOOLEAN DEFAULT false,
  instructions TEXT,
  created_by TEXT,
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create assessment grades table
CREATE TABLE public.assessment_grades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  marks_obtained NUMERIC NOT NULL DEFAULT 0,
  total_marks NUMERIC NOT NULL,
  percentage NUMERIC NOT NULL DEFAULT 0,
  grade TEXT,
  teacher_comment TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE,
  graded_at TIMESTAMP WITH TIME ZONE,
  graded_by TEXT,
  is_absent BOOLEAN DEFAULT false,
  late_submission BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(assessment_id, student_id)
);

-- Create continuous assessment summary table
CREATE TABLE public.student_assessment_summary (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES enhanced_subjects(id) ON DELETE CASCADE,
  class_name TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  total_assessments INTEGER DEFAULT 0,
  completed_assessments INTEGER DEFAULT 0,
  average_percentage NUMERIC DEFAULT 0,
  current_grade TEXT,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(student_id, subject_id, academic_year, academic_term)
);

-- Enable RLS
ALTER TABLE public.assessment_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessment_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_assessment_summary ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow all operations on assessment_categories" ON public.assessment_categories FOR ALL USING (true);
CREATE POLICY "Allow all operations on assessments" ON public.assessments FOR ALL USING (true);
CREATE POLICY "Allow all operations on assessment_grades" ON public.assessment_grades FOR ALL USING (true);
CREATE POLICY "Allow all operations on student_assessment_summary" ON public.student_assessment_summary FOR ALL USING (true);

-- Create update triggers
CREATE TRIGGER update_assessment_categories_updated_at
    BEFORE UPDATE ON public.assessment_categories
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_assessments_updated_at
    BEFORE UPDATE ON public.assessments
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_assessment_grades_updated_at
    BEFORE UPDATE ON public.assessment_grades
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_student_assessment_summary_updated_at
    BEFORE UPDATE ON public.student_assessment_summary
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default assessment categories
INSERT INTO public.assessment_categories (name, description, weight) VALUES
  ('Continuous Assessment', 'Regular assessments throughout the term', 0.4),
  ('Mid-term Exams', 'Mid-term examinations', 0.3),
  ('Final Exams', 'End of term examinations', 0.3),
  ('Projects', 'Long-term projects and assignments', 0.2),
  ('Participation', 'Class participation and engagement', 0.1);

-- Create function to calculate percentage and update summary
CREATE OR REPLACE FUNCTION calculate_assessment_percentage()
RETURNS TRIGGER AS $$
BEGIN
  -- Calculate percentage for the grade
  IF NEW.total_marks > 0 THEN
    NEW.percentage := (NEW.marks_obtained / NEW.total_marks) * 100;
  ELSE
    NEW.percentage := 0;
  END IF;
  
  -- Calculate grade based on percentage
  IF NEW.percentage >= 80 THEN
    NEW.grade := 'A';
  ELSIF NEW.percentage >= 70 THEN
    NEW.grade := 'B';
  ELSIF NEW.percentage >= 60 THEN
    NEW.grade := 'C';
  ELSIF NEW.percentage >= 50 THEN
    NEW.grade := 'D';
  ELSE
    NEW.grade := 'F';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-calculate percentage and grade
CREATE TRIGGER calculate_assessment_percentage_trigger
  BEFORE INSERT OR UPDATE ON assessment_grades
  FOR EACH ROW
  EXECUTE FUNCTION calculate_assessment_percentage();