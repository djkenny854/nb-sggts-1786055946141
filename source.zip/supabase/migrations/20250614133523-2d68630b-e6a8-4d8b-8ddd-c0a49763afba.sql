
-- Drop the existing insert policies restricted to authenticated users
DROP POLICY IF EXISTS exams_insert_policy ON public.exams;
DROP POLICY IF EXISTS exam_results_insert_policy ON public.exam_results;

-- Recreate the policies to allow public inserts for exams
CREATE POLICY exams_insert_policy ON public.exams
  FOR INSERT TO public
  WITH CHECK (true);

-- Recreate the policies to allow public inserts for exam results
CREATE POLICY exam_results_insert_policy ON public.exam_results
  FOR INSERT TO public
  WITH CHECK (true);
