-- Create message_queue table for processing messages
CREATE TABLE IF NOT EXISTS public.message_queue (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  channel TEXT NOT NULL CHECK (channel IN ('sms', 'email', 'whatsapp')),
  recipient_contact TEXT NOT NULL,
  message_content TEXT NOT NULL,
  subject TEXT,
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'sent', 'failed')),
  scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  attempt_count INTEGER DEFAULT 0,
  provider_response JSONB DEFAULT '{}'::jsonb,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_message_queue_status ON public.message_queue(status);
CREATE INDEX IF NOT EXISTS idx_message_queue_scheduled ON public.message_queue(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_message_queue_message_id ON public.message_queue(message_id);

-- Enable RLS
ALTER TABLE public.message_queue ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view message queue"
  ON public.message_queue FOR SELECT
  USING (true);

CREATE POLICY "Users can insert into message queue"
  ON public.message_queue FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update message queue"
  ON public.message_queue FOR UPDATE
  USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_message_queue_updated_at
  BEFORE UPDATE ON public.message_queue
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();