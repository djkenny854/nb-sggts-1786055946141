
-- Drop existing conflicting tables to ensure a clean setup
DROP TABLE IF EXISTS exam_results;
DROP TABLE IF EXISTS exam_schedules;
DROP TABLE IF EXISTS exams;

-- Create the exams table
CREATE TABLE IF NOT EXISTS exams (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  term TEXT NOT NULL,
  year TEXT NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  is_active BOOLEAN DEFAULT false,
  grade_scale JSONB NOT NULL DEFAULT '{"A": {"min": 80, "max": 100, "comment": "Excellent"}, "B": {"min": 70, "max": 79, "comment": "Very Good"}, "C": {"min": 60, "max": 69, "comment": "Good"}, "D": {"min": 50, "max": 59, "comment": "Fair"}, "F": {"min": 0, "max": 49, "comment": "Poor"}}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ
);

-- Create the exam_results table
CREATE TABLE IF NOT EXISTS exam_results (
  id UUID PRIMARY KEY,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  student_name TEXT,
  exam_id UUID REFERENCES exams(id) ON DELETE CASCADE,
  exam_name TEXT,
  class_name TEXT,
  subject_results JSONB NOT NULL,
  total_marks NUMERIC NOT NULL,
  average_marks NUMERIC NOT NULL,
  grade TEXT NOT NULL,
  position INTEGER,
  comments TEXT,
  teacher TEXT,
  date_entered TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies
-- Everyone can select all data
CREATE POLICY exams_select_policy ON exams
  FOR SELECT USING (true);

CREATE POLICY exam_results_select_policy ON exam_results
  FOR SELECT USING (true);

-- Only authenticated users can modify data
CREATE POLICY exams_insert_policy ON exams
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY exams_update_policy ON exams
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY exams_delete_policy ON exams
  FOR DELETE TO authenticated USING (true);

CREATE POLICY exam_results_insert_policy ON exam_results
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY exam_results_update_policy ON exam_results
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY exam_results_delete_policy ON exam_results
  FOR DELETE TO authenticated USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS exams_name_idx ON exams(name);
CREATE INDEX IF NOT EXISTS exams_term_year_idx ON exams(term, year);
CREATE INDEX IF NOT EXISTS exam_results_student_idx ON exam_results(student_id);
CREATE INDEX IF NOT EXISTS exam_results_exam_idx ON exam_results(exam_id);

-- Create a trigger to update the updated_at timestamp for exams
CREATE OR REPLACE FUNCTION update_exams_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_exams_timestamp
BEFORE UPDATE ON exams
FOR EACH ROW
EXECUTE PROCEDURE update_exams_updated_at();
