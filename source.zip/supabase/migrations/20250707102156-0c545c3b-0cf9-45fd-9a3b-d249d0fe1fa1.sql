
-- Drop existing fee-related tables to start fresh
DROP TABLE IF EXISTS public.fee_transactions CASCADE;
DROP TABLE IF EXISTS public.student_fees CASCADE;
DROP TABLE IF EXISTS public.fee_structure_classes CASCADE;
DROP TABLE IF EXISTS public.fee_structures CASCADE;
DROP TABLE IF EXISTS public.student_balances CASCADE;
DROP TABLE IF EXISTS public.class_fee_mappings CASCADE;
DROP TABLE IF EXISTS public.student_fee_customizations CASCADE;
DROP TABLE IF EXISTS public.payments CASCADE;

-- Create a comprehensive fee structures table
CREATE TABLE public.fee_structures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  class_level TEXT, -- e.g., "Primary 1", "Secondary 2"
  boarding_status TEXT DEFAULT 'Both' CHECK (boarding_status IN ('Day', 'Boarding', 'Both')),
  
  -- Fee components
  tuition_fee DECIMAL(10,2) DEFAULT 0,
  boarding_fee DECIMAL(10,2) DEFAULT 0,
  transport_fee DECIMAL(10,2) DEFAULT 0,
  meals_fee DECIMAL(10,2) DEFAULT 0,
  activities_fee DECIMAL(10,2) DEFAULT 0,
  library_fee DECIMAL(10,2) DEFAULT 0,
  computer_fee DECIMAL(10,2) DEFAULT 0,
  laboratory_fee DECIMAL(10,2) DEFAULT 0,
  sports_fee DECIMAL(10,2) DEFAULT 0,
  medical_fee DECIMAL(10,2) DEFAULT 0,
  development_fee DECIMAL(10,2) DEFAULT 0,
  exam_fee DECIMAL(10,2) DEFAULT 0,
  uniform_fee DECIMAL(10,2) DEFAULT 0,
  miscellaneous_fee DECIMAL(10,2) DEFAULT 0,
  
  -- Academic period
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL CHECK (academic_term IN ('Term 1', 'Term 2', 'Term 3')),
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  is_default BOOLEAN DEFAULT false,
  
  -- Audit fields
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by TEXT,
  
  -- Ensure only one default per term/year
  UNIQUE(academic_year, academic_term, is_default) WHERE is_default = true
);

-- Create student fees table (individual student fee records)
CREATE TABLE public.student_fees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL,
  fee_structure_id UUID REFERENCES public.fee_structures(id) ON DELETE CASCADE,
  
  -- Override individual fees if needed
  tuition_fee DECIMAL(10,2) DEFAULT 0,
  boarding_fee DECIMAL(10,2) DEFAULT 0,
  transport_fee DECIMAL(10,2) DEFAULT 0,
  meals_fee DECIMAL(10,2) DEFAULT 0,
  activities_fee DECIMAL(10,2) DEFAULT 0,
  library_fee DECIMAL(10,2) DEFAULT 0,
  computer_fee DECIMAL(10,2) DEFAULT 0,
  laboratory_fee DECIMAL(10,2) DEFAULT 0,
  sports_fee DECIMAL(10,2) DEFAULT 0,
  medical_fee DECIMAL(10,2) DEFAULT 0,
  development_fee DECIMAL(10,2) DEFAULT 0,
  exam_fee DECIMAL(10,2) DEFAULT 0,
  uniform_fee DECIMAL(10,2) DEFAULT 0,
  miscellaneous_fee DECIMAL(10,2) DEFAULT 0,
  
  -- Totals
  total_fees DECIMAL(10,2) GENERATED ALWAYS AS (
    tuition_fee + boarding_fee + transport_fee + meals_fee + activities_fee + 
    library_fee + computer_fee + laboratory_fee + sports_fee + medical_fee + 
    development_fee + exam_fee + uniform_fee + miscellaneous_fee
  ) STORED,
  total_paid DECIMAL(10,2) DEFAULT 0,
  balance DECIMAL(10,2) GENERATED ALWAYS AS (
    tuition_fee + boarding_fee + transport_fee + meals_fee + activities_fee + 
    library_fee + computer_fee + laboratory_fee + sports_fee + medical_fee + 
    development_fee + exam_fee + uniform_fee + miscellaneous_fee - total_paid
  ) STORED,
  
  -- Academic period
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  
  -- Status
  payment_status TEXT GENERATED ALWAYS AS (
    CASE 
      WHEN total_paid >= (tuition_fee + boarding_fee + transport_fee + meals_fee + activities_fee + 
                         library_fee + computer_fee + laboratory_fee + sports_fee + medical_fee + 
                         development_fee + exam_fee + uniform_fee + miscellaneous_fee) THEN 'Paid'
      WHEN total_paid > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END
  ) STORED,
  
  -- Audit fields
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Unique constraint per student per term
  UNIQUE(student_id, academic_year, academic_term)
);

-- Create fee transactions table
CREATE TABLE public.fee_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL,
  student_fee_id UUID REFERENCES public.student_fees(id) ON DELETE CASCADE,
  
  -- Payment details
  amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
  payment_method TEXT NOT NULL CHECK (payment_method IN ('Cash', 'Bank Transfer', 'Mobile Money', 'Cheque', 'Card')),
  payment_date TIMESTAMPTZ DEFAULT NOW(),
  receipt_number TEXT,
  
  -- Fee breakdown (which fees this payment covers)
  fee_breakdown JSONB DEFAULT '{}',
  
  -- Reference information
  reference_number TEXT,
  notes TEXT,
  
  -- Academic period
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  
  -- Audit fields
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by TEXT,
  
  -- Indexes for performance
  INDEX idx_fee_transactions_student_id (student_id),
  INDEX idx_fee_transactions_payment_date (payment_date),
  INDEX idx_fee_transactions_academic_period (academic_year, academic_term)
);

-- Create fee structure class mappings
CREATE TABLE public.fee_structure_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fee_structure_id UUID REFERENCES public.fee_structures(id) ON DELETE CASCADE,
  class_name TEXT NOT NULL, -- Maps to students.class field
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(fee_structure_id, class_name)
);

-- Function to auto-assign fees when student is created or updated
CREATE OR REPLACE FUNCTION public.auto_assign_student_fees()
RETURNS TRIGGER AS $$
DECLARE
  fee_structure_record public.fee_structures%ROWTYPE;
  current_year TEXT := EXTRACT(YEAR FROM NOW())::TEXT;
  current_term TEXT := 'Term 1'; -- You can make this dynamic
BEGIN
  -- Find applicable fee structure
  SELECT * INTO fee_structure_record
  FROM public.fee_structures fs
  JOIN public.fee_structure_classes fsc ON fs.id = fsc.fee_structure_id
  WHERE fsc.class_name = NEW.class
    AND fs.academic_year = current_year
    AND fs.academic_term = current_term
    AND fs.is_active = true
  ORDER BY fs.is_default DESC, fs.created_at DESC
  LIMIT 1;
  
  -- If no specific structure found, try default
  IF NOT FOUND THEN
    SELECT * INTO fee_structure_record
    FROM public.fee_structures
    WHERE academic_year = current_year
      AND academic_term = current_term
      AND is_default = true
      AND is_active = true
    LIMIT 1;
  END IF;
  
  -- Create student fee record if structure found
  IF FOUND THEN
    INSERT INTO public.student_fees (
      student_id, fee_structure_id, academic_year, academic_term,
      tuition_fee, boarding_fee, transport_fee, meals_fee, activities_fee,
      library_fee, computer_fee, laboratory_fee, sports_fee, medical_fee,
      development_fee, exam_fee, uniform_fee, miscellaneous_fee
    ) VALUES (
      NEW.id, fee_structure_record.id, current_year, current_term,
      fee_structure_record.tuition_fee,
      CASE WHEN NEW.boarding_status = 'Boarding' THEN fee_structure_record.boarding_fee ELSE 0 END,
      CASE WHEN NEW.transport = 'Yes' THEN fee_structure_record.transport_fee ELSE 0 END,
      fee_structure_record.meals_fee, fee_structure_record.activities_fee,
      fee_structure_record.library_fee, fee_structure_record.computer_fee,
      fee_structure_record.laboratory_fee, fee_structure_record.sports_fee,
      fee_structure_record.medical_fee, fee_structure_record.development_fee,
      fee_structure_record.exam_fee, fee_structure_record.uniform_fee,
      fee_structure_record.miscellaneous_fee
    ) ON CONFLICT (student_id, academic_year, academic_term) DO UPDATE SET
      fee_structure_id = fee_structure_record.id,
      tuition_fee = fee_structure_record.tuition_fee,
      boarding_fee = CASE WHEN NEW.boarding_status = 'Boarding' THEN fee_structure_record.boarding_fee ELSE 0 END,
      transport_fee = CASE WHEN NEW.transport = 'Yes' THEN fee_structure_record.transport_fee ELSE 0 END,
      updated_at = NOW();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to update total_paid when transactions are added
CREATE OR REPLACE FUNCTION public.update_student_fees_on_payment()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.student_fees 
  SET total_paid = (
    SELECT COALESCE(SUM(amount), 0) 
    FROM public.fee_transactions 
    WHERE student_fee_id = NEW.student_fee_id
  ),
  updated_at = NOW()
  WHERE id = NEW.student_fee_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER trigger_auto_assign_student_fees
  AFTER INSERT OR UPDATE ON public.students
  FOR EACH ROW EXECUTE FUNCTION public.auto_assign_student_fees();

CREATE TRIGGER trigger_update_student_fees_on_payment
  AFTER INSERT ON public.fee_transactions
  FOR EACH ROW EXECUTE FUNCTION public.update_student_fees_on_payment();

-- Enable RLS
ALTER TABLE public.fee_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_structure_classes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allowing all operations for now since auth is disabled)
CREATE POLICY "Allow all operations on fee_structures" ON public.fee_structures FOR ALL USING (true);
CREATE POLICY "Allow all operations on student_fees" ON public.student_fees FOR ALL USING (true);
CREATE POLICY "Allow all operations on fee_transactions" ON public.fee_transactions FOR ALL USING (true);
CREATE POLICY "Allow all operations on fee_structure_classes" ON public.fee_structure_classes FOR ALL USING (true);

-- Insert sample fee structures
INSERT INTO public.fee_structures (name, description, class_level, boarding_status, tuition_fee, boarding_fee, transport_fee, meals_fee, activities_fee, library_fee, computer_fee, exam_fee, academic_year, academic_term, is_default, is_active) VALUES
('Primary Lower Classes', 'Fee structure for Primary 1-3', 'Primary 1-3', 'Both', 400000, 200000, 50000, 80000, 30000, 20000, 25000, 15000, '2024', 'Term 1', true, true),
('Primary Upper Classes', 'Fee structure for Primary 4-7', 'Primary 4-7', 'Both', 500000, 250000, 50000, 80000, 40000, 25000, 30000, 20000, '2024', 'Term 1', false, true),
('Secondary Lower', 'Fee structure for Secondary 1-4', 'Secondary 1-4', 'Both', 600000, 300000, 60000, 100000, 50000, 30000, 40000, 25000, '2024', 'Term 1', false, true);
