-- Create class_teachers table for managing teacher assignments to classes
CREATE TABLE public.class_teachers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  class_name TEXT NOT NULL,
  teacher_id UUID NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('class_teacher', 'subject_teacher', 'assistant')),
  subjects TEXT[] DEFAULT '{}',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(class_name, teacher_id, role)
);

-- Create class_rules table for managing class-specific rules
CREATE TABLE public.class_rules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  class_name TEXT NOT NULL,
  rule_type TEXT NOT NULL CHECK (rule_type IN ('discipline', 'academic', 'general', 'safety')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  is_mandatory BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for class_teachers
ALTER TABLE public.class_teachers ENABLE ROW LEVEL SECURITY;

-- Enable RLS for class_rules  
ALTER TABLE public.class_rules ENABLE ROW LEVEL SECURITY;

-- Create policies for class_teachers
CREATE POLICY "Allow all operations on class_teachers" 
ON public.class_teachers 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Create policies for class_rules
CREATE POLICY "Allow all operations on class_rules" 
ON public.class_rules 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_class_teachers_updated_at
BEFORE UPDATE ON public.class_teachers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_class_rules_updated_at
BEFORE UPDATE ON public.class_rules
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();