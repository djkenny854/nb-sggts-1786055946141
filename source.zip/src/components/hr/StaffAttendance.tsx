
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, Search, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import AttendanceMarkDialog from './AttendanceMarkDialog';

interface StaffAttendanceRecord {
  id: string;
  teacher_id: string;
  date: string;
  check_in_time: string;
  check_out_time: string;
  hours_worked: number;
  status: string;
  notes: string;
  teachers: {
    name: string;
    employee_id: string;
  };
}

const StaffAttendance = () => {
  const [attendanceRecords, setAttendanceRecords] = useState<StaffAttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchAttendance();
  }, [selectedDate]);

  const fetchAttendance = async () => {
    try {
      const { data, error } = await supabase
        .from('staff_attendance')
        .select(`
          *,
          teachers (
            name,
            employee_id
          )
        `)
        .eq('date', selectedDate)
        .order('check_in_time', { ascending: true });

      if (error) throw error;
      setAttendanceRecords(data || []);
    } catch (error) {
      console.error('Error fetching staff attendance:', error);
      toast({
        title: "Error",
        description: "Failed to fetch staff attendance records",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-800';
      case 'absent': return 'bg-red-100 text-red-800';
      case 'late': return 'bg-yellow-100 text-yellow-800';
      case 'half_day': return 'bg-blue-100 text-blue-800';
      case 'on_leave': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredRecords = attendanceRecords.filter(record => {
    const matchesSearch = record.teachers?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.teachers?.employee_id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return <div className="flex justify-center p-8">Loading attendance records...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search staff..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-48"
          />

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="present">Present</SelectItem>
              <SelectItem value="absent">Absent</SelectItem>
              <SelectItem value="late">Late</SelectItem>
              <SelectItem value="half_day">Half Day</SelectItem>
              <SelectItem value="on_leave">On Leave</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Mark Attendance
        </Button>
      </div>

      <div className="grid gap-4">
        {filteredRecords.map((record) => (
          <Card key={record.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">{record.teachers?.name || 'Unknown Staff'}</h3>
                  <p className="text-sm text-muted-foreground">
                    Employee ID: {record.teachers?.employee_id || 'N/A'}
                  </p>
                </div>

                <div className="flex items-center space-x-4">
                  <Badge className={getStatusColor(record.status)}>
                    {record.status.replace('_', ' ').toUpperCase()}
                  </Badge>

                  {record.check_in_time && (
                    <div className="flex items-center space-x-1 text-sm">
                      <Clock className="h-4 w-4" />
                      <span>In: {record.check_in_time}</span>
                    </div>
                  )}

                  {record.check_out_time && (
                    <div className="flex items-center space-x-1 text-sm">
                      <Clock className="h-4 w-4" />
                      <span>Out: {record.check_out_time}</span>
                    </div>
                  )}

                  {record.hours_worked && (
                    <div className="text-sm font-medium">
                      {record.hours_worked} hrs
                    </div>
                  )}
                </div>
              </div>

              {record.notes && (
                <div className="mt-2 text-sm text-muted-foreground">
                  Notes: {record.notes}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredRecords.length === 0 && (
        <div className="text-center py-8">
          <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">No attendance records found</h3>
          <p className="text-muted-foreground">No staff attendance records found for the selected date and filters.</p>
        </div>
      )}

      <AttendanceMarkDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        selectedDate={selectedDate}
        onSuccess={fetchAttendance}
      />
    </div>
  );
};

export default StaffAttendance;
