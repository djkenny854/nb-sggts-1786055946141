
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

interface ClassPerformanceChartProps {
  className: string;
}

const ClassPerformanceChart: React.FC<ClassPerformanceChartProps> = ({ className }) => {
  // Mock performance data - in real app, this would come from exam results
  const performanceData = [
    { subject: 'Math', average: 78, lastExam: 82 },
    { subject: 'English', average: 85, lastExam: 88 },
    { subject: 'Science', average: 72, lastExam: 75 },
    { subject: 'History', average: 80, lastExam: 84 },
    { subject: 'Geography', average: 76, lastExam: 79 }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Performance Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="subject" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="average" fill="#3b82f6" name="Class Average" />
            <Bar dataKey="lastExam" fill="#10b981" name="Last Exam" />
          </BarChart>
        </ResponsiveContainer>
        
        <div className="mt-4 text-sm text-muted-foreground">
          <p>Blue bars show class average, green bars show last exam performance</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClassPerformanceChart;
