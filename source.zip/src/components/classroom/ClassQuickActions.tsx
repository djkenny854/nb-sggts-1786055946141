
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  UserPlus, 
  MessageCircle, 
  Printer, 
  Calendar, 
  ClipboardList,
  FileText,
  DollarSign,
  Bell
} from 'lucide-react';

interface ClassQuickActionsProps {
  className: string;
  studentCount: number;
}

const ClassQuickActions: React.FC<ClassQuickActionsProps> = ({ 
  className, 
  studentCount 
}) => {
  const actions = [
    {
      icon: UserPlus,
      label: 'Add Student',
      description: 'Enroll new student',
      color: 'text-blue-500',
      action: () => console.log('Add student')
    },
    {
      icon: MessageCircle,
      label: 'Message Class',
      description: 'Send notification',
      color: 'text-green-500',
      action: () => console.log('Message class')
    },
    {
      icon: Calendar,
      label: 'Take Attendance',
      description: 'Mark present/absent',
      color: 'text-purple-500',
      action: () => console.log('Take attendance')
    },
    {
      icon: ClipboardList,
      label: 'Grade Assignment',
      description: 'Record scores',
      color: 'text-orange-500',
      action: () => console.log('Grade assignment')
    },
    {
      icon: DollarSign,
      label: 'Record Payment',
      description: 'Update fee records',
      color: 'text-emerald-500',
      action: () => console.log('Record payment')
    },
    {
      icon: FileText,
      label: 'Class Report',
      description: 'Generate summary',
      color: 'text-indigo-500',
      action: () => console.log('Generate report')
    },
    {
      icon: Printer,
      label: 'Print Lists',
      description: 'Student roster',
      color: 'text-gray-500',
      action: () => console.log('Print lists')
    },
    {
      icon: Bell,
      label: 'Send Alerts',
      description: 'Fee reminders',
      color: 'text-red-500',
      action: () => console.log('Send alerts')
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {actions.map((action, index) => {
            const IconComponent = action.icon;
            return (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center gap-2 hover:shadow-md transition-all"
                onClick={action.action}
              >
                <IconComponent className={`w-5 h-5 ${action.color}`} />
                <div className="text-center">
                  <div className="text-xs font-medium">{action.label}</div>
                  <div className="text-xs text-muted-foreground">
                    {action.description}
                  </div>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default ClassQuickActions;
