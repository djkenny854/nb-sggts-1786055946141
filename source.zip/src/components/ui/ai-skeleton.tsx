
import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Brain, Zap } from 'lucide-react';

interface AISkeletonProps {
  lines?: number;
  showIcon?: boolean;
  className?: string;
  message?: string;
}

const AISkeleton: React.FC<AISkeletonProps> = ({ 
  lines = 3, 
  showIcon = true, 
  className = "",
  message = "AI is analyzing..."
}) => {
  return (
    <div className={`space-y-3 ${className}`}>
      {showIcon && (
        <div className="flex items-center gap-2 mb-4">
          <div className="relative">
            <Brain className="h-5 w-5 text-purple-600 animate-pulse" />
            <div className="absolute inset-0 animate-ping opacity-20">
              <Brain className="h-5 w-5 text-purple-600" />
            </div>
          </div>
          <span className="text-sm text-purple-600 font-medium">{message}</span>
          <div className="flex space-x-1">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      )}
      
      <div className="space-y-2">
        {[...Array(lines)].map((_, i) => (
          <div key={i} className="flex items-center space-x-2">
            <Zap className="h-3 w-3 text-purple-400 animate-pulse" />
            <Skeleton 
              className="h-4 animate-pulse" 
              style={{ width: `${Math.random() * 40 + 60}%` }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default AISkeleton;
