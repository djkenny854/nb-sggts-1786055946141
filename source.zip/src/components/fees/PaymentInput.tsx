
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface PaymentInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
  error?: string;
  currency?: string;
}

export const PaymentInput: React.FC<PaymentInputProps> = ({
  className,
  label,
  description,
  error,
  currency = "$",
  id,
  ...props
}) => {
  return (
    <div className="space-y-2">
      {label && <Label htmlFor={id}>{label}</Label>}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <span className="text-gray-500">{currency}</span>
        </div>
        <Input
          id={id}
          className={cn(
            "pl-7",
            error && "border-red-500 focus-visible:ring-red-500",
            className
          )}
          {...props}
        />
      </div>
      {description && !error && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      {error && (
        <p className="text-sm text-red-500">{error}</p>
      )}
    </div>
  );
};
