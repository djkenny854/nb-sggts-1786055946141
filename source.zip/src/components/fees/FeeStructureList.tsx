
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Copy, Trash2, Eye, EyeOff } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface FeeStructure {
  id: string;
  name: string;
  description?: string;
  class_level?: string;
  boarding_status: 'Day' | 'Boarding' | 'Both';
  tuition_fee: number;
  boarding_fee: number;
  transport_fee: number;
  meals_fee: number;
  activities_fee: number;
  library_fee: number;
  computer_fee: number;
  laboratory_fee: number;
  sports_fee: number;
  medical_fee: number;
  development_fee: number;
  exam_fee: number;
  uniform_fee: number;
  miscellaneous_fee: number;
  academic_year: string;
  academic_term: string;
  is_active: boolean;
  is_default: boolean;
  created_at: string;
}

interface ClassOption {
  id: string;
  full_name: string;
  class_level: string;
  stream_name: string;
}

interface FeeStructureListProps {
  feeStructures: FeeStructure[];
  classOptions: ClassOption[];
  handleEdit: (structure: FeeStructure) => void;
  handleDuplicate: (structure: FeeStructure) => void;
  handleDelete: (id: string) => void;
}

const FeeStructureList: React.FC<FeeStructureListProps> = ({
  feeStructures,
  classOptions,
  handleEdit,
  handleDuplicate,
  handleDelete,
}) => {
  const [structureClasses, setStructureClasses] = useState<Record<string, string[]>>({});
  const [expandedStructures, setExpandedStructures] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchStructureClasses();
  }, [feeStructures]);

  const fetchStructureClasses = async () => {
    if (feeStructures.length === 0) return;

    try {
      const { data, error } = await supabase
        .from('fee_structure_classes')
        .select(`
          fee_structure_id, 
          class_id,
          class_streams!inner(full_name)
        `)
        .in('fee_structure_id', feeStructures.map(s => s.id));

      if (error) throw error;

      const classMap: Record<string, string[]> = {};
      data?.forEach((item: any) => {
        if (!classMap[item.fee_structure_id]) {
          classMap[item.fee_structure_id] = [];
        }
        classMap[item.fee_structure_id].push(item.class_streams.full_name);
      });

      setStructureClasses(classMap);
    } catch (error) {
      console.error('Error fetching structure classes:', error);
    }
  };

  const calculateTotal = (structure: FeeStructure) => {
    return structure.tuition_fee + structure.boarding_fee + structure.transport_fee + 
           structure.meals_fee + structure.activities_fee + structure.library_fee + 
           structure.computer_fee + structure.laboratory_fee + structure.sports_fee + 
           structure.medical_fee + structure.development_fee + structure.exam_fee + 
           structure.uniform_fee + structure.miscellaneous_fee;
  };

  const toggleExpanded = (structureId: string) => {
    const newExpanded = new Set(expandedStructures);
    if (newExpanded.has(structureId)) {
      newExpanded.delete(structureId);
    } else {
      newExpanded.add(structureId);
    }
    setExpandedStructures(newExpanded);
  };

  const getFeeComponents = (structure: FeeStructure) => {
    const components = [
      { name: 'Tuition', amount: structure.tuition_fee },
      { name: 'Boarding', amount: structure.boarding_fee },
      { name: 'Transport', amount: structure.transport_fee },
      { name: 'Meals', amount: structure.meals_fee },
      { name: 'Activities', amount: structure.activities_fee },
      { name: 'Library', amount: structure.library_fee },
      { name: 'Computer', amount: structure.computer_fee },
      { name: 'Laboratory', amount: structure.laboratory_fee },
      { name: 'Sports', amount: structure.sports_fee },
      { name: 'Medical', amount: structure.medical_fee },
      { name: 'Development', amount: structure.development_fee },
      { name: 'Exam', amount: structure.exam_fee },
      { name: 'Uniform', amount: structure.uniform_fee },
      { name: 'Miscellaneous', amount: structure.miscellaneous_fee }
    ].filter(component => component.amount > 0);

    return components;
  };

  if (feeStructures.length === 0) {
    return (
      <Card className="bg-white border-gray-200">
        <CardContent className="p-12 text-center">
          <div className="text-gray-500">
            <p className="text-lg">No fee structures created yet</p>
            <p className="text-sm mt-2">Click "Create Fee Structure" to get started</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {feeStructures.map((structure) => {
        const isExpanded = expandedStructures.has(structure.id);
        const assignedClasses = structureClasses[structure.id] || [];
        const feeComponents = getFeeComponents(structure);

        return (
          <Card key={structure.id} className="bg-white border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <CardTitle className="text-lg text-gray-900">{structure.name}</CardTitle>
                    <div className="flex gap-2">
                      {structure.is_default && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                          Default
                        </Badge>
                      )}
                      <Badge 
                        variant={structure.is_active ? "default" : "destructive"}
                        className={structure.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                      >
                        {structure.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      <Badge variant="outline" className="border-gray-300 text-gray-700">
                        {structure.academic_year} - {structure.academic_term}
                      </Badge>
                    </div>
                  </div>
                  
                  {structure.description && (
                    <p className="text-gray-600 text-sm mb-2">{structure.description}</p>
                  )}
                  
                  <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                    {structure.class_level && (
                      <span>Level: {structure.class_level}</span>
                    )}
                    <span>•</span>
                    <span>Boarding: {structure.boarding_status}</span>
                    {assignedClasses.length > 0 && (
                      <>
                        <span>•</span>
                        <span>Classes: {assignedClasses.slice(0, 3).join(',')}{assignedClasses.length > 3 ? ` +${assignedClasses.length - 3} more` : ''}</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleExpanded(structure.id)}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    {isExpanded ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(structure)}
                    className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDuplicate(structure)}
                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(structure.id)}
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-gray-200">
                <div className="text-sm text-gray-600">
                  {feeComponents.length} fee components
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">
                    UGX {calculateTotal(structure).toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-600">Total fees</div>
                </div>
              </div>
            </CardHeader>

            {isExpanded && (
              <CardContent className="pt-0">
                <div className="space-y-4">
                  {/* Fee Breakdown */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Fee Breakdown</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {feeComponents.map((component) => (
                        <div key={component.name} className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-sm text-gray-600">{component.name}</div>
                          <div className="font-semibold text-gray-900">
                            UGX {component.amount.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Assigned Classes */}
                  {assignedClasses.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Assigned Classes</h4>
                      <div className="flex flex-wrap gap-2">
                        {assignedClasses.map((className) => (
                          <Badge key={className} variant="outline" className="border-gray-300 text-gray-700">
                            {className}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
};

export default FeeStructureList;
