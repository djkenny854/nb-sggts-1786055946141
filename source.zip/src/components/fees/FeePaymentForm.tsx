
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Student } from '@/types';
import { PaymentMethod } from '@/types/payment';
import { addPayment } from '@/utils/paymentService';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { Textarea } from '@/components/ui/textarea';
import { useData } from '@/context/DataSyncContext';
import { format } from 'date-fns';
import { Receipt } from 'lucide-react';
import { addPaymentToStudent } from '@/utils/indexedDB';
import { v4 as uuidv4 } from 'uuid';

const FeePaymentForm = ({ onSuccess }: { onSuccess?: () => void }) => {
  const { user } = useAuth();
  const { students, classes, refreshData } = useData();
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [filterClass, setFilterClass] = useState<string>('');
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [receiptData, setReceiptData] = useState<any>(null);
  const [paymentData, setPaymentData] = useState({
    amount: '',
    method: 'Cash' as PaymentMethod,
    description: '',
    academicTerm: 'Term 1',
    academicYear: new Date().getFullYear().toString()
  });

  // Filter students based on selected class
  useEffect(() => {
    if (filterClass) {
      setFilteredStudents(students.filter(student => student.classId === filterClass));
    } else {
      setFilteredStudents(students);
    }
  }, [filterClass, students]);

  // Update selected student when ID changes
  useEffect(() => {
    if (selectedStudentId) {
      const foundStudent = students.find(s => s.id === selectedStudentId);
      setSelectedStudent(foundStudent || null);
    } else {
      setSelectedStudent(null);
    }
  }, [selectedStudentId, students]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPaymentData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentId || !paymentData.amount) {
      toast({
        title: "Validation Error",
        description: "Student and amount are required",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // First, add the payment to the local IndexedDB
      const amount = parseFloat(paymentData.amount);
      const paymentId = uuidv4();
      const payment = {
        id: paymentId,
        date: new Date().toISOString(),
        amount: amount,
        method: paymentData.method,
        receiptNo: `RCP-${Math.floor(Math.random() * 10000)}`,
        notes: paymentData.description,
        createdAt: new Date().toISOString(),
        createdBy: user?.name || 'System',
      };

      // Update the student record locally
      const updatedStudent = await addPaymentToStudent(selectedStudentId, payment);
      
      // Also save to Supabase if connected
      const serverPayment = {
        studentId: selectedStudentId,
        studentName: selectedStudent?.name,
        amount: amount,
        method: paymentData.method,
        description: paymentData.description,
        receivedBy: user?.name || 'System',
        academicTerm: paymentData.academicTerm,
        academicYear: paymentData.academicYear
      };
      
      await addPayment(serverPayment);
      
      // Prepare the receipt data
      const receipt = {
        ...payment,
        student: selectedStudent,
        date: new Date().toISOString(),
        receivedBy: user?.name || 'System',
      };
      setReceiptData(receipt);
      setShowReceipt(true);
      
      refreshData();
      
      toast({
        title: "Success",
        description: `Payment of ${amount} recorded successfully`,
      });
      
      if (onSuccess && !showReceipt) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error recording payment:', error);
      toast({
        title: "Error",
        description: "Failed to record payment",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setPaymentData({
      amount: '',
      method: 'Cash',
      description: '',
      academicTerm: 'Term 1',
      academicYear: new Date().getFullYear().toString()
    });
    setSelectedStudentId('');
    setShowReceipt(false);
  };

  return (
    <>
      {!showReceipt ? (
        <Card>
          <CardHeader>
            <CardTitle>Record Fee Payment</CardTitle>
            <CardDescription>Enter student payment details</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="class">Filter by Class</Label>
                    <Select value={filterClass} onValueChange={setFilterClass}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Classes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Classes</SelectItem>
                        {classes.map(cls => (
                          <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="student">Student</Label>
                    <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select student" />
                      </SelectTrigger>
                      <SelectContent>
                        {filteredStudents.map(student => (
                          <SelectItem key={student.id} value={student.id}>{student.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedStudent && (
                    <div className="rounded-md bg-muted p-4 space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-sm font-medium">Class:</p>
                          <p className="text-sm text-muted-foreground">{selectedStudent.className}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Registration:</p>
                          <p className="text-sm text-muted-foreground">{selectedStudent.enrollmentNumber}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Outstanding Balance:</p>
                        <p className="text-sm font-semibold text-red-500">
                          UGX {selectedStudent.fees.due.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5">UGX</span>
                      <Input
                        id="amount"
                        name="amount"
                        className="pl-12"
                        placeholder="0"
                        value={paymentData.amount}
                        onChange={handleInputChange}
                        type="number"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="method">Payment Method</Label>
                    <Select
                      value={paymentData.method}
                      onValueChange={(value: PaymentMethod) => 
                        setPaymentData(prev => ({ ...prev, method: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Mobile Money">Mobile Money</SelectItem>
                        <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                        <SelectItem value="Card">Card</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="academicTerm">Term</Label>
                      <Select
                        value={paymentData.academicTerm}
                        onValueChange={(value) => 
                          setPaymentData(prev => ({ ...prev, academicTerm: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select term" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Term 1">Term 1</SelectItem>
                          <SelectItem value="Term 2">Term 2</SelectItem>
                          <SelectItem value="Term 3">Term 3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="academicYear">Year</Label>
                      <Input
                        id="academicYear"
                        name="academicYear"
                        value={paymentData.academicYear}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      name="description"
                      placeholder="E.g., School fees for Term 1"
                      value={paymentData.description}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={resetForm}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? 'Processing...' : 'Record Payment'}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <Card>
          <CardHeader className="bg-muted">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center">
                <Receipt className="mr-2 h-5 w-5" />
                Payment Receipt
              </CardTitle>
              <Button variant="outline" size="sm" onClick={() => window.print()}>
                Print Receipt
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {receiptData && (
              <div className="space-y-6 px-4">
                <div className="flex justify-center mb-6">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold">SCHOOL NAME</h2>
                    <p className="text-muted-foreground">P.O. Box 12345, City, Country</p>
                    <p className="text-muted-foreground">Tel: +123 456 7890</p>
                  </div>
                </div>
                
                <div className="flex justify-between text-sm">
                  <div>
                    <p className="font-semibold">Receipt #: {receiptData.receiptNo}</p>
                    <p>Date: {format(new Date(receiptData.date), 'MMM dd, yyyy')}</p>
                  </div>
                  <div>
                    <p>Received By: {receiptData.receivedBy}</p>
                    <p>Payment Method: {receiptData.method}</p>
                  </div>
                </div>
                
                <div className="border-t border-b py-4 my-4">
                  <div className="grid grid-cols-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Student Name:</p>
                      <p className="font-semibold">{receiptData.student?.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Class:</p>
                      <p>{receiptData.student?.className}</p>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm text-muted-foreground">Reg Number:</p>
                      <p>{receiptData.student?.enrollmentNumber}</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-md">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-semibold">Payment Description</p>
                        <p>{receiptData.notes || "School Fees Payment"}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Amount:</p>
                        <p className="text-xl font-bold">UGX {receiptData.amount.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <div>
                      <p className="text-muted-foreground">Previous Balance:</p>
                      <p>UGX {(receiptData.student.fees.due + receiptData.amount).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Amount Paid:</p>
                      <p className="text-green-600">UGX {receiptData.amount.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">New Balance:</p>
                      <p className="font-semibold">UGX {receiptData.student.fees.due.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
                
                <div className="border-t pt-4 mt-8 text-center text-sm text-muted-foreground">
                  <p>Thank you for your payment.</p>
                  <p>This receipt is valid when stamped and signed.</p>
                </div>
                
                <div className="flex justify-between mt-8 pt-8">
                  <div>
                    <div className="border-t border-dashed border-muted-foreground w-40">
                      <p className="text-sm text-center pt-1">Cashier's Signature</p>
                    </div>
                  </div>
                  <div>
                    <div className="border-t border-dashed border-muted-foreground w-40">
                      <p className="text-sm text-center pt-1">Official Stamp</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={resetForm}>
              Record Another Payment
            </Button>
            <Button onClick={onSuccess}>
              Done
            </Button>
          </CardFooter>
        </Card>
      )}
    </>
  );
};

export default FeePaymentForm;
