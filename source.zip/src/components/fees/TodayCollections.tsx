import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const TodayCollections = () => {
  const {
    data: todayCollections,
    isLoading
  } = useQuery({
    queryKey: ['today-collections'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const {
        data,
        error
      } = await supabase
        .from('fee_transactions')
        .select('amount')
        .gte('payment_date', `${today}T00:00:00.000Z`)
        .lt('payment_date', `${today}T23:59:59.999Z`);
      
      if (error) throw error;
      
      const total = data?.reduce((sum, transaction) => sum + (transaction.amount || 0), 0) || 0;
      return {
        total,
        count: data?.length || 0
      };
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Today's Collections</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-muted-foreground">Loading...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Today's Collections</CardTitle>
        <DollarSign className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold truncate">
          UGX {(todayCollections?.total || 0).toLocaleString()}
        </div>
        <p className="text-xs text-muted-foreground flex items-center mt-1">
          <TrendingUp className="h-3 w-3 mr-1" />
          {todayCollections?.count || 0} transactions today
        </p>
      </CardContent>
    </Card>
  );
};

export default TodayCollections;
