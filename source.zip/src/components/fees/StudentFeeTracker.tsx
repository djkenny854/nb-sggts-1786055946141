
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Eye, CreditCard, FileText } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface StudentFeeRecord {
  id: string;
  full_name: string;
  student_id: string;
  class: string;
  total_expected: number;
  total_paid: number;
  balance: number;
  last_payment_date: string | null;
  fee_status: 'Paid' | 'Partial' | 'Unpaid';
}

const StudentFeeTracker = () => {
  const [students, setStudents] = useState<StudentFeeRecord[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<StudentFeeRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [classFilter, setClassFilter] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStudentFeeData();
  }, []);

  useEffect(() => {
    filterStudents();
  }, [students, searchTerm, statusFilter, classFilter]);

  const fetchStudentFeeData = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('students')
        .select(`
          id,
          full_name,
          student_id,
          class,
          fee_status,
          student_fees(
            total_assigned_fees,
            total_paid,
            balance
          ),
          fee_transactions(
            payment_date
          )
        `);

      if (error) throw error;

      const processedData: StudentFeeRecord[] = data.map(student => {
        // Ensure fee_status is properly typed
        const feeStatus = student.fee_status as 'Paid' | 'Partial' | 'Unpaid' | null;
        
        return {
          id: student.id,
          full_name: student.full_name,
          student_id: student.student_id,
          class: student.class,
          total_expected: student.student_fees?.[0]?.total_assigned_fees || 0,
          total_paid: student.student_fees?.[0]?.total_paid || 0,
          balance: student.student_fees?.[0]?.balance || 0,
          last_payment_date: student.fee_transactions?.[0]?.payment_date || null,
          fee_status: feeStatus || 'Unpaid'
        };
      });

      setStudents(processedData);
    } catch (error) {
      console.error('Error fetching student fee data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterStudents = () => {
    let filtered = [...students];

    if (searchTerm) {
      filtered = filtered.filter(student =>
        student.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.student_id.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'All') {
      filtered = filtered.filter(student => student.fee_status === statusFilter);
    }

    if (classFilter !== 'All') {
      filtered = filtered.filter(student => student.class === classFilter);
    }

    setFilteredStudents(filtered);
  };

  const getStatusBadge = (status: string, balance: number) => {
    if (balance === 0) {
      return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
    } else if (balance < 0) {
      return <Badge className="bg-blue-100 text-blue-800">Overpaid</Badge>;
    } else {
      return <Badge variant="destructive">Outstanding</Badge>;
    }
  };

  if (loading) {
    return <div className="p-4">Loading student fee data...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Student Fee Tracker</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or student ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Status</SelectItem>
                <SelectItem value="Paid">Paid</SelectItem>
                <SelectItem value="Partial">Partial</SelectItem>
                <SelectItem value="Unpaid">Unpaid</SelectItem>
              </SelectContent>
            </Select>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Classes</SelectItem>
                {Array.from(new Set(students.map(s => s.class))).map(className => (
                  <SelectItem key={className} value={className}>{className}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <div className="grid grid-cols-7 gap-4 p-4 bg-gray-50 font-semibold text-sm">
              <div>Student</div>
              <div>Class</div>
              <div>Expected</div>
              <div>Paid</div>
              <div>Balance</div>
              <div>Status</div>
              <div>Actions</div>
            </div>
            
            {filteredStudents.map((student) => (
              <div key={student.id} className="grid grid-cols-7 gap-4 p-4 border-t hover:bg-gray-50">
                <div>
                  <div className="font-medium">{student.full_name}</div>
                  <div className="text-sm text-gray-500">{student.student_id}</div>
                </div>
                <div>{student.class}</div>
                <div className="font-medium">
                  UGX {student.total_expected.toLocaleString()}
                </div>
                <div className="text-green-600 font-medium">
                  UGX {student.total_paid.toLocaleString()}
                </div>
                <div className={`font-medium ${student.balance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  UGX {student.balance.toLocaleString()}
                </div>
                <div>
                  {getStatusBadge(student.fee_status, student.balance)}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <CreditCard className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <FileText className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 text-sm text-gray-600">
            Showing {filteredStudents.length} of {students.length} students
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentFeeTracker;
