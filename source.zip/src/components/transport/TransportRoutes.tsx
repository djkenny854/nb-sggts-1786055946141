
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit2, Map, Plus } from 'lucide-react';

const TransportRoutes = () => {
  const routes = [
    { id: 'r1', name: 'North Route', stops: 8, distance: '12.5 km', driver: 'John Smith', vehicle: 'Bus 01', status: 'active' },
    { id: 'r2', name: 'South Route', stops: 6, distance: '8.2 km', driver: 'Mary Johnson', vehicle: 'Bus 03', status: 'active' },
    { id: 'r3', name: 'East Route', stops: 5, distance: '6.7 km', driver: 'Robert Brown', vehicle: 'Van 02', status: 'inactive' },
    { id: 'r4', name: 'West Route', stops: 7, distance: '9.3 km', driver: 'Susan Davis', vehicle: 'Bus 02', status: 'active' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Routes Overview</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Route
        </Button>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Route Name</TableHead>
                <TableHead>Stops</TableHead>
                <TableHead>Distance</TableHead>
                <TableHead>Driver</TableHead>
                <TableHead>Vehicle</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {routes.map((route) => (
                <TableRow key={route.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <Map className="mr-2 h-4 w-4 text-muted-foreground" />
                      {route.name}
                    </div>
                  </TableCell>
                  <TableCell>{route.stops}</TableCell>
                  <TableCell>{route.distance}</TableCell>
                  <TableCell>{route.driver}</TableCell>
                  <TableCell>{route.vehicle}</TableCell>
                  <TableCell>
                    <Badge variant={route.status === 'active' ? 'success' : 'outline'}>
                      {route.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default TransportRoutes;
