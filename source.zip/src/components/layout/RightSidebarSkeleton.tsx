import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import AITextAnimation from '@/components/ui/ai-text-animation';

const RightSidebarSkeleton = () => {
  return (
    <div className="p-4 h-full overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pt-16">
        <Skeleton className="h-6 w-24" />
      </div>

      {/* Today's Schedule Skeleton */}
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-28" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <AITextAnimation
            texts={[
              "Loading today's schedule...",
              "Fetching class timings...",
              "Getting teacher assignments..."
            ]}
            className="text-sm text-muted-foreground"
            interval={1500}
          />
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-2 rounded-md bg-accent/50">
              <div className="space-y-1">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-3 w-16" />
              </div>
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent Activity Skeleton */}
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-24" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <AITextAnimation
            texts={[
              "Loading recent activities...",
              "Fetching updates...",
              "Getting latest changes..."
            ]}
            className="text-sm text-muted-foreground"
            interval={1500}
          />
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-start gap-3">
              <Skeleton className="w-2 h-2 rounded-full mt-2 flex-shrink-0" />
              <div className="space-y-1 flex-1">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Stats Skeleton */}
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-20" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <AITextAnimation
            texts={[
              "Calculating statistics...",
              "Processing attendance data...",
              "Computing financial metrics..."
            ]}
            className="text-sm text-muted-foreground"
            interval={1500}
          />
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex justify-between items-center">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-16" />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Messages Skeleton */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-28" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <AITextAnimation
            texts={[
              "Loading messages...",
              "Fetching communications...",
              "Getting notifications..."
            ]}
            className="text-sm text-muted-foreground"
            interval={1500}
          />
          {[...Array(2)].map((_, i) => (
            <div key={i} className="p-2 rounded-md bg-accent/50 space-y-1">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-3 w-16" />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default RightSidebarSkeleton;