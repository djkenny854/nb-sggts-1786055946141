import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users, MessageSquare, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSiteSettings } from '@/context/SiteSettingsContext';
import { supabase } from '@/integrations/supabase/client';
import RightSidebarSkeleton from './RightSidebarSkeleton';
import { format } from 'date-fns';

interface ScheduleItem {
  id: string;
  subject: string;
  class_name: string;
  time: string;
  teacher?: string;
}

interface RecentActivity {
  id: string;
  type: string;
  description: string;
  timestamp: string;
  color: string;
}

interface QuickStats {
  presentToday: number;
  totalStudents: number;
  pendingFees: number;
  activeTeachers: number;
  totalTeachers: number;
}

interface RecentMessage {
  id: string;
  title: string;
  sender: string;
  timestamp: string;
}

const RightSidebar = () => {
  const { isRightSidebarOpen, toggleRightSidebar } = useSiteSettings();
  const [loading, setLoading] = useState(true);
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [activities, setActivities] = useState<RecentActivity[]>([]);
  const [stats, setStats] = useState<QuickStats>({
    presentToday: 0,
    totalStudents: 0,
    pendingFees: 0,
    activeTeachers: 0,
    totalTeachers: 0
  });
  const [messages, setMessages] = useState<RecentMessage[]>([]);

  useEffect(() => {
    if (isRightSidebarOpen) {
      fetchRightSidebarData();
    }
  }, [isRightSidebarOpen]);

  const fetchRightSidebarData = async () => {
    try {
      setLoading(true);
      
      // Fetch data in parallel
      const [
        scheduleData,
        activitiesData,
        statsData,
        messagesData
      ] = await Promise.all([
        fetchTodaySchedule(),
        fetchRecentActivities(),
        fetchQuickStats(),
        fetchRecentMessages()
      ]);

      setSchedule(scheduleData);
      setActivities(activitiesData);
      setStats(statsData);
      setMessages(messagesData);
    } catch (error) {
      console.error('Error fetching right sidebar data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTodaySchedule = async (): Promise<ScheduleItem[]> => {
    // For now, return mock data - this would be replaced with actual timetable data
    return [
      { id: '1', subject: 'Mathematics', class_name: 'Grade 10A', time: '9:00 AM', teacher: 'Mr. Smith' },
      { id: '2', subject: 'Physics Lab', class_name: 'Grade 12B', time: '11:30 AM', teacher: 'Dr. Johnson' },
      { id: '3', subject: 'Staff Meeting', class_name: 'Conference Room', time: '2:00 PM' }
    ];
  };

  const fetchRecentActivities = async (): Promise<RecentActivity[]> => {
    const activities: RecentActivity[] = [];
    
    // Get recent student registrations
    const { data: students } = await supabase
      .from('students')
      .select('full_name, class, created_at')
      .order('created_at', { ascending: false })
      .limit(2);

    if (students) {
      students.forEach(student => {
        activities.push({
          id: `student-${student.full_name}`,
          type: 'enrollment',
          description: `New student enrolled in ${student.class}`,
          timestamp: student.created_at,
          color: 'bg-primary'
        });
      });
    }

    // Get recent fee payments
    const { data: payments } = await supabase
      .from('fee_transactions')
      .select('amount, payment_date, student_id')
      .eq('status', 'completed')
      .order('payment_date', { ascending: false })
      .limit(2);

    if (payments) {
      payments.forEach(payment => {
        activities.push({
          id: `payment-${payment.student_id}`,
          type: 'payment',
          description: `Fee payment received`,
          timestamp: payment.payment_date,
          color: 'bg-green-500'
        });
      });
    }

    // Get recent attendance records
    const { data: attendance } = await supabase
      .from('attendance_records')
      .select('created_at, student_id')
      .order('created_at', { ascending: false })
      .limit(1);

    if (attendance && attendance.length > 0) {
      activities.push({
        id: `attendance-${attendance[0].student_id}`,
        type: 'attendance',
        description: 'Attendance marked',
        timestamp: attendance[0].created_at,
        color: 'bg-orange-500'
      });
    }

    return activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 3);
  };

  const fetchQuickStats = async (): Promise<QuickStats> => {
    const today = format(new Date(), 'yyyy-MM-dd');
    
    const [
      { count: totalStudents },
      { count: presentToday },
      { data: feeData },
      { count: totalTeachers }
    ] = await Promise.all([
      supabase.from('students').select('*', { count: 'exact', head: true }),
      supabase.from('attendance_records').select('*', { count: 'exact', head: true }).eq('date', today).eq('status', 'present'),
      supabase.from('student_fees').select('balance').neq('payment_status', 'Paid'),
      supabase.from('teachers').select('*', { count: 'exact', head: true })
    ]);

    const pendingFees = feeData?.reduce((sum, record) => sum + (record.balance || 0), 0) || 0;

    return {
      presentToday: presentToday || 0,
      totalStudents: totalStudents || 0,
      pendingFees,
      activeTeachers: totalTeachers || 0, // Assuming all teachers are active for now
      totalTeachers: totalTeachers || 0
    };
  };

  const fetchRecentMessages = async (): Promise<RecentMessage[]> => {
    const { data: messages } = await supabase
      .from('messages')
      .select('id, title, sender_id, created_at, metadata')
      .order('created_at', { ascending: false })
      .limit(2);

    if (messages) {
      return messages.map(msg => ({
        id: msg.id,
        title: msg.title,
        sender: (msg.metadata as any)?.sender_name || 'System',
        timestamp: msg.created_at
      }));
    }

    return [];
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hour${Math.floor(diffInMinutes / 60) > 1 ? 's' : ''} ago`;
    return format(time, 'MMM d, h:mm a');
  };

  return (
    <>
      {/* Toggle Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={toggleRightSidebar}
        className="fixed right-4 top-20 z-50 bg-background border border-border shadow-sm"
      >
        {isRightSidebarOpen ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </Button>

      {/* Right Sidebar */}
      <div
        className={`fixed right-0 top-0 h-full bg-background border-l border-border z-30 transition-all duration-300 ease-in-out ${
          isRightSidebarOpen ? 'w-80' : 'w-0'
        } overflow-hidden`}
      >
        {loading ? (
          <RightSidebarSkeleton />
        ) : (
          <div className="p-4 h-full overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6 pt-16">
              <h3 className="text-lg font-semibold text-foreground">Quick Info</h3>
            </div>

            {/* Today's Schedule */}
            <Card className="mb-4">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" />
                  Today's Schedule
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {schedule.length > 0 ? (
                  schedule.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-2 rounded-md bg-accent/50">
                      <div>
                        <p className="text-sm font-medium">{item.subject}</p>
                        <p className="text-xs text-muted-foreground">{item.class_name}</p>
                        {item.teacher && <p className="text-xs text-muted-foreground">{item.teacher}</p>}
                      </div>
                      <Badge variant="outline">{item.time}</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No schedule for today</p>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="mb-4">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {activities.length > 0 ? (
                  activities.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className={`w-2 h-2 rounded-full ${activity.color} mt-2 flex-shrink-0`}></div>
                      <div>
                        <p className="text-sm">{activity.description}</p>
                        <p className="text-xs text-muted-foreground">{formatTimeAgo(activity.timestamp)}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent activity</p>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="mb-4">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Users className="h-4 w-4 text-primary" />
                  Quick Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Present Today</span>
                  <span className="text-sm font-medium">{stats.presentToday}/{stats.totalStudents}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Pending Fees</span>
                  <span className="text-sm font-medium">₹{stats.pendingFees.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Active Teachers</span>
                  <span className="text-sm font-medium">{stats.activeTeachers}/{stats.totalTeachers}</span>
                </div>
              </CardContent>
            </Card>

            {/* Messages */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-primary" />
                  Recent Messages
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {messages.length > 0 ? (
                  messages.map((message) => (
                    <div key={message.id} className="p-2 rounded-md bg-accent/50">
                      <p className="text-sm font-medium">{message.title}</p>
                      <p className="text-xs text-muted-foreground">From: {message.sender}</p>
                      <p className="text-xs text-muted-foreground">{formatTimeAgo(message.timestamp)}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent messages</p>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </>
  );
};

export default RightSidebar;