import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Users, DollarSign, CalendarCheck, GraduationCap, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

const MobileNav = () => {
  const navItems = [
    { icon: Home, label: 'Home', href: '/dashboard' },
    { icon: Users, label: 'Students', href: '/students' },
    { icon: DollarSign, label: 'Fees', href: '/fees' },
    { icon: CalendarCheck, label: 'Attendance', href: '/attendance' },
    { icon: GraduationCap, label: 'Teachers', href: '/teachers' },
    { icon: Settings, label: 'Settings', href: '/settings' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-40 md:hidden safe-area-bottom">
      <div className="grid grid-cols-6 items-center h-16 px-2">
        {navItems.map((item) => (
          <Tooltip key={item.label} delayDuration={0}>
            <TooltipTrigger asChild>
              <NavLink
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    'mx-auto flex items-center justify-center w-12 h-12 rounded-full transition-colors',
                    isActive 
                      ? 'text-primary' 
                      : 'text-muted-foreground hover:bg-accent'
                  )
                }
                aria-label={item.label}
              >
                <item.icon className="h-6 w-6" strokeWidth={1.75} />
              </NavLink>
            </TooltipTrigger>
            <TooltipContent side="top" className="text-xs">
              {item.label}
            </TooltipContent>
          </Tooltip>
        ))}
      </div>
    </nav>
  );
};

export default MobileNav;
