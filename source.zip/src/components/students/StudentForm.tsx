import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { studentSchema, type StudentFormValues, getDefaultValues } from './form-sections/StudentFormSchema';
import BasicInfoSection from './form-sections/BasicInfoSection';
import EnrollmentSection from './form-sections/EnrollmentSection';
import ParentInfoSection from './form-sections/ParentInfoSection';
import AdditionalInfoSection from './form-sections/AdditionalInfoSection';
import ProfilePictureUpload from '@/components/common/ProfilePictureUpload';
import StudentAIAnalysis from './StudentAIAnalysis';
import StudentConfirmationDialog from './StudentConfirmationDialog';
import ClassPilotLogo from '@/components/common/ClassPilotLogo';
import { insertStudent, generateNextStudentEnrollmentNumber } from '@/utils/supabaseHelpers';
import { Save, Plus, Sparkles } from 'lucide-react';
import { Student } from '@/types';
interface StudentFormProps {
  initialData?: Partial<StudentFormValues>;
  studentId?: string;
  onSuccess?: () => void;
  mode?: 'create' | 'edit';
}
const StudentForm: React.FC<StudentFormProps> = ({
  initialData,
  studentId,
  onSuccess,
  mode = 'create'
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profileImageUrl, setProfileImageUrl] = useState(initialData?.profileImage || '');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formData, setFormData] = useState<StudentFormValues | null>(null);
  const form = useForm<StudentFormValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: initialData || getDefaultValues()
  });
  const watchedValues = form.watch();

  // Fetch available classes from Supabase
  const {
    data: availableClasses,
    isLoading: classesLoading
  } = useQuery({
    queryKey: ['available-classes'],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from('class_streams').select('id, full_name, class_level, stream_name').order('class_level', {
        ascending: true
      });
      if (error) throw error;
      return data;
    }
  });

  // Generate enrollment number when component mounts for new students
  useEffect(() => {
    if (mode === 'create' && !initialData?.enrollmentNumber) {
      generateNextStudentEnrollmentNumber().then(enrollmentNumber => {
        form.setValue('enrollmentNumber', enrollmentNumber);
      }).catch(error => {
        console.error('Error generating enrollment number:', error);
        toast.error('Failed to generate enrollment number');
      });
    }
  }, [mode, initialData, form]);
  const handleFormSubmit = async (data: StudentFormValues) => {
    setFormData(data);
    setShowConfirmation(true);
  };
  const handleConfirmedSubmit = async () => {
    if (!formData) return;
    setIsSubmitting(true);
    setShowConfirmation(false);
    try {
      // Transform form data to match Student interface
      const studentData = {
        name: formData.name,
        enrollmentNumber: formData.enrollmentNumber,
        dateOfBirth: formData.dateOfBirth || '',
        gender: formData.gender || '',
        classId: formData.className,
        className: formData.className,
        parentName: formData.parentName || '',
        parentContact: formData.parentContact || '',
        address: formData.address || '',
        joinDate: formData.joinDate || new Date().toISOString().split('T')[0],
        fees: {
          paid: 0,
          due: 0,
          lastPaymentDate: null
        },
        profileImage: profileImageUrl,
        email: formData.email,
        bloodGroup: formData.bloodGroup,
        emergencyContact: formData.emergencyContact,
        medicalConditions: formData.medicalConditions,
        boardingStatus: formData.boardingStatus || 'Day',
        transportUse: formData.transportUse || 'No',
        bestColor: formData.bestColor,
        clubsActivities: formData.clubsActivities || []
      };

      if (studentId && mode === 'edit') {
        // Update existing student
        const dbStudentData = {
          full_name: studentData.name,
          student_id: studentData.enrollmentNumber,
          class: studentData.className,
          date_of_birth: studentData.dateOfBirth,
          gender: studentData.gender,
          parent_name: studentData.parentName,
          parent_contact: studentData.parentContact,
          address: studentData.address,
          join_date: studentData.joinDate,
          boarding_status: studentData.boardingStatus,
          transport: studentData.transportUse,
          email: studentData.email,
          blood_group: studentData.bloodGroup,
          emergency_contact: studentData.emergencyContact,
          medical_conditions: studentData.medicalConditions,
          best_color: studentData.bestColor,
          clubs_activities: studentData.clubsActivities,
          profile_image_url: studentData.profileImage,
        };
        const { error: updateError } = await supabase
          .from('students')
          .update(dbStudentData)
          .eq('id', studentId)
          .select()
          .single();
        if (updateError) throw updateError;
        toast.success('Student updated successfully!');
      } else {
        // Create new student
        await insertStudent(studentData);
        toast.success('Student registered successfully! 🎉', {
          description: `${formData.name} has been registered with ID: ${formData.enrollmentNumber}`
        });

        // Reset form and generate new enrollment number
        form.reset(getDefaultValues());
        setProfileImageUrl('');
        const newEnrollmentNumber = await generateNextStudentEnrollmentNumber();
        form.setValue('enrollmentNumber', newEnrollmentNumber);
      }
      
      onSuccess?.();
    } catch (error) {
      console.error('Error saving student:', error);
      toast.error('Failed to register student', {
        description: error instanceof Error ? error.message : 'Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleProfileImageChange = (imageUrl: string) => {
    setProfileImageUrl(imageUrl);
    form.setValue('profileImage', imageUrl);
  };
  return <>
      <Card className="max-w-5xl mx-auto">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ClassPilotLogo className="w-8 h-8" />
              <div className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                
                <Sparkles className="h-4 w-4 text-primary animate-pulse" />
              </div>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-8">
              {/* Profile Picture Section */}
              <div className="flex justify-center">
                <ProfilePictureUpload currentImage={profileImageUrl} onImageChange={handleProfileImageChange} entityType="student" entityId={studentId} gender={watchedValues.gender} />
              </div>

              <Separator />

              {/* Form Sections */}
              <BasicInfoSection control={form.control} />
              
              <Separator />
              
              <EnrollmentSection control={form.control} availableClasses={availableClasses || []} classesLoading={classesLoading} />
              
              <Separator />
              
              <ParentInfoSection control={form.control} />
              
              <Separator />
              
              <AdditionalInfoSection control={form.control} />

              {/* AI Analysis */}
              <StudentAIAnalysis formData={watchedValues} />

              {/* Submit Button */}
              <div className="flex justify-end pt-6">
                <Button type="submit" disabled={isSubmitting} size="lg" className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
                  <Save className="h-4 w-4" />
                  {isSubmitting ? mode === 'edit' ? 'Updating...' : 'Registering Student...' : mode === 'edit' ? 'Update Student' : 'Register Student'}
                  <Sparkles className="h-3 w-3 animate-pulse" />
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      {formData && <StudentConfirmationDialog open={showConfirmation} onOpenChange={setShowConfirmation} studentData={formData} onConfirm={handleConfirmedSubmit} profileImageUrl={profileImageUrl} />}
    </>;
};
export default StudentForm;