
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CalendarDays, MapPin, Phone, Mail, Users, GraduationCap, Bus, Home, ArrowLeft } from 'lucide-react';
import StudentFeeBalance from './StudentFeeBalance';

interface Student {
  id: string;
  full_name: string;
  student_id: string;
  class: string;
  date_of_birth?: string;
  gender?: string;
  parent_name?: string;
  parent_contact?: string;
  email?: string;
  address?: string;
  boarding_status?: string;
  transport?: string;
  join_date?: string;
  profile_image_url?: string;
  clubs_activities?: string[];
  emergency_contact?: string;
  medical_conditions?: string;
  blood_group?: string;
  fee_status?: string;
}

interface StudentDetailViewProps {
  student: Student;
  onEdit: () => void;
  onBack?: () => void;
}

const StudentDetailView: React.FC<StudentDetailViewProps> = ({ student, onEdit, onBack }) => {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getBoardingStatusColor = (status?: string) => {
    switch (status) {
      case 'Boarding':
        return 'bg-blue-100 text-blue-800';
      case 'Day':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Section */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-4">
              {onBack && (
                <Button variant="outline" size="sm" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              )}
              <Avatar className="w-20 h-20">
                <AvatarImage src={student.profile_image_url} alt={student.full_name} />
                <AvatarFallback className="text-lg">
                  {getInitials(student.full_name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{student.full_name}</h1>
                <p className="text-gray-600">Student ID: {student.student_id}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <GraduationCap className="w-3 h-3" />
                    {student.class}
                  </Badge>
                  <Badge className={getBoardingStatusColor(student.boarding_status)}>
                    <Home className="w-3 h-3 mr-1" />
                    {student.boarding_status || 'Day'}
                  </Badge>
                  {student.transport === 'Yes' && (
                    <Badge className="bg-yellow-100 text-yellow-800">
                      <Bus className="w-3 h-3 mr-1" />
                      Transport
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <Button onClick={onEdit}>Edit Student</Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Personal Information */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {student.date_of_birth && (
                  <div className="flex items-center space-x-2">
                    <CalendarDays className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Date of Birth</p>
                      <p className="font-medium">{student.date_of_birth}</p>
                    </div>
                  </div>
                )}
                {student.gender && (
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Gender</p>
                      <p className="font-medium">{student.gender}</p>
                    </div>
                  </div>
                )}
                {student.blood_group && (
                  <div>
                    <p className="text-sm text-gray-500">Blood Group</p>
                    <p className="font-medium">{student.blood_group}</p>
                  </div>
                )}
                {student.join_date && (
                  <div>
                    <p className="text-sm text-gray-500">Join Date</p>
                    <p className="font-medium">{student.join_date}</p>
                  </div>
                )}
              </div>
              
              {student.address && (
                <div className="flex items-start space-x-2">
                  <MapPin className="w-4 h-4 text-gray-500 mt-1" />
                  <div>
                    <p className="text-sm text-gray-500">Address</p>
                    <p className="font-medium">{student.address}</p>
                  </div>
                </div>
              )}

              {student.medical_conditions && (
                <div>
                  <p className="text-sm text-gray-500">Medical Conditions</p>
                  <p className="font-medium">{student.medical_conditions}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Parent/Guardian Information */}
          <Card>
            <CardHeader>
              <CardTitle>Parent/Guardian Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {student.parent_name && (
                  <div>
                    <p className="text-sm text-gray-500">Parent/Guardian Name</p>
                    <p className="font-medium">{student.parent_name}</p>
                  </div>
                )}
                {student.parent_contact && (
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Contact Number</p>
                      <p className="font-medium">{student.parent_contact}</p>
                    </div>
                  </div>
                )}
                {student.emergency_contact && (
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-red-500" />
                    <div>
                      <p className="text-sm text-gray-500">Emergency Contact</p>
                      <p className="font-medium">{student.emergency_contact}</p>
                    </div>
                  </div>
                )}
                {student.email && (
                  <div className="flex items-center space-x-2">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-medium">{student.email}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Activities & Clubs */}
          {student.clubs_activities && student.clubs_activities.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Clubs & Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {student.clubs_activities.map((activity, index) => (
                    <Badge key={index} variant="secondary">
                      {activity}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Fee Information Sidebar */}
        <div className="space-y-6">
          <StudentFeeBalance studentId={student.id} />
        </div>
      </div>
    </div>
  );
};

export default StudentDetailView;
