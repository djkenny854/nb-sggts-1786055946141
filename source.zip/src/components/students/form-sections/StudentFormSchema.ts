
import * as z from 'zod';

export const studentSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters" }),
  enrollmentNumber: z.string().min(2, { message: "Enrollment number is required" }),
  className: z.string().min(1, { message: "Class is required" }),
  dateOfBirth: z.string().optional(),
  gender: z.string().optional(),
  parentName: z.string().optional(),
  parentContact: z.string().optional(),
  address: z.string().optional(),
  joinDate: z.string().optional(),
  boardingStatus: z.enum(["Boarding", "Day"]).default("Day"),
  transportUse: z.enum(["Yes", "No"]).default("No"),
  email: z.string().optional(),
  bloodGroup: z.string().optional(),
  emergencyContact: z.string().optional(),
  medicalConditions: z.string().optional(),
  bestColor: z.string().optional(),
  clubsActivities: z.array(z.string()).optional(),
  profileImage: z.string().optional(),
});

export type StudentFormValues = z.infer<typeof studentSchema>;

export const getDefaultValues = (): StudentFormValues => ({
  name: '',
  enrollmentNumber: '',
  className: '',
  dateOfBirth: '',
  gender: '',
  parentName: '',
  parentContact: '',
  address: '',
  joinDate: new Date().toISOString().split('T')[0],
  boardingStatus: 'Day' as const,
  transportUse: 'No' as const,
  email: '',
  bloodGroup: '',
  emergencyContact: '',
  medicalConditions: '',
  bestColor: '',
  clubsActivities: [],
  profileImage: '',
});
