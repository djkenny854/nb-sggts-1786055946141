
import React from 'react';
import { Control } from 'react-hook-form';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StudentFormValues } from './StudentFormSchema';

export interface AdditionalInfoSectionProps {
  control: Control<StudentFormValues>;
}

const AdditionalInfoSection: React.FC<AdditionalInfoSectionProps> = ({ control }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Additional Information</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="bloodGroup"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Blood Group</FormLabel>
              <Select onValueChange={field.onChange} value={field.value || "not-specified"}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select blood group" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="not-specified">Not Specified</SelectItem>
                  <SelectItem value="A-positive">A+</SelectItem>
                  <SelectItem value="A-negative">A-</SelectItem>
                  <SelectItem value="B-positive">B+</SelectItem>
                  <SelectItem value="B-negative">B-</SelectItem>
                  <SelectItem value="AB-positive">AB+</SelectItem>
                  <SelectItem value="AB-negative">AB-</SelectItem>
                  <SelectItem value="O-positive">O+</SelectItem>
                  <SelectItem value="O-negative">O-</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="bestColor"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Favorite Color</FormLabel>
              <FormControl>
                <Input placeholder="Student's favorite color" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="medicalConditions"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Medical Conditions</FormLabel>
            <FormControl>
              <Textarea 
                placeholder="Any medical conditions or allergies..." 
                {...field} 
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
};

export default AdditionalInfoSection;
