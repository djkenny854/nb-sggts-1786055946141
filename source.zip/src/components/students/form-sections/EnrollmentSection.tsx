
import React from 'react';
import { Control, useWatch } from 'react-hook-form';
import {
  FormField,
  FormItem,
  FormControl,
  FormMessage,
} from '@/components/ui/form';
import { GoogleInput } from '@/components/ui/google-input';
import { GoogleSelect, GoogleSelectItem } from '@/components/ui/google-select';
import { StudentFormValues } from './StudentFormSchema';
import { Loader2 } from 'lucide-react';
import StudentAIFeeDetector from '../StudentAIFeeDetector';

export interface EnrollmentSectionProps {
  control: Control<StudentFormValues>;
  availableClasses?: Array<{
    id: string;
    full_name: string;
    class_level: string;
    stream_name: string;
  }>;
  classesLoading?: boolean;
}

const EnrollmentSection: React.FC<EnrollmentSectionProps> = ({ 
  control, 
  availableClasses = [],
  classesLoading = false 
}) => {
  // Watch form values for AI analysis
  const watchedValues = useWatch({
    control,
    name: ['className', 'boardingStatus', 'transportUse']
  });
  
  const [selectedClass, boardingStatus, transportUse] = watchedValues;

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        📚 Enrollment Information
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={control}
          name="enrollmentNumber"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleInput
                  label="Enrollment Number *"
                  {...field}
                  readOnly
                  error={fieldState.error?.message}
                  helperText="Auto-generated enrollment ID"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="className"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                {classesLoading ? (
                  <div className="flex items-center justify-center p-4 border rounded-lg">
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    <span className="text-sm text-muted-foreground">Loading classes...</span>
                  </div>
                ) : (
                  <GoogleSelect
                    label="Class *"
                    value={field.value || 'select-class'}
                    onValueChange={field.onChange}
                    error={fieldState.error?.message}
                    helperText="Select the student's class"
                  >
                    <GoogleSelectItem value="select-class">Select a class</GoogleSelectItem>
                    {availableClasses.map((classItem) => (
                      <GoogleSelectItem 
                        key={classItem.id} 
                        value={classItem.full_name || `class-${classItem.id}`}
                      >
                        {classItem.full_name || 'Unknown Class'}
                      </GoogleSelectItem>
                    ))}
                  </GoogleSelect>
                )}
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="joinDate"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleInput
                  label="Join Date"
                  type="date"
                  {...field}
                  error={fieldState.error?.message}
                  helperText="Date of enrollment"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="boardingStatus"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleSelect
                  label="Boarding Status"
                  value={field.value || 'Day'}
                  onValueChange={field.onChange}
                  error={fieldState.error?.message}
                  helperText="Boarding or day student"
                >
                  <GoogleSelectItem value="Day">Day Student</GoogleSelectItem>
                  <GoogleSelectItem value="Boarding">Boarding Student</GoogleSelectItem>
                </GoogleSelect>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="transportUse"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleSelect
                  label="Transport Required"
                  value={field.value || 'No'}
                  onValueChange={field.onChange}
                  error={fieldState.error?.message}
                  helperText="Does student need school transport"
                >
                  <GoogleSelectItem value="No">No Transport</GoogleSelectItem>
                  <GoogleSelectItem value="Yes">School Transport</GoogleSelectItem>
                </GoogleSelect>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {/* AI Fee Detection */}
      <div className="mt-6">
        <StudentAIFeeDetector
          selectedClass={selectedClass || ''}
          boardingStatus={boardingStatus || 'Day'}
          transportUse={transportUse || 'No'}
        />
      </div>
    </div>
  );
};

export default EnrollmentSection;
