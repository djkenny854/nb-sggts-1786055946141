import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Users, Mail, Phone, MessageSquare, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { ScrollArea } from '@/components/ui/scroll-area';
import AISkeleton from '@/components/ui/ai-skeleton';
import AITextAnimation from '@/components/ui/ai-text-animation';
import { Checkbox } from '@/components/ui/checkbox';

interface Recipient {
  id: string;
  name: string;
  contact: string;
  type: 'student' | 'teacher';
}

interface RecipientsListProps {
  selectedGroups: string[];
  channel: 'sms' | 'email' | 'whatsapp';
  groups: Array<{
    id: string;
    name: string;
    group_type: string;
    is_dynamic?: boolean;
    member_ids: string[];
  }>;
  onRecipientsChange?: (recipients: string[]) => void;
}

const RecipientsList: React.FC<RecipientsListProps> = ({
  selectedGroups,
  channel,
  groups,
  onRecipientsChange
}) => {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const loadingTexts = [
    'Fetching recipients...',
    'Loading contacts...',
    'Gathering member data...',
    'Preparing recipient list...'
  ];

  useEffect(() => {
    if (selectedGroups.length === 0) {
      setRecipients([]);
      setSelectedRecipients([]);
      return;
    }
    fetchRecipients();
  }, [selectedGroups, channel]);

  const fetchRecipients = async () => {
    setLoading(true);
    const allRecipients: Recipient[] = [];

    try {
      console.log('Fetching recipients for groups:', selectedGroups);
      console.log('Channel:', channel);
      console.log('Groups data:', groups);

      for (const groupId of selectedGroups) {
        const group = groups.find(g => g.id === groupId);
        if (!group) {
          console.log('Group not found:', groupId);
          continue;
        }

        console.log('Processing group:', group);
        const isTeacherGroup = group.group_type?.toLowerCase().includes('teacher');
        const table = isTeacherGroup ? 'teachers' : 'students';
        const field = channel === 'email' ? 'email' : (isTeacherGroup ? 'phone' : 'parent_contact');

        console.log(`Querying ${table} table for ${field}`);

        // Fetch data based on dynamic or static group
        let data: any = null;
        if (!group.is_dynamic && group.member_ids && group.member_ids.length > 0) {
          console.log('Fetching static group members:', group.member_ids);
          
          // For students, use first_name and last_name instead of name
          if (table === 'students') {
            const result = await supabase
              .from(table as any)
              .select(`id, first_name, last_name, ${field}`)
              .in('id', group.member_ids)
              .not(field, 'is', null)
              .neq(field, '');
            
            if (result.error) {
              console.error('Query error:', result.error);
            }
            data = result.data;
          } else {
            const result = await supabase
              .from(table as any)
              .select(`id, name, ${field}`)
              .in('id', group.member_ids)
              .not(field, 'is', null)
              .neq(field, '');
            
            if (result.error) {
              console.error('Query error:', result.error);
            }
            data = result.data;
          }
          console.log('Static group result:', data);
        } else {
          console.log('Fetching dynamic group members');
          
          // For students, use first_name and last_name instead of name
          if (table === 'students') {
            const result = await supabase
              .from(table as any)
              .select(`id, first_name, last_name, ${field}`)
              .not(field, 'is', null)
              .neq(field, '');
            
            if (result.error) {
              console.error('Query error:', result.error);
            }
            data = result.data;
          } else {
            const result = await supabase
              .from(table as any)
              .select(`id, name, ${field}`)
              .not(field, 'is', null)
              .neq(field, '');
            
            if (result.error) {
              console.error('Query error:', result.error);
            }
            data = result.data;
          }
          console.log('Dynamic group result:', data);
        }

        if (data && data.length > 0) {
          const mappedRecipients: Recipient[] = data.map((r: any) => ({
            id: r.id,
            name: table === 'students' 
              ? `${r.first_name || ''} ${r.last_name || ''}`.trim() || 'Unknown'
              : r.name || 'Unknown',
            contact: r[field] || '',
            type: (isTeacherGroup ? 'teacher' : 'student') as 'student' | 'teacher'
          }));
          console.log('Mapped recipients:', mappedRecipients);
          allRecipients.push(...mappedRecipients);
        } else {
          console.log('No data returned for group:', group.name);
        }
      }

      // Remove duplicates based on contact
      const uniqueRecipients = allRecipients.filter(
        (recipient, index, self) =>
          index === self.findIndex((r) => r.contact === recipient.contact)
      );

      setRecipients(uniqueRecipients);
      
      // Auto-select all recipients initially
      const allIds = uniqueRecipients.map(r => r.id);
      setSelectedRecipients(allIds);
      onRecipientsChange?.(allIds);
    } catch (error) {
      console.error('Error fetching recipients:', error);
      setRecipients([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRecipientToggle = (recipientId: string) => {
    const newSelected = selectedRecipients.includes(recipientId)
      ? selectedRecipients.filter(id => id !== recipientId)
      : [...selectedRecipients, recipientId];
    
    setSelectedRecipients(newSelected);
    onRecipientsChange?.(newSelected);
  };

  const handleSelectAll = (checked: boolean | 'indeterminate') => {
    if (checked === true) {
      const allIds = filteredRecipients.map(r => r.id);
      setSelectedRecipients(allIds);
      onRecipientsChange?.(allIds);
    } else {
      setSelectedRecipients([]);
      onRecipientsChange?.([]);
    }
  };

  const filteredRecipients = recipients.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.contact.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getChannelIcon = () => {
    switch (channel) {
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'sms':
        return <Phone className="h-4 w-4" />;
      case 'whatsapp':
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3 space-y-3">
        <CardTitle className="flex items-center justify-between gap-2 text-lg">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Recipients
          </div>
          {recipients.length > 0 && (
            <Badge variant="secondary" className="gap-1">
              {selectedRecipients.length}/{recipients.length}
            </Badge>
          )}
        </CardTitle>
        {recipients.length > 0 && (
          <>
            <Input
              placeholder="Search recipients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8 text-xs"
            />
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="select-all"
                  checked={selectedRecipients.length === filteredRecipients.length && filteredRecipients.length > 0}
                  onCheckedChange={handleSelectAll}
                />
                <label
                  htmlFor="select-all"
                  className="text-xs font-medium cursor-pointer"
                >
                  Select All
                </label>
              </div>
              <span className="text-xs text-muted-foreground">
                Showing {filteredRecipients.length} of {recipients.length}
              </span>
            </div>
          </>
        )}
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden pb-2">
        {loading ? (
          <div className="space-y-4">
            <AITextAnimation 
              texts={loadingTexts}
              className="text-sm text-primary"
              interval={1500}
            />
            <AISkeleton lines={5} message="Loading recipients..." />
          </div>
        ) : recipients.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <Users className="h-12 w-12 text-muted-foreground/50 mb-3" />
            <p className="text-sm text-muted-foreground">
              {selectedGroups.length === 0 
                ? 'Select recipient groups to see the list'
                : `No ${channel} contacts found in selected groups`}
            </p>
          </div>
        ) : (
          <div className="h-full overflow-auto pr-4">
            <div className="space-y-2">{filteredRecipients.map((recipient) => {
                const isSelected = selectedRecipients.includes(recipient.id);
                return (
                  <div
                    key={recipient.id}
                    className={`flex items-start gap-2 p-2 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-primary bg-primary/5'
                        : 'border-border bg-background hover:bg-muted/50'
                    }`}
                    onClick={() => handleRecipientToggle(recipient.id)}
                  >
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={() => handleRecipientToggle(recipient.id)}
                      className="mt-0.5"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-xs font-medium truncate">
                          {recipient.name}
                        </p>
                        <Badge
                          variant={recipient.type === 'teacher' ? 'default' : 'secondary'}
                          className="text-[10px] h-4 px-1.5 flex-shrink-0"
                        >
                          {recipient.type}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                        {getChannelIcon()}
                        <span className="truncate">{recipient.contact}</span>
                      </div>
                    </div>
                    {isSelected && (
                      <CheckCircle2 className="h-3.5 w-3.5 text-primary flex-shrink-0 mt-0.5" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecipientsList;
