
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Settings, Mail, MessageSquare, Smartphone, TestTube, CheckCircle, XCircle } from 'lucide-react';
import { MessagingService } from '@/utils/messagingService';
import { CommunicationSettings } from '@/types/messaging';
import { useToast } from '@/hooks/use-toast';
import { useMobile } from '@/hooks/use-mobile';

const CommunicationSettingsPanel = () => {
  const [settings, setSettings] = useState<CommunicationSettings[]>([]);
  const [loading, setLoading] = useState(true);
  const [testResults, setTestResults] = useState<Record<string, boolean>>({});
  const { toast } = useToast();
  const isMobile = useMobile();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const settingsData = await MessagingService.fetchCommunicationSettings();
      setSettings(settingsData);
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (settingId: string, configuration: Record<string, any>, isActive?: boolean) => {
    try {
      const success = await MessagingService.updateCommunicationSettings(settingId, configuration, isActive);
      if (success) {
        toast({
          title: "Success",
          description: "Settings updated successfully.",
        });
        loadSettings();
      }
    } catch (error) {
      console.error('Error updating settings:', error);
      toast({
        title: "Error",
        description: "Failed to update settings.",
        variant: "destructive",
      });
    }
  };

  const testConfiguration = async (settingType: string) => {
    // Mock test functionality - in real implementation, this would call edge functions
    setTestResults(prev => ({ ...prev, [settingType]: false }));
    
    setTimeout(() => {
      const isSuccess = Math.random() > 0.3; // Simulate 70% success rate
      setTestResults(prev => ({ ...prev, [settingType]: isSuccess }));
      
      toast({
        title: isSuccess ? "Test Successful" : "Test Failed",
        description: isSuccess 
          ? `${settingType} configuration is working correctly.`
          : `${settingType} configuration test failed. Please check your settings.`,
        variant: isSuccess ? "default" : "destructive",
      });
    }, 2000);
  };

  const EmailProviderSettings = ({ setting }: { setting: CommunicationSettings }) => {
    const [config, setConfig] = useState(setting.configuration);

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Email Provider Settings
            </CardTitle>
            <div className="flex items-center gap-2">
              <Switch
                checked={setting.is_active}
                onCheckedChange={(checked) => updateSetting(setting.id, config, checked)}
              />
              <Badge variant={setting.is_active ? "default" : "secondary"}>
                {setting.is_active ? "Active" : "Inactive"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Sender Name</Label>
              <Input
                value={config.sender_name || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, sender_name: e.target.value }))}
                placeholder="School Name"
              />
            </div>
            <div className="space-y-2">
              <Label>Sender Email</Label>
              <Input
                type="email"
                value={config.sender_email || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, sender_email: e.target.value }))}
                placeholder="noreply@school.edu"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>API Key</Label>
            <Input
              type="password"
              value={config.api_key || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, api_key: e.target.value }))}
              placeholder="Enter your SendGrid API key"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={() => updateSetting(setting.id, config)}>
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={() => testConfiguration('email')}
              disabled={testResults.email === false}
            >
              <TestTube className="h-4 w-4 mr-2" />
              {testResults.email === false ? 'Testing...' : 'Test Configuration'}
            </Button>
            {testResults.email !== undefined && (
              testResults.email ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const SMSProviderSettings = ({ setting }: { setting: CommunicationSettings }) => {
    const [config, setConfig] = useState(setting.configuration);

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="h-5 w-5" />
              SMS Provider Settings
            </CardTitle>
            <div className="flex items-center gap-2">
              <Switch
                checked={setting.is_active}
                onCheckedChange={(checked) => updateSetting(setting.id, config, checked)}
              />
              <Badge variant={setting.is_active ? "default" : "secondary"}>
                {setting.is_active ? "Active" : "Inactive"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Account SID</Label>
              <Input
                value={config.account_sid || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, account_sid: e.target.value }))}
                placeholder="Twilio Account SID"
              />
            </div>
            <div className="space-y-2">
              <Label>Auth Token</Label>
              <Input
                type="password"
                value={config.auth_token || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, auth_token: e.target.value }))}
                placeholder="Twilio Auth Token"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>From Number</Label>
            <Input
              value={config.from_number || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, from_number: e.target.value }))}
              placeholder="+1234567890"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={() => updateSetting(setting.id, config)}>
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={() => testConfiguration('sms')}
              disabled={testResults.sms === false}
            >
              <TestTube className="h-4 w-4 mr-2" />
              {testResults.sms === false ? 'Testing...' : 'Test Configuration'}
            </Button>
            {testResults.sms !== undefined && (
              testResults.sms ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const WhatsAppSettings = ({ setting }: { setting: CommunicationSettings }) => {
    const [config, setConfig] = useState(setting.configuration);

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              WhatsApp Business Settings
            </CardTitle>
            <div className="flex items-center gap-2">
              <Switch
                checked={setting.is_active}
                onCheckedChange={(checked) => updateSetting(setting.id, config, checked)}
              />
              <Badge variant={setting.is_active ? "default" : "secondary"}>
                {setting.is_active ? "Active" : "Inactive"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Access Token</Label>
              <Input
                type="password"
                value={config.access_token || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, access_token: e.target.value }))}
                placeholder="WhatsApp Business Access Token"
              />
            </div>
            <div className="space-y-2">
              <Label>Phone Number ID</Label>
              <Input
                value={config.phone_number_id || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, phone_number_id: e.target.value }))}
                placeholder="WhatsApp Phone Number ID"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Webhook Verify Token</Label>
            <Input
              value={config.webhook_verify_token || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, webhook_verify_token: e.target.value }))}
              placeholder="Webhook verification token"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={() => updateSetting(setting.id, config)}>
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={() => testConfiguration('whatsapp')}
              disabled={testResults.whatsapp === false}
            >
              <TestTube className="h-4 w-4 mr-2" />
              {testResults.whatsapp === false ? 'Testing...' : 'Test Configuration'}
            </Button>
            {testResults.whatsapp !== undefined && (
              testResults.whatsapp ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const GeneralSettings = ({ setting }: { setting: CommunicationSettings }) => {
    const [config, setConfig] = useState(setting.configuration);

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            General Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>School Name</Label>
              <Input
                value={config.school_name || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, school_name: e.target.value }))}
                placeholder="Enter school name"
              />
            </div>
            <div className="space-y-2">
              <Label>Contact Number</Label>
              <Input
                value={config.contact_number || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, contact_number: e.target.value }))}
                placeholder="+1234567890"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Default Sender</Label>
            <Input
              value={config.default_sender || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, default_sender: e.target.value }))}
              placeholder="School"
            />
          </div>

          <Button onClick={() => updateSetting(setting.id, config)}>
            Save General Settings
          </Button>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Communication Settings</h3>
        <p className="text-muted-foreground">
          Configure SMS, email, and WhatsApp provider settings for messaging
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">
            <Settings className="h-4 w-4" />
            {!isMobile && <span className="ml-2">General</span>}
          </TabsTrigger>
          <TabsTrigger value="email">
            <Mail className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Email</span>}
          </TabsTrigger>
          <TabsTrigger value="sms">
            <Smartphone className="h-4 w-4" />
            {!isMobile && <span className="ml-2">SMS</span>}
          </TabsTrigger>
          <TabsTrigger value="whatsapp">
            <MessageSquare className="h-4 w-4" />
            {!isMobile && <span className="ml-2">WhatsApp</span>}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          {settings.find(s => s.setting_type === 'general') && (
            <GeneralSettings setting={settings.find(s => s.setting_type === 'general')!} />
          )}
        </TabsContent>

        <TabsContent value="email">
          {settings.find(s => s.setting_type === 'email_provider') && (
            <EmailProviderSettings setting={settings.find(s => s.setting_type === 'email_provider')!} />
          )}
        </TabsContent>

        <TabsContent value="sms">
          {settings.find(s => s.setting_type === 'sms_provider') && (
            <SMSProviderSettings setting={settings.find(s => s.setting_type === 'sms_provider')!} />
          )}
        </TabsContent>

        <TabsContent value="whatsapp">
          {settings.find(s => s.setting_type === 'whatsapp_config') && (
            <WhatsAppSettings setting={settings.find(s => s.setting_type === 'whatsapp_config')!} />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CommunicationSettingsPanel;
