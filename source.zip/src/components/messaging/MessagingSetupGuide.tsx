import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, CheckCircle, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

const MessagingSetupGuide = () => {
  return (
    <div className="space-y-6">
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Follow these steps to configure messaging. Each provider requires API credentials from their platform.
        </AlertDescription>
      </Alert>

      {/* EMAIL SETUP - SendGrid */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge>1</Badge> Email Setup (SendGrid)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 1: Create SendGrid Account</p>
                <p className="text-sm text-muted-foreground">Visit SendGrid and create a free account</p>
                <a 
                  href="https://signup.sendgrid.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Go to SendGrid Signup <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 2: Verify Your Domain/Email</p>
                <p className="text-sm text-muted-foreground">Verify your sender email or domain to avoid spam filters</p>
                <a 
                  href="https://app.sendgrid.com/settings/sender_auth" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Domain Authentication <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 3: Create API Key</p>
                <p className="text-sm text-muted-foreground">Generate an API key with "Full Access" permissions</p>
                <a 
                  href="https://app.sendgrid.com/settings/api_keys" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Create API Key <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 4: Configure in Settings</p>
                <ul className="text-sm text-muted-foreground space-y-1 mt-1">
                  <li>• <strong>Sender Name:</strong> Your school name (e.g., "St. Mary's School")</li>
                  <li>• <strong>Sender Email:</strong> Verified email (e.g., "noreply@yourschool.com")</li>
                  <li>• <strong>API Key:</strong> Paste the key from Step 3</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SMS SETUP - Twilio */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge>2</Badge> SMS Setup (Twilio)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 1: Create Twilio Account</p>
                <p className="text-sm text-muted-foreground">Sign up for a Twilio account (free trial available)</p>
                <a 
                  href="https://www.twilio.com/try-twilio" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Try Twilio Free <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 2: Get a Phone Number</p>
                <p className="text-sm text-muted-foreground">Purchase or get a free trial phone number</p>
                <a 
                  href="https://console.twilio.com/us1/develop/phone-numbers/manage/incoming" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Get Phone Number <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 3: Find Your Credentials</p>
                <p className="text-sm text-muted-foreground">Get Account SID and Auth Token from your dashboard</p>
                <a 
                  href="https://console.twilio.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Twilio Console <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 4: Configure in Settings</p>
                <ul className="text-sm text-muted-foreground space-y-1 mt-1">
                  <li>• <strong>Account SID:</strong> Found on dashboard (starts with "AC")</li>
                  <li>• <strong>Auth Token:</strong> Click "Show" on dashboard to reveal</li>
                  <li>• <strong>From Number:</strong> Your Twilio phone number (e.g., "+1234567890")</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* WHATSAPP SETUP */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge>3</Badge> WhatsApp Setup (Meta Business)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 1: Create Meta Business Account</p>
                <p className="text-sm text-muted-foreground">Set up a Meta Business account if you don't have one</p>
                <a 
                  href="https://business.facebook.com/overview" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Meta Business Suite <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 2: Set Up WhatsApp Business API</p>
                <p className="text-sm text-muted-foreground">Apply for WhatsApp Business API access</p>
                <a 
                  href="https://developers.facebook.com/docs/whatsapp/cloud-api/get-started" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  WhatsApp Cloud API Guide <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 3: Get Access Token</p>
                <p className="text-sm text-muted-foreground">Generate a permanent access token from Meta Business</p>
                <a 
                  href="https://developers.facebook.com/apps/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm flex items-center gap-1 mt-1"
                >
                  Meta for Developers <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 4: Configure Webhook</p>
                <p className="text-sm text-muted-foreground">Set up webhook for delivery status (optional but recommended)</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Webhook URL: <code className="bg-muted px-2 py-1 rounded text-xs">
                    https://nwaeyguvhidayxctdvpy.supabase.co/functions/v1/whatsapp-webhook
                  </code>
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">Step 5: Configure in Settings</p>
                <ul className="text-sm text-muted-foreground space-y-1 mt-1">
                  <li>• <strong>Access Token:</strong> From Meta for Developers app dashboard</li>
                  <li>• <strong>Phone Number ID:</strong> Found in WhatsApp Business API settings</li>
                  <li>• <strong>Webhook Verify Token:</strong> Create a random string (e.g., "my_school_webhook_123")</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TESTING */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge>4</Badge> Testing Your Setup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-3">
            <p className="text-sm">After configuring each provider:</p>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-primary">1.</span>
                Click "Save Settings" to store your credentials
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">2.</span>
                Toggle the provider to "Active" using the switch
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">3.</span>
                Click "Test Configuration" to verify it works
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">4.</span>
                Go to "Compose" tab and send a test message
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* IMPORTANT NOTES */}
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <p className="font-semibold mb-2">Important Notes:</p>
          <ul className="text-sm space-y-1">
            <li>• All credentials are stored securely in the database</li>
            <li>• Free tiers available for all providers to test</li>
            <li>• WhatsApp requires business verification for production use</li>
            <li>• Messages are queued and processed automatically</li>
            <li>• Parent contact numbers must include country code (e.g., +256...)</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default MessagingSetupGuide;
