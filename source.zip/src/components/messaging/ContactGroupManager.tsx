import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Users, Edit, Trash2, UserCheck } from 'lucide-react';
import { MessagingService } from '@/utils/messagingService';
import { ContactGroup } from '@/types/messaging';
import { useToast } from '@/hooks/use-toast';

interface ContactGroupManagerProps {
  groups: ContactGroup[];
  onGroupChange: () => void;
}

const ContactGroupManager: React.FC<ContactGroupManagerProps> = ({ groups, onGroupChange }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<ContactGroup | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    group_type: 'custom' as ContactGroup['group_type'],
    is_dynamic: true,
    member_ids: [] as string[],
    criteria: {} as Record<string, any>,
  });
  const [newMemberId, setNewMemberId] = useState('');
  const { toast } = useToast();

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      group_type: 'custom',
      is_dynamic: true,
      member_ids: [],
      criteria: {},
    });
    setNewMemberId('');
    setEditingGroup(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (group: ContactGroup) => {
    setFormData({
      name: group.name,
      description: group.description || '',
      group_type: group.group_type,
      is_dynamic: group.is_dynamic,
      member_ids: [...group.member_ids],
      criteria: { ...group.criteria },
    });
    setEditingGroup(group);
    setIsDialogOpen(true);
  };

  const handleSaveGroup = async () => {
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide a group name.",
        variant: "destructive",
      });
      return;
    }

    try {
      const groupData = {
        name: formData.name,
        description: formData.description,
        group_type: formData.group_type,
        is_dynamic: formData.is_dynamic,
        member_ids: formData.member_ids,
        criteria: formData.criteria,
      };

      if (editingGroup) {
        toast({
          title: "Info",
          description: "Group update functionality not yet implemented.",
        });
      } else {
        const result = await MessagingService.createContactGroup(groupData);
        if (result) {
          toast({
            title: "Success",
            description: "Contact group created successfully.",
          });
          onGroupChange();
          setIsDialogOpen(false);
          resetForm();
        }
      }
    } catch (error) {
      console.error('Error saving group:', error);
      toast({
        title: "Error",
        description: "Failed to save contact group.",
        variant: "destructive",
      });
    }
  };

  const addMember = () => {
    if (newMemberId.trim() && !formData.member_ids.includes(newMemberId.trim())) {
      setFormData(prev => ({
        ...prev,
        member_ids: [...prev.member_ids, newMemberId.trim()]
      }));
      setNewMemberId('');
    }
  };

  const removeMember = (memberId: string) => {
    setFormData(prev => ({
      ...prev,
      member_ids: prev.member_ids.filter(id => id !== memberId)
    }));
  };

  const getGroupTypeIcon = (type: ContactGroup['group_type']) => {
    switch (type) {
      case 'all_parents': return '👨‍👩‍👧‍👦';
      case 'all_teachers': return '👩‍🏫';
      case 'fee_defaulters': return '💰';
      case 'class': return '📚';
      default: return '👥';
    }
  };

  const getGroupTypeColor = (type: ContactGroup['group_type']) => {
    switch (type) {
      case 'all_parents': return 'bg-blue-100 text-blue-800';
      case 'all_teachers': return 'bg-green-100 text-green-800';
      case 'fee_defaulters': return 'bg-red-100 text-red-800';
      case 'class': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Contact Groups</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Create Group
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingGroup ? 'Edit Contact Group' : 'Create New Contact Group'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Group Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter group name"
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe this group"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Group Type</Label>
                <Select 
                  value={formData.group_type} 
                  onValueChange={(value: ContactGroup['group_type']) => setFormData(prev => ({ ...prev, group_type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select group type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="custom">Custom Group</SelectItem>
                    <SelectItem value="class">Class-based Group</SelectItem>
                    <SelectItem value="all_parents">All Parents</SelectItem>
                    <SelectItem value="all_teachers">All Teachers</SelectItem>
                    <SelectItem value="fee_defaulters">Fee Defaulters</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.is_dynamic}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_dynamic: checked }))}
                />
                <Label>Dynamic Group (auto-updates membership)</Label>
              </div>

              {!formData.is_dynamic && (
                <div className="space-y-2">
                  <Label>Static Members</Label>
                  <div className="flex gap-2">
                    <Input
                      value={newMemberId}
                      onChange={(e) => setNewMemberId(e.target.value)}
                      placeholder="Add member ID"
                      onKeyPress={(e) => e.key === 'Enter' && addMember()}
                    />
                    <Button type="button" onClick={addMember}>Add</Button>
                  </div>
                  <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                    {formData.member_ids.map((memberId) => (
                      <Badge key={memberId} variant="secondary" className="cursor-pointer" onClick={() => removeMember(memberId)}>
                        {memberId} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveGroup}>
                  {editingGroup ? 'Update' : 'Create'} Group
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups.map((group) => (
          <Card key={group.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getGroupTypeIcon(group.group_type)}</span>
                  <div>
                    <CardTitle className="text-sm">{group.name}</CardTitle>
                    <Badge className={`text-xs ${getGroupTypeColor(group.group_type)}`}>
                      {group.group_type.replace('_', ' ').toUpperCase()}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => openEditDialog(group)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {group.description && (
                <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                  {group.description}
                </p>
              )}
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-3 w-3" />
                <span className="text-xs">
                  {group.is_dynamic ? 'Dynamic' : `${group.member_ids.length} members`}
                </span>
                {group.is_dynamic && (
                  <Badge variant="outline" className="text-xs">
                    Auto-update
                  </Badge>
                )}
              </div>
              <div className="text-xs text-muted-foreground">
                Created {new Date(group.created_at).toLocaleDateString()}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {groups.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">
              No contact groups found. Create your first group to organize recipients.
            </p>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Group
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ContactGroupManager;
