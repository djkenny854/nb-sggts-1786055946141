import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, DollarSign, Users, MessageSquare } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';

interface StudentFeeAlertsProps {
  onSendReminder?: (studentIds: string[]) => void;
}

const StudentFeeAlerts: React.FC<StudentFeeAlertsProps> = ({ onSendReminder }) => {
  const { data: unpaidStudents, isLoading } = useQuery({
    queryKey: ['unpaid-students'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('student_fees')
        .select(`
          *,
          students!inner(
            id,
            full_name,
            class,
            parent_contact,
            fee_status
          )
        `)
        .in('payment_status', ['Unpaid', 'Partial'])
        .order('balance', { ascending: false });

      if (error) throw error;
      return data || [];
    }
  });

  const currentMonth = format(new Date(), 'MMMM yyyy');
  const unpaidThisMonth = unpaidStudents?.filter(student => 
    student.academic_year === new Date().getFullYear().toString() &&
    student.payment_status !== 'Paid'
  ) || [];

  const totalOutstanding = unpaidStudents?.reduce((sum, student) => 
    sum + (student.balance || 0), 0) || 0;

  const handleSendBulkReminder = () => {
    const studentIds = unpaidThisMonth.map(student => student.students.id);
    onSendReminder?.(studentIds);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Fee Payment Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-orange-500" />
          Fee Payment Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-destructive/10 p-3 rounded-lg border border-destructive/20">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-destructive" />
              <div>
                <p className="text-sm text-destructive">Unpaid This Month</p>
                <p className="text-xl font-bold text-destructive">{unpaidThisMonth.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-orange-500/10 p-3 rounded-lg border border-orange-500/20">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-orange-500" />
              <div>
                <p className="text-sm text-orange-600 dark:text-orange-400">Outstanding Amount</p>
                <p className="text-xl font-bold text-orange-600 dark:text-orange-400">
                  UGX {totalOutstanding.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-primary/10 p-3 rounded-lg border border-primary/20">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              <div>
                <p className="text-sm text-primary">Action Required</p>
                <Button 
                  size="sm" 
                  onClick={handleSendBulkReminder}
                  className="mt-1"
                  disabled={unpaidThisMonth.length === 0}
                >
                  Send Reminders
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Top Unpaid Students */}
        {unpaidStudents && unpaidStudents.length > 0 && (
          <div>
            <h4 className="font-semibold mb-3">Students with Outstanding Balances</h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {unpaidStudents.slice(0, 10).map((student) => (
                <div key={student.id} className="flex justify-between items-center p-2 bg-secondary rounded">
                  <div>
                    <p className="font-medium text-foreground">{student.students.full_name}</p>
                    <p className="text-sm text-muted-foreground">
                      {student.students.class} • {student.academic_term} {student.academic_year}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant={student.payment_status === 'Unpaid' ? 'destructive' : 'secondary'}>
                      {student.payment_status}
                    </Badge>
                    <p className="text-sm font-medium text-destructive mt-1">
                      UGX {(student.balance || 0).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {unpaidStudents.length > 10 && (
              <p className="text-sm text-muted-foreground mt-2 text-center">
                ... and {unpaidStudents.length - 10} more students
              </p>
            )}
          </div>
        )}

        {(!unpaidStudents || unpaidStudents.length === 0) && (
          <div className="text-center py-6 text-muted-foreground">
            <DollarSign className="h-12 w-12 mx-auto mb-2 text-muted" />
            <p>No outstanding fee balances</p>
            <p className="text-sm">All students are up to date with their payments!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StudentFeeAlerts;
