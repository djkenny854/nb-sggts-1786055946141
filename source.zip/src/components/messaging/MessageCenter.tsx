
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MessageSquare, Send, Users, Settings, BarChart3, RefreshCw, BookOpen } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMobile } from '@/hooks/use-mobile';
import MessageComposer from './MessageComposer';
import MessageList from './MessageList';
import ContactGroupManager from './ContactGroupManager';
import MessageTemplateManager from './MessageTemplateManager';
import CommunicationSettingsPanel from './CommunicationSettingsPanel';
import MessageAnalytics from './MessageAnalytics';
import EnhancedMessageComposer from './EnhancedMessageComposer';
import MessagingSetupGuide from './MessagingSetupGuide';
import { MessageQueueService } from '@/utils/messageQueueService';
import { Message, ContactGroup, MessageTemplate } from '@/types/messaging';

const MessageCenter: React.FC = () => {
  const { toast } = useToast();
  const isMobile = useMobile();
  const [messages, setMessages] = useState<Message[]>([]);
  const [contactGroups, setContactGroups] = useState<ContactGroup[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [queueStatus, setQueueStatus] = useState({
    queued: 0,
    processing: 0,
    sent: 0,
    failed: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    loadQueueStatus();
    
    // Poll queue status every 30 seconds
    const interval = setInterval(loadQueueStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load messages
      const { data: messagesData, error: messagesError } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (messagesError) throw messagesError;
      
      // Transform database messages to match Message type with proper type casting
      const transformedMessages: Message[] = (messagesData || []).map(msg => ({
        ...msg,
        channel: msg.channel as 'sms' | 'email' | 'whatsapp', // Type cast
        recipient_type: msg.recipient_type as 'individual' | 'group' | 'broadcast', // Type cast
        status: msg.status as 'pending' | 'sent' | 'delivered' | 'failed' | 'cancelled', // Type cast
        delivery_status: (msg.delivery_status as Record<string, any>) || {},
        metadata: (msg.metadata as Record<string, any>) || {},
        updated_at: msg.updated_at || msg.created_at
      }));
      setMessages(transformedMessages);

      // Load contact groups
      const { data: groupsData, error: groupsError } = await supabase
        .from('contact_groups')
        .select('*')
        .order('name');

      if (groupsError) throw groupsError;
      
      // Transform database groups to match ContactGroup type with proper type casting
      const transformedGroups: ContactGroup[] = (groupsData || []).map(group => ({
        ...group,
        group_type: group.group_type as 'class' | 'custom' | 'all_parents' | 'all_teachers' | 'fee_defaulters', // Type cast
        criteria: (group.criteria as Record<string, any>) || {},
        member_ids: group.member_ids || [],
        is_dynamic: group.is_dynamic || false,
        description: group.description || undefined
      }));
      setContactGroups(transformedGroups);

      // Load templates
      const { data: templatesData, error: templatesError } = await supabase
        .from('message_templates')
        .select('*')
        .order('category');

      if (templatesError) throw templatesError;
      
      // Transform database templates to match MessageTemplate type with proper type casting
      const transformedTemplates: MessageTemplate[] = (templatesData || []).map(template => ({
        ...template,
        category: template.category as 'fee_reminder' | 'attendance_alert' | 'exam_result' | 'event_reminder' | 'announcement' | 'custom', // Type cast
        variables: template.variables || [],
        channels: template.channels || [],
        is_default: template.is_default || false
      }));
      setTemplates(transformedTemplates);

    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Error",
        description: "Failed to load messaging data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadQueueStatus = async () => {
    try {
      const status = await MessageQueueService.getQueueStatus();
      setQueueStatus(status);
    } catch (error) {
      console.error('Error loading queue status:', error);
    }
  };

  const processQueue = async () => {
    try {
      const result = await MessageQueueService.processQueue();
      
      toast({
        title: result.success ? "Queue Processed" : "Process Failed",
        description: result.success 
          ? `Processed ${result.processed} messages`
          : "Failed to process message queue",
        variant: result.success ? "default" : "destructive",
      });

      if (result.success) {
        loadQueueStatus();
        loadData();
      }
    } catch (error) {
      console.error('Error processing queue:', error);
      toast({
        title: "Error",
        description: "Failed to process message queue.",
        variant: "destructive",
      });
    }
  };

  const retryFailedMessages = async () => {
    try {
      const success = await MessageQueueService.retryFailedMessages();
      
      toast({
        title: success ? "Retry Initiated" : "Retry Failed",
        description: success 
          ? "Failed messages have been queued for retry"
          : "Failed to retry messages",
        variant: success ? "default" : "destructive",
      });

      if (success) {
        loadQueueStatus();
      }
    } catch (error) {
      console.error('Error retrying failed messages:', error);
      toast({
        title: "Error",
        description: "Failed to retry messages.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
          <p>Loading messaging center...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Queued</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{queueStatus.queued}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Processing</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {queueStatus.processing}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sent</CardTitle>
            <Send className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {queueStatus.sent}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed</CardTitle>
            <Badge variant="destructive" className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-red-600">
                {queueStatus.failed}
              </div>
              {queueStatus.failed > 0 && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={retryFailedMessages}
                >
                  Retry
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Queue Actions */}
      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          <Button onClick={processQueue} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Process Queue
          </Button>
          <Button onClick={loadQueueStatus} variant="ghost">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Status
          </Button>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="setup" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6 bg-transparent border-b border-border rounded-none p-0 h-auto">
          <TabsTrigger value="setup" className="data-[state=active]:bg-transparent">
            <BookOpen className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Setup</span>}
          </TabsTrigger>
          <TabsTrigger value="compose" className="data-[state=active]:bg-transparent">
            <Send className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Compose</span>}
          </TabsTrigger>
          <TabsTrigger value="messages" className="data-[state=active]:bg-transparent">
            <MessageSquare className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Messages</span>}
          </TabsTrigger>
          <TabsTrigger value="templates" className="data-[state=active]:bg-transparent">
            <BookOpen className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Templates</span>}
          </TabsTrigger>
          <TabsTrigger value="contacts" className="data-[state=active]:bg-transparent">
            <Users className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Groups</span>}
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-transparent">
            <Settings className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Settings</span>}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="setup">
          <MessagingSetupGuide />
        </TabsContent>

        <TabsContent value="compose">
          <EnhancedMessageComposer
            templates={templates}
            groups={contactGroups}
            onMessageSent={loadData}
          />
        </TabsContent>

        <TabsContent value="messages">
          <MessageList messages={messages} onRefresh={loadData} />
        </TabsContent>

        <TabsContent value="contacts">
          <ContactGroupManager groups={contactGroups} onGroupChange={loadData} />
        </TabsContent>

        <TabsContent value="templates">
          <MessageTemplateManager templates={templates} onTemplateChange={loadData} />
        </TabsContent>

        <TabsContent value="settings">
          <CommunicationSettingsPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MessageCenter;
