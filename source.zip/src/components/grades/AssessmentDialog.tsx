import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { createAssessment, updateAssessment, getAssessmentCategories } from '@/utils/gradingService';
import { supabase } from '@/integrations/supabase/client';
import type { Assessment, AssessmentCategory, AssessmentType } from '@/types/grading';

interface AssessmentDialogProps {
  assessment?: Assessment | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: () => void;
}

const AssessmentDialog: React.FC<AssessmentDialogProps> = ({
  assessment,
  open,
  onOpenChange,
  onSave
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subject_id: '',
    class_name: '',
    assessment_type: 'assignment' as AssessmentType,
    category_id: '',
    total_marks: 100,
    due_date: null as Date | null,
    assessment_date: new Date(),
    is_published: false,
    instructions: '',
    academic_year: '2024',
    academic_term: 'Term 1'
  });
  const [loading, setLoading] = useState(false);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [categories, setCategories] = useState<AssessmentCategory[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadData();
      if (assessment) {
        setFormData({
          title: assessment.title,
          description: assessment.description || '',
          subject_id: assessment.subject_id || '',
          class_name: assessment.class_name,
          assessment_type: assessment.assessment_type,
          category_id: assessment.category_id || '',
          total_marks: assessment.total_marks,
          due_date: assessment.due_date ? new Date(assessment.due_date) : null,
          assessment_date: new Date(assessment.assessment_date),
          is_published: assessment.is_published,
          instructions: assessment.instructions || '',
          academic_year: assessment.academic_year,
          academic_term: assessment.academic_term
        });
      } else {
        setFormData({
          title: '',
          description: '',
          subject_id: '',
          class_name: '',
          assessment_type: 'assignment',
          category_id: '',
          total_marks: 100,
          due_date: null,
          assessment_date: new Date(),
          is_published: false,
          instructions: '',
          academic_year: '2024',
          academic_term: 'Term 1'
        });
      }
    }
  }, [open, assessment]);

  const loadData = async () => {
    try {
      // Load subjects
      const { data: subjectsData } = await supabase
        .from('enhanced_subjects')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      setSubjects(subjectsData || []);

      // Load categories
      const categoriesData = await getAssessmentCategories();
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = {
        ...formData,
        due_date: formData.due_date ? format(formData.due_date, 'yyyy-MM-dd') : null,
        assessment_date: format(formData.assessment_date, 'yyyy-MM-dd'),
        created_by: 'System' // Replace with actual user
      };

      if (assessment) {
        await updateAssessment(assessment.id, data);
        toast({
          title: "Success",
          description: "Assessment updated successfully"
        });
      } else {
        await createAssessment(data);
        toast({
          title: "Success",
          description: "Assessment created successfully"
        });
      }

      onSave();
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save assessment",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const assessmentTypes: { value: AssessmentType; label: string }[] = [
    { value: 'exam', label: 'Exam' },
    { value: 'assignment', label: 'Assignment' },
    { value: 'test', label: 'Test' },
    { value: 'quiz', label: 'Quiz' },
    { value: 'project', label: 'Project' },
    { value: 'presentation', label: 'Presentation' },
    { value: 'practical', label: 'Practical' },
    { value: 'homework', label: 'Homework' },
    { value: 'classwork', label: 'Classwork' },
    { value: 'other', label: 'Other' }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {assessment ? 'Edit Assessment' : 'Create New Assessment'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Assessment Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Assessment Type *</Label>
              <Select
                value={formData.assessment_type}
                onValueChange={(value: AssessmentType) => setFormData({ ...formData, assessment_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {assessmentTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="subject">Subject</Label>
              <Select
                value={formData.subject_id}
                onValueChange={(value) => setFormData({ ...formData, subject_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject.id} value={subject.id}>
                      {subject.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="class">Class *</Label>
              <Input
                id="class"
                value={formData.class_name}
                onChange={(e) => setFormData({ ...formData, class_name: e.target.value })}
                placeholder="e.g., Grade 10A"
                required
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={formData.category_id}
                onValueChange={(value) => setFormData({ ...formData, category_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="marks">Total Marks *</Label>
              <Input
                id="marks"
                type="number"
                min="1"
                max="1000"
                value={formData.total_marks}
                onChange={(e) => setFormData({ ...formData, total_marks: parseInt(e.target.value) || 0 })}
                required
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Assessment Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.assessment_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.assessment_date ? (
                      format(formData.assessment_date, "PPP")
                    ) : (
                      <span>Pick a date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.assessment_date}
                    onSelect={(date) => setFormData({ ...formData, assessment_date: date || new Date() })}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Due Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.due_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.due_date ? (
                      format(formData.due_date, "PPP")
                    ) : (
                      <span>Pick a date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.due_date}
                    onSelect={(date) => setFormData({ ...formData, due_date: date })}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instructions">Instructions</Label>
            <Textarea
              id="instructions"
              value={formData.instructions}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              rows={3}
              placeholder="Special instructions for students..."
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="published"
              checked={formData.is_published}
              onCheckedChange={(checked) => setFormData({ ...formData, is_published: checked })}
            />
            <Label htmlFor="published">Publish Assessment</Label>
          </div>

          <div className="flex gap-3 justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : (assessment ? 'Update' : 'Create')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AssessmentDialog;