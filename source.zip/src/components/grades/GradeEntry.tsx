import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { getAssessments, getAssessmentGrades, saveGrades } from '@/utils/gradingService';
import { supabase } from '@/integrations/supabase/client';
import type { Assessment, AssessmentGrade } from '@/types/grading';

const GradeEntry = () => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [selectedAssessment, setSelectedAssessment] = useState<string>('');
  const [students, setStudents] = useState<any[]>([]);
  const [grades, setGrades] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAssessments();
  }, []);

  useEffect(() => {
    if (selectedAssessment) {
      loadStudentsAndGrades();
    }
  }, [selectedAssessment]);

  const loadAssessments = async () => {
    try {
      const data = await getAssessments({
        academic_year: '2024',
        academic_term: 'Term 1'
      }).then(assessments => assessments.filter(a => a.is_published));
      setAssessments(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load assessments",
        variant: "destructive"
      });
    }
  };

  const loadStudentsAndGrades = async () => {
    if (!selectedAssessment) return;
    
    setLoading(true);
    try {
      const assessment = assessments.find(a => a.id === selectedAssessment);
      if (!assessment) return;

      // Load students for the class
      const { data: studentsData } = await supabase
        .from('students')
        .select('id, full_name, student_id')
        .eq('class', assessment.class_name)
        .order('full_name');

      setStudents(studentsData || []);

      // Load existing grades
      const existingGrades = await getAssessmentGrades(selectedAssessment);
      const gradesMap = existingGrades.reduce((acc, grade) => {
        acc[grade.student_id] = {
          id: grade.id,
          marks_obtained: grade.marks_obtained,
          teacher_comment: grade.teacher_comment || '',
          is_absent: grade.is_absent,
          late_submission: grade.late_submission,
          graded_at: grade.graded_at
        };
        return acc;
      }, {} as Record<string, any>);

      setGrades(gradesMap);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load students and grades",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateGrade = (studentId: string, field: string, value: any) => {
    setGrades(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: value
      }
    }));
  };

  const calculatePercentage = (marks: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((marks / total) * 100 * 100) / 100;
  };

  const getGrade = (percentage: number) => {
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  };

  const handleSaveGrades = async () => {
    if (!selectedAssessment) return;
    
    setSaving(true);
    try {
      const assessment = assessments.find(a => a.id === selectedAssessment);
      if (!assessment) return;

      const gradesToSave = Object.entries(grades).map(([studentId, gradeData]) => ({
        ...(gradeData.id ? { id: gradeData.id } : {}),
        assessment_id: selectedAssessment,
        student_id: studentId,
        marks_obtained: gradeData.marks_obtained || 0,
        total_marks: assessment.total_marks,
        teacher_comment: gradeData.teacher_comment || '',
        is_absent: gradeData.is_absent || false,
        late_submission: gradeData.late_submission || false,
        graded_at: new Date().toISOString(),
        graded_by: 'System' // Replace with actual user
      }));

      await saveGrades(gradesToSave);
      
      toast({
        title: "Success",
        description: "Grades saved successfully"
      });
      
      // Reload to get updated data
      loadStudentsAndGrades();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save grades",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const selectedAssessmentData = assessments.find(a => a.id === selectedAssessment);
  const gradedCount = Object.values(grades).filter(g => g.marks_obtained !== undefined && !g.is_absent).length;
  const totalStudents = students.length;
  const progress = totalStudents > 0 ? (gradedCount / totalStudents) * 100 : 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Grade Entry</h2>
        <p className="text-muted-foreground">Record and manage assessment grades for students</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Assessment</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedAssessment} onValueChange={setSelectedAssessment}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Choose an assessment to grade" />
            </SelectTrigger>
            <SelectContent>
              {assessments.map(assessment => (
                <SelectItem key={assessment.id} value={assessment.id}>
                  <div className="flex items-center justify-between w-full">
                    <span>{assessment.title} - {assessment.class_name}</span>
                    <Badge variant="outline" className="ml-2">
                      {assessment.assessment_type}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedAssessment && selectedAssessmentData && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>{selectedAssessmentData.title}</CardTitle>
                <p className="text-muted-foreground">
                  {selectedAssessmentData.class_name} • Total Marks: {selectedAssessmentData.total_marks}
                </p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">{gradedCount} / {totalStudents} graded</span>
                </div>
                <Progress value={progress} className="w-32" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 animate-pulse">
                    <div className="h-4 bg-muted rounded w-32"></div>
                    <div className="h-8 bg-muted rounded w-20"></div>
                    <div className="h-8 bg-muted rounded w-16"></div>
                    <div className="h-8 bg-muted rounded flex-1"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-12 gap-4 text-sm font-medium text-muted-foreground border-b pb-2">
                  <div className="col-span-3">Student</div>
                  <div className="col-span-2">Marks</div>
                  <div className="col-span-1">%</div>
                  <div className="col-span-1">Grade</div>
                  <div className="col-span-3">Comment</div>
                  <div className="col-span-1">Absent</div>
                  <div className="col-span-1">Late</div>
                </div>

                {students.map(student => {
                  const studentGrade = grades[student.id] || {};
                  const marks = studentGrade.marks_obtained || 0;
                  const percentage = calculatePercentage(marks, selectedAssessmentData.total_marks);
                  const grade = getGrade(percentage);
                  const isGraded = studentGrade.graded_at;

                  return (
                    <div key={student.id} className="grid grid-cols-12 gap-4 items-center py-2 border-b">
                      <div className="col-span-3 flex items-center gap-2">
                        <span className="font-medium">{student.full_name}</span>
                        <span className="text-sm text-muted-foreground">({student.student_id})</span>
                        {isGraded && <CheckCircle className="h-4 w-4 text-green-600" />}
                      </div>
                      
                      <div className="col-span-2">
                        <Input
                          type="number"
                          min="0"
                          max={selectedAssessmentData.total_marks}
                          value={marks}
                          onChange={(e) => updateGrade(student.id, 'marks_obtained', parseFloat(e.target.value) || 0)}
                          disabled={studentGrade.is_absent}
                          className="w-full"
                        />
                      </div>

                      <div className="col-span-1">
                        <span className="text-sm font-medium">
                          {studentGrade.is_absent ? '-' : `${percentage}%`}
                        </span>
                      </div>

                      <div className="col-span-1">
                        {studentGrade.is_absent ? (
                          <Badge variant="secondary">ABS</Badge>
                        ) : (
                          <Badge variant={grade === 'F' ? 'destructive' : 'default'}>
                            {grade}
                          </Badge>
                        )}
                      </div>

                      <div className="col-span-3">
                        <Input
                          placeholder="Teacher comment..."
                          value={studentGrade.teacher_comment || ''}
                          onChange={(e) => updateGrade(student.id, 'teacher_comment', e.target.value)}
                          className="w-full"
                        />
                      </div>

                      <div className="col-span-1">
                        <Switch
                          checked={studentGrade.is_absent || false}
                          onCheckedChange={(checked) => updateGrade(student.id, 'is_absent', checked)}
                        />
                      </div>

                      <div className="col-span-1">
                        <Switch
                          checked={studentGrade.late_submission || false}
                          onCheckedChange={(checked) => updateGrade(student.id, 'late_submission', checked)}
                        />
                      </div>
                    </div>
                  );
                })}

                <div className="flex justify-end gap-4 pt-4">
                  <Button
                    onClick={handleSaveGrades}
                    disabled={saving}
                    className="min-w-32"
                  >
                    {saving ? 'Saving...' : 'Save All Grades'}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!selectedAssessment && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Clock className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Select an Assessment</h3>
            <p className="text-muted-foreground text-center max-w-sm">
              Choose an assessment from the dropdown above to start entering grades for students.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default GradeEntry;