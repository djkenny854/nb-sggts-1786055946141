
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ExamType, SubjectResult } from '@/types/exam';
import { Student } from '@/types';
import { saveExamResults, calculateGrade, getExams } from '@/utils/examService';
import { toast } from '@/components/ui/use-toast';
import { useData } from '@/context/DataSyncContext';
import { Progress } from '@/components/ui/progress';

const ExamEntryForm = ({ onSuccess }: { onSuccess?: () => void }) => {
  const { students, classes } = useData();
  const [exams, setExams] = useState<ExamType[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedExam, setSelectedExam] = useState<string>('');
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [subjects, setSubjects] = useState<{id: string, name: string}[]>([]);
  const [subjectResults, setSubjectResults] = useState<SubjectResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [examInfo, setExamInfo] = useState<ExamType | null>(null);
  const [classStudents, setClassStudents] = useState<Student[]>([]);

  useEffect(() => {
    const loadExams = async () => {
      try {
        const examsList = await getExams();
        setExams(examsList.filter(exam => exam.isActive));
      } catch (error) {
        console.error('Error loading exams:', error);
      }
    };

    loadExams();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      const filteredStudents = students.filter(student => student.classId === selectedClass);
      setClassStudents(filteredStudents);
      
      // Mock subjects for the selected class
      const mockSubjects = [
        { id: '1', name: 'Mathematics' },
        { id: '2', name: 'English' },
        { id: '3', name: 'Science' },
        { id: '4', name: 'Social Studies' }
      ];
      setSubjects(mockSubjects);
      
      // Initialize subject results
      setSubjectResults(mockSubjects.map(subject => ({
        subjectId: subject.id,
        subjectName: subject.name,
        marks: 0,
        outOf: 100,
        grade: '',
        teacherComment: ''
      })));
    }
  }, [selectedClass, students]);

  useEffect(() => {
    if (selectedExam) {
      const exam = exams.find(e => e.id === selectedExam);
      setExamInfo(exam || null);
    }
  }, [selectedExam, exams]);

  const handleSubjectResultChange = (subjectId: string, field: keyof SubjectResult, value: any) => {
    setSubjectResults(prev => 
      prev.map(result => 
        result.subjectId === subjectId 
          ? { 
              ...result, 
              [field]: value,
              // Recalculate grade if marks changed
              ...(field === 'marks' && examInfo 
                ? { grade: calculateGrade(Number(value), examInfo.gradeScale) } 
                : {})
            } 
          : result
      )
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedExam) {
      toast({
        title: "Validation Error",
        description: "Please select a student and exam",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    setProgress(0);
    
    try {
      // Calculate total and average
      const totalMarks = subjectResults.reduce((sum, subject) => sum + Number(subject.marks), 0);
      const averageMarks = totalMarks / subjectResults.length;
      const grade = examInfo ? calculateGrade(averageMarks, examInfo.gradeScale) : 'N/A';
      
      const student = students.find(s => s.id === selectedStudent);
      const className = classes.find(c => c.id === selectedClass)?.name || '';
      
      // Progress animation
      const timer = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(timer);
            return 90;
          }
          return prev + 10;
        });
      }, 100);
      
      await saveExamResults({
        studentId: selectedStudent,
        studentName: student?.name,
        examId: selectedExam,
        examName: examInfo?.name,
        className,
        subjectResults,
        totalMarks,
        averageMarks,
        grade,
        teacher: '',  // Would come from authenticated user in a real app
        dateEntered: new Date().toISOString(),
      });
      
      clearInterval(timer);
      setProgress(100);
      
      toast({
        title: "Success",
        description: "Exam results saved successfully",
      });
      
      setTimeout(() => {
        resetForm();
        if (onSuccess) onSuccess();
      }, 1000);
      
    } catch (error) {
      console.error('Error saving exam results:', error);
      toast({
        title: "Error",
        description: "Failed to save exam results",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setSelectedStudent('');
    setSubjectResults(subjects.map(subject => ({
      subjectId: subject.id,
      subjectName: subject.name,
      marks: 0,
      outOf: 100,
      grade: '',
      teacherComment: ''
    })));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Record Exam Results</CardTitle>
        <CardDescription>Enter student examination scores by subject</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="class">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls.id} value={cls.id || "no-class"}>{cls.name || "Unknown Class"}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="exam">Examination</Label>
              <Select value={selectedExam} onValueChange={setSelectedExam}>
                <SelectTrigger>
                  <SelectValue placeholder="Select exam" />
                </SelectTrigger>
                <SelectContent>
                  {exams.map(exam => (
                    <SelectItem key={exam.id} value={exam.id || "no-exam"}>
                      {exam.name || "Unknown Exam"} ({exam.term || "Unknown Term"} {exam.year || "Unknown Year"})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="student">Student</Label>
              <Select 
                value={selectedStudent} 
                onValueChange={setSelectedStudent}
                disabled={!selectedClass}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select student" />
                </SelectTrigger>
                <SelectContent>
                  {classStudents.map(student => (
                    <SelectItem key={student.id} value={student.id || "no-student"}>{student.name || "Unknown Student"}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {selectedStudent && selectedExam && (
            <>
              <div className="space-y-4">
                <h3 className="font-medium text-lg">Subject Marks</h3>
                {subjectResults.map((subject, index) => (
                  <div key={subject.subjectId} className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-4">
                      <Label>{subject.subjectName || "Unknown Subject"}</Label>
                    </div>
                    <div className="col-span-3">
                      <Input 
                        type="number" 
                        min="0"
                        max="100"
                        value={subject.marks} 
                        onChange={(e) => handleSubjectResultChange(
                          subject.subjectId, 
                          'marks', 
                          Number(e.target.value)
                        )}
                        placeholder="Marks"
                      />
                    </div>
                    <div className="col-span-2">
                      <span className="text-sm text-muted-foreground">/ {subject.outOf}</span>
                    </div>
                    <div className="col-span-1">
                      <span className="font-bold">{subject.grade}</span>
                    </div>
                    <div className="col-span-2">
                      <Button 
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const comment = prompt('Add teacher comment for ' + subject.subjectName);
                          if (comment !== null) {
                            handleSubjectResultChange(subject.subjectId, 'teacherComment', comment);
                          }
                        }}
                      >
                        Add Comment
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t">
                <div>
                  <Label>Average: </Label>
                  <span className="font-bold ml-2">
                    {(subjectResults.reduce((sum, subject) => sum + Number(subject.marks), 0) / subjectResults.length).toFixed(1)}%
                  </span>
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'Saving...' : 'Save Results'}
                </Button>
              </div>
              
              {isLoading && (
                <div className="space-y-2">
                  <Progress value={progress} className="h-2" />
                  <p className="text-center text-sm text-muted-foreground">
                    {progress < 100 ? 'Processing...' : 'Complete!'}
                  </p>
                </div>
              )}
            </>
          )}
        </form>
      </CardContent>
    </Card>
  );
};

export default ExamEntryForm;
