
import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Users, UserCheck, FileImage, Database, HardDrive } from 'lucide-react';

interface StorageBreakdownProps {
  studentFiles: {
    count: number;
    size: number;
  };
  teacherFiles: {
    count: number;
    size: number;
  };
  otherFiles: {
    count: number;
    size: number;
  };
  totalStorage: number;
  storageLimit: number;
}

const StorageBreakdown: React.FC<StorageBreakdownProps> = ({
  studentFiles,
  teacherFiles,
  otherFiles,
  totalStorage,
  storageLimit
}) => {
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPercentage = (size: number) => (size / storageLimit) * 100;

  const categories = [
    {
      name: 'Student Files',
      icon: Users,
      size: studentFiles.size,
      count: studentFiles.count,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-100',
      textColor: 'text-blue-700'
    },
    {
      name: 'Teacher Files',
      icon: UserCheck,
      size: teacherFiles.size,
      count: teacherFiles.count,
      color: 'bg-green-500',
      lightColor: 'bg-green-100',
      textColor: 'text-green-700'
    },
    {
      name: 'Other Files',
      icon: FileImage,
      size: otherFiles.size,
      count: otherFiles.count,
      color: 'bg-purple-500',
      lightColor: 'bg-purple-100',
      textColor: 'text-purple-700'
    }
  ];

  return (
    <div className="space-y-4">
      <div className="text-sm font-medium">File Storage Breakdown</div>
      
      {/* Overall progress bar with segments */}
      <div className="relative">
        <Progress value={(totalStorage / storageLimit) * 100} className="h-4" />
        <div className="absolute inset-0 flex h-4 rounded-full overflow-hidden">
          {categories.map((category, index) => {
            const percentage = getPercentage(category.size);
            if (percentage === 0) return null;
            
            return (
              <div
                key={category.name}
                className={category.color}
                style={{ width: `${percentage}%` }}
                title={`${category.name}: ${formatBytes(category.size)}`}
              />
            );
          })}
        </div>
      </div>

      {/* Category details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {categories.map((category) => {
          const Icon = category.icon;
          const percentage = getPercentage(category.size);
          
          return (
            <div
              key={category.name}
              className={`p-3 rounded-lg ${category.lightColor} border border-opacity-20`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`h-4 w-4 ${category.textColor}`} />
                <span className={`text-sm font-medium ${category.textColor}`}>
                  {category.name}
                </span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>{formatBytes(category.size)}</span>
                  <span>{percentage.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{category.count} files</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Storage summary */}
      <div className="flex justify-between text-sm text-muted-foreground pt-2 border-t">
        <span>Total Used: {formatBytes(totalStorage)}</span>
        <span>Available: {formatBytes(storageLimit - totalStorage)}</span>
      </div>
    </div>
  );
};

export default StorageBreakdown;
