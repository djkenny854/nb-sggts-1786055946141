
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Clock, Users, AlertTriangle, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AttendanceSettings = () => {
  const [attendancePeriod, setAttendancePeriod] = useState('daily');
  const [allowFutureAttendance, setAllowFutureAttendance] = useState(false);
  const [lockAfterHours, setLockAfterHours] = useState('24');
  const [absentThreshold, setAbsentThreshold] = useState('3');
  const [notifyParentsOnAbsence, setNotifyParentsOnAbsence] = useState(true);
  const [requireAbsenceExplanation, setRequireAbsenceExplanation] = useState(true);
  const [monthlyReport, setMonthlyReport] = useState('class-teacher');
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Attendance settings have been updated successfully."
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Attendance Settings</h2>
        <p className="text-muted-foreground">Configure attendance tracking and reporting preferences.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Attendance Tracking
            </CardTitle>
            <CardDescription>Configure how attendance is tracked</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Attendance Period</Label>
              <Select value={attendancePeriod || 'daily'} onValueChange={setAttendancePeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="lesson">Per Lesson</SelectItem>
                  <SelectItem value="am-pm">AM/PM</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Allow Future Attendance</Label>
                <p className="text-xs text-muted-foreground">
                  Allow marking attendance for future dates
                </p>
              </div>
              <Switch checked={allowFutureAttendance} onCheckedChange={setAllowFutureAttendance} />
            </div>

            <div className="space-y-2">
              <Label>Lock Attendance After (Hours)</Label>
              <Select value={lockAfterHours || '24'} onValueChange={setLockAfterHours}>
                <SelectTrigger>
                  <SelectValue placeholder="Select hours" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Hour</SelectItem>
                  <SelectItem value="6">6 Hours</SelectItem>
                  <SelectItem value="12">12 Hours</SelectItem>
                  <SelectItem value="24">24 Hours</SelectItem>
                  <SelectItem value="48">48 Hours</SelectItem>
                  <SelectItem value="never">Never Lock</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Absence Management
            </CardTitle>
            <CardDescription>Configure absence tracking and notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Consecutive Absence Threshold</Label>
              <Select value={absentThreshold || '3'} onValueChange={setAbsentThreshold}>
                <SelectTrigger>
                  <SelectValue placeholder="Select threshold" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 Days</SelectItem>
                  <SelectItem value="3">3 Days</SelectItem>
                  <SelectItem value="5">5 Days</SelectItem>
                  <SelectItem value="7">1 Week</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Notify Parents on Absence</Label>
                <p className="text-xs text-muted-foreground">
                  Send automatic notifications to parents
                </p>
              </div>
              <Switch checked={notifyParentsOnAbsence} onCheckedChange={setNotifyParentsOnAbsence} />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Require Absence Explanation</Label>
                <p className="text-xs text-muted-foreground">
                  Require teachers to provide reason for absences
                </p>
              </div>
              <Switch checked={requireAbsenceExplanation} onCheckedChange={setRequireAbsenceExplanation} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Reporting
            </CardTitle>
            <CardDescription>Configure attendance reporting settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Monthly Report Recipients</Label>
              <Select value={monthlyReport || 'class-teacher'} onValueChange={setMonthlyReport}>
                <SelectTrigger>
                  <SelectValue placeholder="Select recipients" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="class-teacher">Class Teacher Only</SelectItem>
                  <SelectItem value="head-teacher">Head Teacher</SelectItem>
                  <SelectItem value="admin">Administration</SelectItem>
                  <SelectItem value="all">All Staff</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Auto-Generate Reports</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically generate monthly attendance reports
                </p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Include Tardiness Data</Label>
                <p className="text-xs text-muted-foreground">
                  Include late arrival statistics in reports
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSave} className="min-w-32">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default AttendanceSettings;
