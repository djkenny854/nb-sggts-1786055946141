
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { MessageSquare, Mail, Bell, Send, Loader2, Save } from 'lucide-react';
import { useCommunicationSettings } from '@/hooks/useCommunicationSettings';

const CommunicationPreferences = () => {
  const { settings, loading, updateSettings } = useCommunicationSettings();
  const [localSettings, setLocalSettings] = React.useState(settings);
  const [isSaving, setIsSaving] = React.useState(false);

  React.useEffect(() => {
    if (settings) {
      setLocalSettings(settings);
    }
  }, [settings]);

  const handleSave = async () => {
    if (!localSettings) return;
    
    setIsSaving(true);
    try {
      await updateSettings(localSettings);
    } catch (error) {
      // Error handling is done in the hook
    } finally {
      setIsSaving(false);
    }
  };

  const handleChange = (field: keyof typeof localSettings, value: any) => {
    setLocalSettings(prev => prev ? { ...prev, [field]: value } : null);
  };

  const handleConfigChange = (configType: 'email_config' | 'sms_config', key: string, value: any) => {
    setLocalSettings(prev => {
      if (!prev) return null;
      return {
        ...prev,
        [configType]: {
          ...prev[configType],
          [key]: value
        }
      };
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading communication settings...</span>
      </div>
    );
  }

  if (!localSettings) return null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Communication Preferences</h2>
        <p className="text-muted-foreground">Configure SMS, email, and notification settings.</p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="mr-2 h-5 w-5" />
              Email Configuration
            </CardTitle>
            <CardDescription>Set up email sending preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Email Provider</label>
              <Select 
                value={localSettings.email_provider} 
                onValueChange={(value) => handleChange('email_provider', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select provider" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="smtp">Custom SMTP</SelectItem>
                  <SelectItem value="sendgrid">SendGrid</SelectItem>
                  <SelectItem value="mailgun">Mailgun</SelectItem>
                  <SelectItem value="ses">Amazon SES</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {localSettings.email_provider === 'smtp' && (
              <>
                <div className="space-y-2">
                  <label className="text-sm font-medium">SMTP Server</label>
                  <Input 
                    placeholder="smtp.example.com" 
                    value={localSettings.email_config.smtp_server || ''}
                    onChange={(e) => handleConfigChange('email_config', 'smtp_server', e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Port</label>
                    <Input 
                      placeholder="587" 
                      value={localSettings.email_config.port || ''}
                      onChange={(e) => handleConfigChange('email_config', 'port', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Security</label>
                    <Select 
                      value={localSettings.email_config.security || 'tls'}
                      onValueChange={(value) => handleConfigChange('email_config', 'security', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select security" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="tls">TLS</SelectItem>
                        <SelectItem value="ssl">SSL</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">SMTP Username</label>
                  <Input 
                    placeholder="user@example.com" 
                    value={localSettings.email_config.username || ''}
                    onChange={(e) => handleConfigChange('email_config', 'username', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">SMTP Password</label>
                  <Input 
                    type="password" 
                    placeholder="••••••••" 
                    value={localSettings.email_config.password || ''}
                    onChange={(e) => handleConfigChange('email_config', 'password', e.target.value)}
                  />
                </div>
              </>
            )}
            
            {localSettings.email_provider !== 'smtp' && (
              <div className="space-y-2">
                <label className="text-sm font-medium">API Key</label>
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  value={localSettings.email_config.api_key || ''}
                  onChange={(e) => handleConfigChange('email_config', 'api_key', e.target.value)}
                />
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Sender Name</label>
              <Input 
                placeholder="School Name" 
                value={localSettings.email_config.sender_name || ''}
                onChange={(e) => handleConfigChange('email_config', 'sender_name', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Sender Email</label>
              <Input 
                placeholder="info@school.edu" 
                value={localSettings.email_config.sender_email || ''}
                onChange={(e) => handleConfigChange('email_config', 'sender_email', e.target.value)}
              />
            </div>
            
            <Button variant="outline" className="w-full">
              Test Email Configuration
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageSquare className="mr-2 h-5 w-5" />
              SMS Configuration
            </CardTitle>
            <CardDescription>Set up SMS gateway for text messaging</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">SMS Provider</label>
              <Select 
                value={localSettings.sms_provider} 
                onValueChange={(value) => handleChange('sms_provider', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select provider" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="twilio">Twilio</SelectItem>
                  <SelectItem value="africastalking">Africa's Talking</SelectItem>
                  <SelectItem value="nexmo">Vonage (Nexmo)</SelectItem>
                  <SelectItem value="custom">Custom Gateway</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">API Key / Account SID</label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                value={localSettings.sms_config.api_key || ''}
                onChange={(e) => handleConfigChange('sms_config', 'api_key', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">API Secret / Auth Token</label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                value={localSettings.sms_config.api_secret || ''}
                onChange={(e) => handleConfigChange('sms_config', 'api_secret', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Sender ID / From Number</label>
              <Input 
                placeholder="School Name or +12345678901" 
                value={localSettings.sms_config.sender_id || ''}
                onChange={(e) => handleConfigChange('sms_config', 'sender_id', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Enable Bulk SMS</label>
                <input type="checkbox" className="h-4 w-4" defaultChecked />
              </div>
              <p className="text-xs text-muted-foreground">
                Allow sending messages to multiple recipients at once
              </p>
            </div>
            
            <Button variant="outline" className="w-full">
              Test SMS Configuration
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="mr-2 h-5 w-5" />
              Notification Settings
            </CardTitle>
            <CardDescription>Configure in-app notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Notification Summary Frequency</label>
              <Select 
                value={localSettings.notification_frequency} 
                onValueChange={(value) => handleChange('notification_frequency', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realtime">Real-time</SelectItem>
                  <SelectItem value="hourly">Hourly Digest</SelectItem>
                  <SelectItem value="daily">Daily Digest</SelectItem>
                  <SelectItem value="weekly">Weekly Summary</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Notification Categories</label>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">New Messages</span>
                  <input type="checkbox" className="h-4 w-4" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Student Absences</span>
                  <input type="checkbox" className="h-4 w-4" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Fee Payments</span>
                  <input type="checkbox" className="h-4 w-4" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">System Updates</span>
                  <input type="checkbox" className="h-4 w-4" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Disciplinary Issues</span>
                  <input type="checkbox" className="h-4 w-4" defaultChecked />
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Allow Users to Customize</label>
                <input type="checkbox" className="h-4 w-4" defaultChecked />
              </div>
              <p className="text-xs text-muted-foreground">
                Let users set their own notification preferences
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex justify-end pt-4">
        <Button 
          onClick={handleSave}
          disabled={isSaving}
          className="min-w-32"
        >
          {isSaving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          {isSaving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
};

export default CommunicationPreferences;
