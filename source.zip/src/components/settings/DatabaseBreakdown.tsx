
import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Users, UserCheck, GraduationCap, CreditCard, Calendar, FileText } from 'lucide-react';

interface TableData {
  name: string;
  count: number;
  estimatedSize: number;
  icon: React.ComponentType<any>;
  color: string;
  lightColor: string;
  textColor: string;
}

interface DatabaseBreakdownProps {
  tableStats: {
    students: number;
    teachers: number;
    payments: number;
    feeTransactions: number;
    attendance: number;
    exams: number;
  };
  totalDbSize: number;
  dbLimit: number;
}

const DatabaseBreakdown: React.FC<DatabaseBreakdownProps> = ({
  tableStats,
  totalDbSize,
  dbLimit
}) => {
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPercentage = (size: number) => (size / dbLimit) * 100;

  // Estimate size per record type (in bytes)
  const recordSizes = {
    students: 2048, // Larger due to profile data
    teachers: 1536,
    payments: 512,
    feeTransactions: 384,
    attendance: 256,
    exams: 1024
  };

  const tables: TableData[] = [
    {
      name: 'Students',
      count: tableStats.students,
      estimatedSize: tableStats.students * recordSizes.students,
      icon: Users,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-100',
      textColor: 'text-blue-700'
    },
    {
      name: 'Teachers',
      count: tableStats.teachers,
      estimatedSize: tableStats.teachers * recordSizes.teachers,
      icon: UserCheck,
      color: 'bg-green-500',
      lightColor: 'bg-green-100',
      textColor: 'text-green-700'
    },
    {
      name: 'Payments',
      count: tableStats.payments,
      estimatedSize: tableStats.payments * recordSizes.payments,
      icon: CreditCard,
      color: 'bg-orange-500',
      lightColor: 'bg-orange-100',
      textColor: 'text-orange-700'
    },
    {
      name: 'Fees',
      count: tableStats.feeTransactions,
      estimatedSize: tableStats.feeTransactions * recordSizes.feeTransactions,
      icon: FileText,
      color: 'bg-red-500',
      lightColor: 'bg-red-100',
      textColor: 'text-red-700'
    },
    {
      name: 'Attendance',
      count: tableStats.attendance,
      estimatedSize: tableStats.attendance * recordSizes.attendance,
      icon: Calendar,
      color: 'bg-purple-500',
      lightColor: 'bg-purple-100',
      textColor: 'text-purple-700'
    },
    {
      name: 'Exams',
      count: tableStats.exams,
      estimatedSize: tableStats.exams * recordSizes.exams,
      icon: GraduationCap,
      color: 'bg-indigo-500',
      lightColor: 'bg-indigo-100',
      textColor: 'text-indigo-700'
    }
  ];

  return (
    <div className="space-y-4">
      <div className="text-sm font-medium">Database Storage Breakdown</div>
      
      {/* Overall progress bar with segments */}
      <div className="relative">
        <Progress value={(totalDbSize / dbLimit) * 100} className="h-4" />
        <div className="absolute inset-0 flex h-4 rounded-full overflow-hidden">
          {tables.map((table) => {
            const percentage = getPercentage(table.estimatedSize);
            if (percentage === 0) return null;
            
            return (
              <div
                key={table.name}
                className={table.color}
                style={{ width: `${percentage}%` }}
                title={`${table.name}: ${formatBytes(table.estimatedSize)}`}
              />
            );
          })}
        </div>
      </div>

      {/* Table details */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {tables.map((table) => {
          const Icon = table.icon;
          const percentage = getPercentage(table.estimatedSize);
          
          return (
            <div
              key={table.name}
              className={`p-3 rounded-lg ${table.lightColor} border border-opacity-20`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`h-4 w-4 ${table.textColor}`} />
                <span className={`text-sm font-medium ${table.textColor}`}>
                  {table.name}
                </span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>{formatBytes(table.estimatedSize)}</span>
                  <span>{percentage.toFixed(1)}%</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {table.count.toLocaleString()} records
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Database summary */}
      <div className="flex justify-between text-sm text-muted-foreground pt-2 border-t">
        <span>Total Used: {formatBytes(totalDbSize)}</span>
        <span>Available: {formatBytes(dbLimit - totalDbSize)}</span>
      </div>
    </div>
  );
};

export default DatabaseBreakdown;
