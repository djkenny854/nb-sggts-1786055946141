
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { ArrowDown, ArrowUp, Check, Loader } from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { CLASS_LEVELS } from '@/data/classLevels';
import { Student } from '@/types';
import { fetchStudents, updateStudent } from '@/utils/supabaseHelpers';
import { useQuery } from '@tanstack/react-query';

const StudentPromotion = () => {
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [targetClass, setTargetClass] = useState<string>('');
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [promoting, setPromoting] = useState(false);
  const [promotionComplete, setPromotionComplete] = useState(false);
  const [actionType, setActionType] = useState<'promote' | 'demote'>('promote');
  const [newAcademicYear, setNewAcademicYear] = useState<string>(new Date().getFullYear().toString());

  // Fetch all students
  const { 
    data: allStudents = [], 
    isLoading: studentsLoading,
    refetch: refetchStudents 
  } = useQuery({
    queryKey: ['students'],
    queryFn: fetchStudents,
  });

  const handleClassChange = (value: string) => {
    console.log('Selected class:', value);
    setSelectedClass(value);
    setSelectedStudents([]); // Reset selected students when class changes
  };

  const handleTargetClassChange = (value: string) => {
    setTargetClass(value);
  };

  // Filter students when class selection changes
  useEffect(() => {
    if (selectedClass && allStudents.length > 0) {
      console.log('Filtering students for class:', selectedClass);
      console.log('All students count:', allStudents.length);
      
      // Get the display name for the selected class
      const selectedClassInfo = CLASS_LEVELS.find(cl => cl.id === selectedClass);
      const classDisplayName = selectedClassInfo?.displayName;
      
      console.log('Looking for students in class:', selectedClass, 'or', classDisplayName);
      
      const filtered = allStudents.filter(student => {
        // Check multiple possible matches
        const matchesClassId = student.classId === selectedClass;
        const matchesClassName = student.className === selectedClass;
        const matchesDisplayName = student.className === classDisplayName;
        const matchesClassIdAsName = student.classId === classDisplayName;
        
        const isMatch = matchesClassId || matchesClassName || matchesDisplayName || matchesClassIdAsName;
        
        if (isMatch) {
          console.log(`Student ${student.name} matches - classId: ${student.classId}, className: ${student.className}`);
        }
        
        return isMatch;
      });
      
      console.log('Filtered students count:', filtered.length);
      setFilteredStudents(filtered);
    } else {
      setFilteredStudents([]);
    }
  }, [selectedClass, allStudents]);

  const toggleSelectStudent = (studentId: string) => {
    setSelectedStudents(prev => {
      if (prev.includes(studentId)) {
        return prev.filter(id => id !== studentId);
      } else {
        return [...prev, studentId];
      }
    });
  };

  const toggleSelectAll = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(filteredStudents.map(student => student.id));
    }
  };

  const handlePromoteStudents = async () => {
    if (!targetClass || selectedStudents.length === 0) {
      toast.error(`Cannot ${actionType}`, {
        description: "Please select target class and at least one student."
      });
      return;
    }

    const targetClassInfo = CLASS_LEVELS.find(cl => cl.id === targetClass);
    if (!targetClassInfo) {
      toast.error("Invalid target class", {
        description: "The selected target class is invalid."
      });
      return;
    }

    // Validate action type
    const currentClassIndex = CLASS_LEVELS.findIndex(cl => cl.id === selectedClass);
    const targetClassIndex = CLASS_LEVELS.findIndex(cl => cl.id === targetClass);
    
    if (actionType === 'promote' && targetClassIndex <= currentClassIndex) {
      toast.error("Invalid promotion", {
        description: "Target class must be higher than current class for promotion."
      });
      return;
    }
    
    if (actionType === 'demote' && targetClassIndex >= currentClassIndex) {
      toast.error("Invalid demotion", {
        description: "Target class must be lower than current class for demotion."
      });
      return;
    }

    setPromoting(true);
    setProgress(0);
    setPromotionComplete(false);

    try {
      const totalStudents = selectedStudents.length;
      let processed = 0;

      for (const studentId of selectedStudents) {
        const student = filteredStudents.find(s => s.id === studentId);
        if (student) {
          console.log(`${actionType === 'promote' ? 'Promoting' : 'Demoting'} student ${student.name} from ${student.className} to ${targetClassInfo.displayName}`);
          
          // Update student class and academic year
          const updatedStudent = {
            classId: targetClass,
            className: targetClassInfo.displayName,
            // You can add academic_year field to students table if needed
            // academic_year: newAcademicYear
          };

          await updateStudent(studentId, updatedStudent);
          console.log(`Successfully ${actionType === 'promote' ? 'promoted' : 'demoted'} ${student.name}`);

          // Update progress
          processed++;
          setProgress(Math.round((processed / totalStudents) * 100));
        }
      }

      // Refresh student list
      await refetchStudents();
      
      setPromotionComplete(true);
      toast.success(`${actionType === 'promote' ? 'Promotion' : 'Demotion'} complete`, {
        description: `Successfully ${actionType === 'promote' ? 'promoted' : 'demoted'} ${totalStudents} student${totalStudents !== 1 ? 's' : ''} to ${targetClassInfo.displayName}.`
      });

      // Reset selection after successful operation
      setSelectedStudents([]);
    } catch (error) {
      console.error(`Error during ${actionType}:`, error);
      toast.error(`${actionType === 'promote' ? 'Promotion' : 'Demotion'} failed`, {
        description: `An error occurred while ${actionType === 'promote' ? 'promoting' : 'demoting'} students. Please try again.`
      });
    } finally {
      // Wait 2 seconds to show the completion state before resetting
      setTimeout(() => {
        setPromoting(false);
        setPromotionComplete(false);
      }, 2000);
    }
  };

  const getClassDisplayName = (classId: string) => {
    return CLASS_LEVELS.find(cl => cl.id === classId)?.displayName || classId;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {actionType === 'promote' ? (
            <ArrowUp className="h-5 w-5 text-green-600" />
          ) : (
            <ArrowDown className="h-5 w-5 text-orange-600" />
          )}
          Year-End Student Transitions
        </CardTitle>
        <CardDescription>Promote students to next grade or demote based on performance</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Action Type Selection */}
        <div className="flex gap-2 p-1 bg-muted rounded-lg w-fit">
          <Button
            variant={actionType === 'promote' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActionType('promote')}
            className="gap-2"
          >
            <ArrowUp className="h-4 w-4" />
            Promote
          </Button>
          <Button
            variant={actionType === 'demote' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActionType('demote')}
            className="gap-2"
          >
            <ArrowDown className="h-4 w-4" />
            Demote
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Current Class</label>
            <Select value={selectedClass} onValueChange={handleClassChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select current class" />
              </SelectTrigger>
              <SelectContent>
                {CLASS_LEVELS.map((classLevel) => (
                  <SelectItem key={classLevel.id} value={classLevel.id}>
                    {classLevel.displayName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">
              {actionType === 'promote' ? 'Promote To' : 'Demote To'}
            </label>
            <Select value={targetClass} onValueChange={handleTargetClassChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select target class" />
              </SelectTrigger>
              <SelectContent>
                {CLASS_LEVELS.map((classLevel) => (
                  <SelectItem key={classLevel.id} value={classLevel.id}>
                    {classLevel.displayName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Academic Year</label>
            <Select value={newAcademicYear} onValueChange={setNewAcademicYear}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={(new Date().getFullYear() - 1).toString()}>
                  {new Date().getFullYear() - 1}
                </SelectItem>
                <SelectItem value={new Date().getFullYear().toString()}>
                  {new Date().getFullYear()}
                </SelectItem>
                <SelectItem value={(new Date().getFullYear() + 1).toString()}>
                  {new Date().getFullYear() + 1}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedClass && (
          <>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox 
                        checked={filteredStudents.length > 0 && selectedStudents.length === filteredStudents.length}
                        onCheckedChange={toggleSelectAll}
                      />
                    </TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>ID</TableHead>
                    <TableHead>Current Class</TableHead>
                    <TableHead>Gender</TableHead>
                    <TableHead>Fees Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {studentsLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="flex justify-center">
                          <Loader className="h-6 w-6 animate-spin text-primary" />
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">Loading students...</p>
                      </TableCell>
                    </TableRow>
                  ) : filteredStudents.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <p className="text-sm text-muted-foreground">
                          No students found in {getClassDisplayName(selectedClass)}.
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Debug: Looking for students with classId="{selectedClass}" or className="{getClassDisplayName(selectedClass)}"
                        </p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell>
                          <Checkbox 
                            checked={selectedStudents.includes(student.id)} 
                            onCheckedChange={() => toggleSelectStudent(student.id)}
                          />
                        </TableCell>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>{student.enrollmentNumber}</TableCell>
                        <TableCell>{student.className}</TableCell>
                        <TableCell>{student.gender}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            (student.fees?.due || 0) > 0 
                              ? 'bg-red-100 text-red-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {(student.fees?.due || 0) > 0 ? 'Has Balance' : 'Paid Up'}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="flex flex-col items-center space-y-4">
              {promoting && (
                <div className="w-full space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Promoting students...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="w-full" />
                </div>
              )}

              {promotionComplete && (
                <div className="flex items-center text-green-600 space-x-2 py-2">
                  <Check className="h-5 w-5" />
                  <span>Promotion completed successfully!</span>
                </div>
              )}
              
              <Button 
                onClick={handlePromoteStudents} 
                disabled={selectedStudents.length === 0 || !targetClass || promoting}
                className="w-full md:w-auto"
                variant={actionType === 'promote' ? 'default' : 'destructive'}
              >
                {promoting ? (
                  <span className="flex items-center">
                    <Loader className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </span>
                ) : (
                  <span className="flex items-center">
                    {actionType === 'promote' ? (
                      <ArrowUp className="mr-2 h-4 w-4" />
                    ) : (
                      <ArrowDown className="mr-2 h-4 w-4" />
                    )}
                    {actionType === 'promote' ? 'Promote' : 'Demote'} {selectedStudents.length} Student{selectedStudents.length !== 1 ? 's' : ''}
                  </span>
                )}
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                {selectedStudents.length > 0 
                  ? `${selectedStudents.length} student${selectedStudents.length > 1 ? 's' : ''} selected for ${actionType === 'promote' ? 'promotion' : 'demotion'}.`
                  : `Select students to ${actionType === 'promote' ? 'promote to the next class' : 'demote to a lower class'}.`}
              </p>
              <p className="text-xs text-muted-foreground bg-muted p-2 rounded">
                <strong>Note:</strong> {actionType === 'promote' ? 'Promoting' : 'Demoting'} students will update their class assignment. 
                Fee structures will be automatically applied based on the new class during the next term.
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default StudentPromotion;
