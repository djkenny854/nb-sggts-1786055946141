
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, DollarSign, Monitor } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import GoogleDeviceEnrollment from './GoogleDeviceEnrollment';

interface InventoryCategory {
  id: string;
  name: string;
  description?: string;
}

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  quantity: number;
  cost?: number;
  paid_from_fees: boolean;
  condition: string;
  status: string;
  date_purchased?: string;
  google_device_id?: string;
  enrollment_status: string;
  category_id?: string;
  serial_number?: string;
  location?: string;
  assigned_to?: string;
}

interface InventoryItemFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: InventoryItem | null;
  categories: InventoryCategory[];
  onSuccess: () => void;
}

const InventoryItemForm: React.FC<InventoryItemFormProps> = ({
  open,
  onOpenChange,
  item,
  categories,
  onSuccess
}) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    quantity: 1,
    cost: '',
    paid_from_fees: false,
    condition: 'good',
    status: 'available',
    date_purchased: '',
    serial_number: '',
    location: '',
    assigned_to: '',
    notes: '',
    enable_enrollment: false
  });
  const [loading, setLoading] = useState(false);
  const [showGoogleEnrollment, setShowGoogleEnrollment] = useState(false);
  const [availableFees, setAvailableFees] = useState(0);
  const [savedItem, setSavedItem] = useState<InventoryItem | null>(null);
  const { toast } = useToast();

  // All available categories with their descriptions
  const allCategories = [
    { id: 'computers', name: 'Computers', description: 'Desktops, laptops, tablets, and computer accessories' },
    { id: 'laptops', name: 'Laptops', description: 'Portable computers and laptop accessories' },
    { id: 'tablets', name: 'Tablets', description: 'Tablets and mobile computing devices' },
    { id: 'smartphones', name: 'Smartphones', description: 'Mobile phones and smartphone accessories' },
    { id: 'printers', name: 'Printers', description: 'Printers, scanners, and printing equipment' },
    { id: 'projectors', name: 'Projectors', description: 'Classroom projectors and presentation equipment' },
    { id: 'electronics', name: 'Electronics', description: 'General electronic devices and equipment' },
    { id: 'lab_equipment', name: 'Lab Equipment', description: 'Science lab equipment and instruments' },
    { id: 'sports_equipment', name: 'Sports Equipment', description: 'Sports gear and physical education equipment' },
    { id: 'vehicles', name: 'Vehicles', description: 'School vehicles and transportation equipment' },
    { id: 'furniture', name: 'Furniture', description: 'Desks, chairs, tables, and classroom furniture' },
    { id: 'books', name: 'Books', description: 'Textbooks, library books, and educational materials' },
    { id: 'office_supplies', name: 'Office Supplies', description: 'Stationery, paper, and office materials' },
    { id: 'musical_instruments', name: 'Musical Instruments', description: 'Instruments for music education' },
    { id: 'art_supplies', name: 'Art Supplies', description: 'Materials for art and craft activities' },
    { id: 'kitchen_equipment', name: 'Kitchen Equipment', description: 'Cafeteria and kitchen appliances' },
    { id: 'cleaning_supplies', name: 'Cleaning Supplies', description: 'Maintenance and cleaning equipment' },
    { id: 'medical_equipment', name: 'Medical Equipment', description: 'First aid and medical supplies' },
    { id: 'security_equipment', name: 'Security Equipment', description: 'Cameras, locks, and security devices' },
    { id: 'tools', name: 'Tools', description: 'Maintenance and repair tools' }
  ];

  // Categories that require serial numbers
  const serialNumberCategories = [
    'Computers', 'Laptops', 'Tablets', 'Smartphones', 'Printers', 'Projectors', 
    'Electronics', 'Lab Equipment', 'Vehicles', 'Musical Instruments', 'Security Equipment'
  ];

  // Categories that support Google Device Enrollment
  const googleEnrollmentCategories = ['Computers', 'Laptops', 'Tablets'];

  useEffect(() => {
    if (open) {
      fetchAvailableFees();
    }
  }, [open]);

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name || '',
        description: item.description || '',
        category: item.category || '',
        quantity: item.quantity || 1,
        cost: item.cost?.toString() || '',
        paid_from_fees: item.paid_from_fees || false,
        condition: item.condition || 'good',
        status: item.status || 'available',
        date_purchased: item.date_purchased || '',
        serial_number: item.serial_number || '',
        location: item.location || '',
        assigned_to: item.assigned_to || '',
        notes: '',
        enable_enrollment: item.enrollment_status === 'enrolled'
      });
    } else {
      setFormData({
        name: '',
        description: '',
        category: '',
        quantity: 1,
        cost: '',
        paid_from_fees: false,
        condition: 'good',
        status: 'available',
        date_purchased: '',
        serial_number: '',
        location: '',
        assigned_to: '',
        notes: '',
        enable_enrollment: false
      });
    }
  }, [item, open]);

  const fetchAvailableFees = async () => {
    try {
      // Get total fees collected
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('fee_transactions')
        .select('amount')
        .eq('status', 'completed');

      if (paymentsError) throw paymentsError;

      const totalCollected = paymentsData?.reduce((sum, payment) => sum + Number(payment.amount), 0) || 0;

      // Get total fees used
      const { data: usageData, error: usageError } = await supabase
        .from('fees_usage')
        .select('amount');

      if (usageError) throw usageError;

      const totalUsed = usageData?.reduce((sum, usage) => sum + Number(usage.amount), 0) || 0;

      setAvailableFees(totalCollected - totalUsed);
    } catch (error) {
      console.error('Error fetching available fees:', error);
    }
  };

  const handleCategoryChange = (categoryName: string) => {
    setFormData(prev => ({
      ...prev,
      category: categoryName
    }));
  };

  // Map category names to database enum values
  const mapCategoryToEnum = (categoryName: string): 'computers' | 'furniture' | 'books' | 'electronics' | 'sports_equipment' | 'lab_equipment' | 'office_supplies' | 'vehicles' | 'other' => {
    const categoryMap: { [key: string]: 'computers' | 'furniture' | 'books' | 'electronics' | 'sports_equipment' | 'lab_equipment' | 'office_supplies' | 'vehicles' | 'other' } = {
      'Computers': 'computers',
      'Laptops': 'computers',
      'Tablets': 'computers',
      'Smartphones': 'electronics',
      'Furniture': 'furniture',
      'Books': 'books',
      'Printers': 'electronics',
      'Projectors': 'electronics',
      'Electronics': 'electronics',
      'Sports Equipment': 'sports_equipment',
      'Lab Equipment': 'lab_equipment',
      'Office Supplies': 'office_supplies',
      'Vehicles': 'vehicles',
      'Musical Instruments': 'other',
      'Art Supplies': 'other',
      'Kitchen Equipment': 'other',
      'Cleaning Supplies': 'other',
      'Medical Equipment': 'other',
      'Security Equipment': 'electronics',
      'Tools': 'other'
    };
    return categoryMap[categoryName] || 'other';
  };

  // Map condition to database enum values
  const mapConditionToEnum = (condition: string): 'excellent' | 'good' | 'fair' | 'poor' | 'damaged' | 'obsolete' => {
    const conditionMap: { [key: string]: 'excellent' | 'good' | 'fair' | 'poor' | 'damaged' | 'obsolete' } = {
      'excellent': 'excellent',
      'good': 'good',
      'fair': 'fair',
      'poor': 'poor',
      'damaged': 'damaged',
      'obsolete': 'obsolete'
    };
    return conditionMap[condition] || 'good';
  };

  // Map status to database enum values
  const mapStatusToEnum = (status: string): 'available' | 'in_use' | 'maintenance' | 'retired' | 'lost' | 'stolen' => {
    const statusMap: { [key: string]: 'available' | 'in_use' | 'maintenance' | 'retired' | 'lost' | 'stolen' } = {
      'available': 'available',
      'in_use': 'in_use',
      'maintenance': 'maintenance',
      'retired': 'retired',
      'lost': 'lost',
      'stolen': 'stolen'
    };
    return statusMap[status] || 'available';
  };

  const requiresSerialNumber = (categoryName: string) => {
    return serialNumberCategories.includes(categoryName);
  };

  const supportsGoogleEnrollment = (categoryName: string) => {
    return googleEnrollmentCategories.includes(categoryName);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const totalCost = formData.cost ? parseFloat(formData.cost) * formData.quantity : 0;

      // Validate serial number requirement
      if (requiresSerialNumber(formData.category) && !formData.serial_number.trim()) {
        toast({
          title: "Error",
          description: `Serial number is required for ${formData.category}`,
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      // Check if fees are sufficient when paid from fees
      if (formData.paid_from_fees && totalCost > availableFees) {
        toast({
          title: "Insufficient Fees",
          description: `Available fees: UGX ${availableFees.toLocaleString()}. Required: UGX ${totalCost.toLocaleString()}`,
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      // Prepare data with correct types for database - remove category_id completely
      const data = {
        name: formData.name,
        description: formData.description || null,
        category: mapCategoryToEnum(formData.category),
        quantity: formData.quantity,
        cost: formData.cost ? parseFloat(formData.cost) : null,
        paid_from_fees: formData.paid_from_fees,
        condition: mapConditionToEnum(formData.condition),
        status: mapStatusToEnum(formData.status),
        date_purchased: formData.date_purchased || null,
        serial_number: formData.serial_number || null,
        location: formData.location || null,
        assigned_to: formData.assigned_to || null,
        notes: formData.notes || null,
        enrollment_status: formData.enable_enrollment ? 'enrolled' : 'not_enrolled'
      };

      if (item) {
        const { error } = await supabase
          .from('inventory_items')
          .update(data)
          .eq('id', item.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Inventory item updated successfully"
        });
      } else {
        const { data: insertedData, error } = await supabase
          .from('inventory_items')
          .insert([data])
          .select()
          .single();

        if (error) throw error;

        setSavedItem(insertedData);

        toast({
          title: "Success",
          description: "Inventory item created successfully"
        });
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error saving inventory item:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save inventory item",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const totalCost = formData.cost ? parseFloat(formData.cost) * formData.quantity : 0;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{item ? 'Edit Inventory Item' : 'Add New Inventory Item'}</DialogTitle>
            <DialogDescription>
              {item ? 'Update the inventory item details below.' : 'Fill in the details for the new inventory item.'}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Item Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select value={formData.category} onValueChange={handleCategoryChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {allCategories.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>

            {/* Serial Number - Required for certain categories */}
            {requiresSerialNumber(formData.category) && (
              <div className="space-y-2">
                <Label htmlFor="serial_number">Serial Number *</Label>
                <Input
                  id="serial_number"
                  value={formData.serial_number}
                  onChange={(e) => setFormData({ ...formData, serial_number: e.target.value })}
                  placeholder="e.g., SN123456789"
                  required
                />
              </div>
            )}

            {/* Quantity and Cost */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity *</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cost">Cost per Item (UGX)</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                  placeholder="0.00"
                />
              </div>
            </div>

            {/* Total Cost Display */}
            {totalCost > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <DollarSign className="h-5 w-5 mr-2" />
                    Total Cost: UGX {totalCost.toLocaleString()}
                  </CardTitle>
                </CardHeader>
              </Card>
            )}

            {/* Fee Deduction Option */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Fee Deduction</CardTitle>
                <CardDescription>
                  Available fees: UGX {availableFees.toLocaleString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="paid_from_fees"
                    checked={formData.paid_from_fees}
                    onCheckedChange={(checked) => setFormData({ ...formData, paid_from_fees: checked })}
                  />
                  <Label htmlFor="paid_from_fees">Paid from student fees</Label>
                </div>
                
                {formData.paid_from_fees && (
                  <div className={`p-3 rounded-lg border ${
                    totalCost > availableFees 
                      ? 'bg-red-50 border-red-200' 
                      : 'bg-yellow-50 border-yellow-200'
                  }`}>
                    <div className="flex items-center">
                      <AlertCircle className={`h-4 w-4 mr-2 ${
                        totalCost > availableFees ? 'text-red-600' : 'text-yellow-600'
                      }`} />
                      <p className={`text-sm ${
                        totalCost > availableFees ? 'text-red-800' : 'text-yellow-800'
                      }`}>
                        {totalCost > availableFees 
                          ? `Insufficient fees! Available: UGX ${availableFees.toLocaleString()}, Required: UGX ${totalCost.toLocaleString()}`
                          : `This will deduct UGX ${totalCost.toLocaleString()} from your fee collections.`
                        }
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Google Device Enrollment for supported categories */}
            {supportsGoogleEnrollment(formData.category) && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Monitor className="h-5 w-5 mr-2" />
                    Google Device Management
                  </CardTitle>
                  <CardDescription>
                    Enable Google Admin enrollment for this {formData.category.toLowerCase()}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="enable_enrollment"
                      checked={formData.enable_enrollment}
                      onCheckedChange={(checked) => setFormData({ ...formData, enable_enrollment: checked })}
                    />
                    <Label htmlFor="enable_enrollment">Enable Google Device Enrollment</Label>
                  </div>
                  
                  {formData.enable_enrollment && (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        This device will be enrolled in Google Admin for management and monitoring.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Condition and Status */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="condition">Condition</Label>
                <Select value={formData.condition} onValueChange={(value) => setFormData({ ...formData, condition: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">Excellent</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="poor">Poor</SelectItem>
                    <SelectItem value="damaged">Damaged</SelectItem>
                    <SelectItem value="obsolete">Obsolete</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="in_use">In Use</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                    <SelectItem value="lost">Lost</SelectItem>
                    <SelectItem value="stolen">Stolen</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Additional Details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date_purchased">Date Purchased</Label>
                <Input
                  id="date_purchased"
                  type="date"
                  value={formData.date_purchased}
                  onChange={(e) => setFormData({ ...formData, date_purchased: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g., Computer Lab, Office 101"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="assigned_to">Assigned To</Label>
              <Input
                id="assigned_to"
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                placeholder="e.g., John Doe, Class 6A"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                placeholder="Additional notes about this item..."
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? 'Saving...' : item ? 'Update Item' : 'Add Item'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Google Device Enrollment Dialog */}
      <GoogleDeviceEnrollment
        open={showGoogleEnrollment}
        onOpenChange={setShowGoogleEnrollment}
        item={savedItem || item}
        onSuccess={() => {
          onSuccess();
          setShowGoogleEnrollment(false);
        }}
      />
    </>
  );
};

export default InventoryItemForm;
