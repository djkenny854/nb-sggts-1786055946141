
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Monitor, Smartphone } from 'lucide-react';
import GoogleDeviceEnrollment from './GoogleDeviceEnrollment';

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  serial_number?: string;
  google_device_id?: string;
  enrollment_status: string;
}

interface ResponsiveGoogleEnrollmentProps {
  item: InventoryItem;
  onSuccess: () => void;
}

const ResponsiveGoogleEnrollment: React.FC<ResponsiveGoogleEnrollmentProps> = ({
  item,
  onSuccess
}) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Mobile View - Icon Only */}
      <div className="md:hidden">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="p-2">
              <Smartphone className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Monitor className="h-5 w-5 mr-2" />
                Google Enrollment
              </DialogTitle>
            </DialogHeader>
            <div className="mt-4">
              <GoogleDeviceEnrollment
                open={true}
                onOpenChange={() => {}}
                item={item}
                onSuccess={() => {
                  onSuccess();
                  setOpen(false);
                }}
              />
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Desktop/Tablet View - Full Button */}
      <div className="hidden md:block">
        <GoogleDeviceEnrollment
          open={open}
          onOpenChange={setOpen}
          item={item}
          onSuccess={onSuccess}
        />
        <Button
          variant="outline"
          size="sm"
          onClick={() => setOpen(true)}
          className="flex items-center"
        >
          <Monitor className="h-4 w-4 mr-2" />
          Google Enrollment
        </Button>
      </div>
    </>
  );
};

export default ResponsiveGoogleEnrollment;
