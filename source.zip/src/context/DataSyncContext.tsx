import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner';
import { supabase, subscribeToTable, fetchData, insertData, updateData, deleteData } from '@/lib/supabase';
import { Student, Teacher, ClassInfo, SyncStatus } from '@/types';
import { saveStudentsToDB, loadStudentsFromDB } from '@/utils/indexedDB';
import { Payment } from '@/types/payment';

type DataContextType = {
  students: Student[];
  teachers: Teacher[];
  classes: ClassInfo[];
  payments: Payment[];
  syncStatus: SyncStatus;
  addStudent: (student: Partial<Student>) => Promise<Student>;
  updateStudent: (id: string, data: Partial<Student>) => Promise<Student>;
  deleteStudent: (id: string) => Promise<void>;
  addTeacher: (teacher: Partial<Teacher>) => Promise<Teacher>;
  updateTeacher: (id: string, data: Partial<Teacher>) => Promise<Teacher>;
  deleteTeacher: (id: string) => Promise<void>;
  addClass: (classInfo: Partial<ClassInfo>) => Promise<ClassInfo>;
  updateClass: (id: string, data: Partial<ClassInfo>) => Promise<ClassInfo>;
  deleteClass: (id: string) => Promise<void>;
  triggerSync: () => Promise<void>;
  isOnline: boolean;
  refreshData: () => Promise<void>; // Added the missing refreshData function
};

const defaultSyncStatus: SyncStatus = {
  lastSyncedAt: null,
  syncedWithDevices: [],
  pendingChanges: 0,
  status: 'offline',
};

const DataContext = createContext<DataContextType>({
  students: [],
  teachers: [],
  classes: [],
  payments: [],
  syncStatus: defaultSyncStatus,
  addStudent: async () => ({ id: '', name: '', enrollmentNumber: '', dateOfBirth: '', gender: '', classId: '', className: '', parentName: '', parentContact: '', address: '', joinDate: '', fees: { paid: 0, due: 0, lastPaymentDate: '' } }),
  updateStudent: async () => ({ id: '', name: '', enrollmentNumber: '', dateOfBirth: '', gender: '', classId: '', className: '', parentName: '', parentContact: '', address: '', joinDate: '', fees: { paid: 0, due: 0, lastPaymentDate: '' } }),
  deleteStudent: async () => {},
  addTeacher: async () => ({ id: '', name: '', email: '', phone: '', subjects: [], classTeacherFor: '', joinDate: '' }),
  updateTeacher: async () => ({ id: '', name: '', email: '', phone: '', subjects: [], classTeacherFor: '', joinDate: '' }),
  deleteTeacher: async () => {},
  addClass: async () => ({ id: '', name: '', teacher: '', studentsCount: 0, subjects: [] }),
  updateClass: async () => ({ id: '', name: '', teacher: '', studentsCount: 0, subjects: [] }),
  deleteClass: async () => {},
  triggerSync: async () => {},
  isOnline: false,
  refreshData: async () => {}, // Added the missing refreshData function in default context
});

export const useData = () => useContext(DataContext);

export const DataSyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [classes, setClasses] = useState<ClassInfo[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(defaultSyncStatus);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [pendingChanges, setPendingChanges] = useState<any[]>([]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      triggerSync();
      setSyncStatus(prev => ({ ...prev, status: 'syncing' }));
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus(prev => ({ ...prev, status: 'offline' }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const localStudents = await loadStudentsFromDB();
        setStudents(localStudents);

        if (isOnline) {
          setSyncStatus(prev => ({ ...prev, status: 'syncing' }));
          
          const remoteStudents = await fetchData<Student>('students');
          console.log("Fetched remote students:", remoteStudents);
          setStudents(remoteStudents);
          await saveStudentsToDB(remoteStudents);
          
          const remoteTeachers = await fetchData<Teacher>('teachers');
          setTeachers(remoteTeachers);
          
          const remoteClasses = await fetchData<ClassInfo>('classes');
          setClasses(remoteClasses);

          try {
            const remotePayments = await fetchData<Payment>('payments');
            setPayments(remotePayments);
          } catch (error) {
            console.warn('Payments table may not exist yet:', error);
          }
          
          setSyncStatus({
            lastSyncedAt: new Date().toISOString(),
            syncedWithDevices: ['Current Device'],
            pendingChanges: 0,
            status: 'synced',
          });
        }
      } catch (error) {
        console.error("Error loading initial data:", error);
        setSyncStatus(prev => ({ ...prev, status: 'error' }));
      }
    };

    loadInitialData();
  }, [isOnline]);

  useEffect(() => {
    if (!isOnline) return;
    
    const cleanupFunctions: Array<() => void> = [];
    
    const studentsCleanup = subscribeToTable('students', (payload: any) => {
      if (payload.eventType === 'INSERT') {
        setStudents(prev => [...prev, payload.new]);
      } else if (payload.eventType === 'UPDATE') {
        setStudents(prev => prev.map(student => 
          student.id === payload.new.id ? payload.new : student
        ));
      } else if (payload.eventType === 'DELETE') {
        setStudents(prev => prev.filter(student => student.id !== payload.old.id));
      }
    });
    cleanupFunctions.push(studentsCleanup);
    
    const teachersCleanup = subscribeToTable('teachers', (payload: any) => {
      if (payload.eventType === 'INSERT') {
        setTeachers(prev => [...prev, payload.new]);
      } else if (payload.eventType === 'UPDATE') {
        setTeachers(prev => prev.map(teacher => 
          teacher.id === payload.new.id ? payload.new : teacher
        ));
      } else if (payload.eventType === 'DELETE') {
        setTeachers(prev => prev.filter(teacher => teacher.id !== payload.old.id));
      }
    });
    cleanupFunctions.push(teachersCleanup);
    
    const classesCleanup = subscribeToTable('classes', (payload: any) => {
      if (payload.eventType === 'INSERT') {
        setClasses(prev => [...prev, payload.new]);
      } else if (payload.eventType === 'UPDATE') {
        setClasses(prev => prev.map(cls => 
          cls.id === payload.new.id ? payload.new : cls
        ));
      } else if (payload.eventType === 'DELETE') {
        setClasses(prev => prev.filter(cls => cls.id !== payload.old.id));
      }
    });
    cleanupFunctions.push(classesCleanup);

    try {
      const paymentsCleanup = subscribeToTable('payments', (payload: any) => {
        if (payload.eventType === 'INSERT') {
          setPayments(prev => [...prev, payload.new]);
        } else if (payload.eventType === 'UPDATE') {
          setPayments(prev => prev.map(payment => 
            payment.id === payload.new.id ? payload.new : payment
          ));
        } else if (payload.eventType === 'DELETE') {
          setPayments(prev => prev.filter(payment => payment.id !== payload.old.id));
        }
      });
      cleanupFunctions.push(paymentsCleanup);
    } catch (error) {
      console.warn('Could not subscribe to payments table:', error);
    }

    return () => {
      cleanupFunctions.forEach(cleanup => cleanup());
    };
  }, [isOnline]);

  useEffect(() => {
    if (isOnline && pendingChanges.length > 0) {
      triggerSync();
    }
  }, [isOnline, pendingChanges.length]);

  const addToPendingChanges = (change: any) => {
    setPendingChanges(prev => [...prev, change]);
    setSyncStatus(prev => ({
      ...prev,
      pendingChanges: prev.pendingChanges + 1,
      status: 'offline'
    }));
  };

  const addStudent = async (studentData: Partial<Student>): Promise<Student> => {
    try {
      if (!isOnline) {
        const tempStudent = {
          ...studentData,
          id: `temp_${Date.now()}`,
        } as Student;
        
        setStudents(prev => [...prev, tempStudent]);
        addToPendingChanges({
          type: 'INSERT',
          table: 'students',
          data: studentData
        });
        
        toast.success("Student added (offline mode)");
        return tempStudent;
      }
      
      const preparedData = {
        ...studentData,
        fees: typeof studentData.fees === 'object' ? studentData.fees : { paid: 0, due: 0, lastPaymentDate: '' },
        clubsActivities: Array.isArray(studentData.clubsActivities) ? 
          studentData.clubsActivities : 
          (studentData.clubsActivities ? [studentData.clubsActivities] : [])
      };
      
      const newStudent = await insertData<Student>('students', preparedData);
      console.log("Student added to Supabase:", newStudent);
      
      setStudents(prev => [...prev, newStudent]);
      toast.success("Student added successfully");
      return newStudent;
    } catch (error) {
      console.error("Error adding student:", error);
      toast.error("Failed to add student");
      throw error;
    }
  };

  const updateStudent = async (id: string, studentData: Partial<Student>): Promise<Student> => {
    try {
      if (!isOnline) {
        const updatedStudent = { 
          ...students.find(s => s.id === id), 
          ...studentData, 
          id 
        } as Student;
        
        setStudents(prev => 
          prev.map(student => student.id === id ? updatedStudent : student)
        );
        
        addToPendingChanges({
          type: 'UPDATE',
          table: 'students',
          id,
          data: studentData
        });
        
        toast.success("Student updated (offline mode)");
        return updatedStudent;
      }
      
      const preparedData = {
        ...studentData,
        fees: typeof studentData.fees === 'object' ? studentData.fees : undefined,
        clubsActivities: Array.isArray(studentData.clubsActivities) ? 
          studentData.clubsActivities : 
          (studentData.clubsActivities ? [studentData.clubsActivities] : undefined)
      };
      
      console.log("Updating student in Supabase:", id, preparedData);
      const updatedStudent = await updateData<Student>('students', id, preparedData);
      
      setStudents(prev => prev.map(student => student.id === id ? updatedStudent : student));
      
      toast.success("Student updated successfully");
      return updatedStudent;
    } catch (error) {
      console.error("Error updating student:", error);
      toast.error("Failed to update student");
      throw error;
    }
  };

  const deleteStudent = async (id: string): Promise<void> => {
    try {
      if (!isOnline) {
        setStudents(prev => prev.filter(student => student.id !== id));
        
        addToPendingChanges({
          type: 'DELETE',
          table: 'students',
          id
        });
        
        toast.success("Student deleted (offline mode)");
        return;
      }
      
      console.log("Deleting student from Supabase:", id);
      await deleteData('students', id);
      
      setStudents(prev => prev.filter(student => student.id !== id));
      
      toast.success("Student deleted successfully");
    } catch (error) {
      console.error("Error deleting student:", error);
      toast.error("Failed to delete student");
      throw error;
    }
  };

  const addTeacher = async (teacherData: Partial<Teacher>): Promise<Teacher> => {
    try {
      if (!isOnline) {
        const tempTeacher = {
          ...teacherData,
          id: `temp_${Date.now()}`,
        } as Teacher;
        
        setTeachers(prev => [...prev, tempTeacher]);
        addToPendingChanges({
          type: 'INSERT',
          table: 'teachers',
          data: teacherData
        });
        
        toast.success("Teacher added (offline mode)");
        return tempTeacher;
      }
      
      const newTeacher = await insertData<Teacher>('teachers', teacherData);
      toast.success("Teacher added successfully");
      return newTeacher;
    } catch (error) {
      console.error("Error adding teacher:", error);
      toast.error("Failed to add teacher");
      throw error;
    }
  };

  const updateTeacher = async (id: string, teacherData: Partial<Teacher>): Promise<Teacher> => {
    try {
      if (!isOnline) {
        const updatedTeacher = { 
          ...teachers.find(t => t.id === id), 
          ...teacherData, 
          id 
        } as Teacher;
        
        setTeachers(prev => 
          prev.map(teacher => teacher.id === id ? updatedTeacher : teacher)
        );
        
        addToPendingChanges({
          type: 'UPDATE',
          table: 'teachers',
          id,
          data: teacherData
        });
        
        toast.success("Teacher updated (offline mode)");
        return updatedTeacher;
      }
      
      const updatedTeacher = await updateData<Teacher>('teachers', id, teacherData);
      toast.success("Teacher updated successfully");
      return updatedTeacher;
    } catch (error) {
      console.error("Error updating teacher:", error);
      toast.error("Failed to update teacher");
      throw error;
    }
  };

  const deleteTeacher = async (id: string): Promise<void> => {
    try {
      if (!isOnline) {
        setTeachers(prev => prev.filter(teacher => teacher.id !== id));
        
        addToPendingChanges({
          type: 'DELETE',
          table: 'teachers',
          id
        });
        
        toast.success("Teacher deleted (offline mode)");
        return;
      }
      
      await deleteData('teachers', id);
      toast.success("Teacher deleted successfully");
    } catch (error) {
      console.error("Error deleting teacher:", error);
      toast.error("Failed to delete teacher");
      throw error;
    }
  };

  const addClass = async (classData: Partial<ClassInfo>): Promise<ClassInfo> => {
    try {
      if (!isOnline) {
        const tempClass = {
          ...classData,
          id: `temp_${Date.now()}`,
        } as ClassInfo;
        
        setClasses(prev => [...prev, tempClass]);
        addToPendingChanges({
          type: 'INSERT',
          table: 'classes',
          data: classData
        });
        
        toast.success("Class added (offline mode)");
        return tempClass;
      }
      
      const newClass = await insertData<ClassInfo>('classes', classData);
      toast.success("Class added successfully");
      return newClass;
    } catch (error) {
      console.error("Error adding class:", error);
      toast.error("Failed to add class");
      throw error;
    }
  };

  const updateClass = async (id: string, classData: Partial<ClassInfo>): Promise<ClassInfo> => {
    try {
      if (!isOnline) {
        const updatedClass = { 
          ...classes.find(c => c.id === id), 
          ...classData, 
          id 
        } as ClassInfo;
        
        setClasses(prev => 
          prev.map(cls => cls.id === id ? updatedClass : cls)
        );
        
        addToPendingChanges({
          type: 'UPDATE',
          table: 'classes',
          id,
          data: classData
        });
        
        toast.success("Class updated (offline mode)");
        return updatedClass;
      }
      
      const updatedClass = await updateData<ClassInfo>('classes', id, classData);
      toast.success("Class updated successfully");
      return updatedClass;
    } catch (error) {
      console.error("Error updating class:", error);
      toast.error("Failed to update class");
      throw error;
    }
  };

  const deleteClass = async (id: string): Promise<void> => {
    try {
      if (!isOnline) {
        setClasses(prev => prev.filter(cls => cls.id !== id));
        
        addToPendingChanges({
          type: 'DELETE',
          table: 'classes',
          id
        });
        
        toast.success("Class deleted (offline mode)");
        return;
      }
      
      await deleteData('classes', id);
      toast.success("Class deleted successfully");
    } catch (error) {
      console.error("Error deleting class:", error);
      toast.error("Failed to delete class");
      throw error;
    }
  };

  const triggerSync = async (): Promise<void> => {
    if (!isOnline) {
      toast.error("Cannot sync while offline");
      return;
    }
    
    try {
      setSyncStatus(prev => ({ ...prev, status: 'syncing' }));
      
      for (const change of pendingChanges) {
        if (change.type === 'INSERT') {
          await insertData(change.table, change.data);
        } else if (change.type === 'UPDATE') {
          await updateData(change.table, change.id, change.data);
        } else if (change.type === 'DELETE') {
          await deleteData(change.table, change.id);
        }
      }
      
      setPendingChanges([]);
      
      const remoteStudents = await fetchData<Student>('students');
      setStudents(remoteStudents);
      await saveStudentsToDB(remoteStudents);
      
      const remoteTeachers = await fetchData<Teacher>('teachers');
      setTeachers(remoteTeachers);
      
      const remoteClasses = await fetchData<ClassInfo>('classes');
      setClasses(remoteClasses);
      
      try {
        const remotePayments = await fetchData<Payment>('payments');
        setPayments(remotePayments);
      } catch (error) {
        console.warn('Could not sync payments:', error);
      }
      
      setSyncStatus({
        lastSyncedAt: new Date().toISOString(),
        syncedWithDevices: ['Current Device'],
        pendingChanges: 0,
        status: 'synced',
      });
      
      toast.success("Synced successfully with Supabase");
    } catch (error) {
      console.error("Error syncing data:", error);
      setSyncStatus(prev => ({ ...prev, status: 'error' }));
      toast.error("Failed to sync data");
    }
  };

  const refreshData = async (): Promise<void> => {
    try {
      if (isOnline) {
        setSyncStatus(prev => ({ ...prev, status: 'syncing' }));
        
        const remoteStudents = await fetchData<Student>('students');
        console.log("Fetched remote students:", remoteStudents);
        setStudents(remoteStudents);
        await saveStudentsToDB(remoteStudents);
        
        const remoteTeachers = await fetchData<Teacher>('teachers');
        setTeachers(remoteTeachers);
        
        const remoteClasses = await fetchData<ClassInfo>('classes');
        setClasses(remoteClasses);

        try {
          const remotePayments = await fetchData<Payment>('payments');
          setPayments(remotePayments);
        } catch (error) {
          console.warn('Payments table may not exist yet:', error);
        }
        
        setSyncStatus({
          lastSyncedAt: new Date().toISOString(),
          syncedWithDevices: ['Current Device'],
          pendingChanges: 0,
          status: 'synced',
        });
      } else {
        const localStudents = await loadStudentsFromDB();
        setStudents(localStudents);
      }
    } catch (error) {
      console.error("Error refreshing data:", error);
      setSyncStatus(prev => ({ ...prev, status: 'error' }));
    }
  };

  return (
    <DataContext.Provider
      value={{
        students,
        teachers,
        classes,
        payments,
        syncStatus,
        addStudent,
        updateStudent,
        deleteStudent,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        addClass,
        updateClass,
        deleteClass,
        triggerSync,
        isOnline,
        refreshData // Include the refreshData function in the context value
      }}
    >
      {children}
    </DataContext.Provider>
  );
};
