
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Book, BookOpen, Calendar, Check, Download, Edit, FilePlus, LibraryBig, Search, Trash, User, List } from 'lucide-react';
import { LibraryItem } from '@/types';
import { useMobile } from '@/hooks/use-mobile';

const MOCK_LIBRARY_ITEMS: LibraryItem[] = [
  {
    id: '1',
    title: 'Introduction to Mathematics',
    author: 'John Smith',
    category: 'Mathematics',
    availableCopies: 3,
    totalCopies: 5,
    borrowedBy: [
      {
        userId: 'u1',
        userName: 'Alice Johnson',
        role: 'student',
        borrowDate: '2025-03-15',
        dueDate: '2025-04-15'
      },
      {
        userId: 'u2',
        userName: 'Bob Wilson',
        role: 'student',
        borrowDate: '2025-03-20',
        dueDate: '2025-04-20'
      }
    ]
  },
  {
    id: '2',
    title: 'Advanced Physics',
    author: 'Mary Johnson',
    category: 'Science',
    availableCopies: 2,
    totalCopies: 3,
    borrowedBy: [
      {
        userId: 'u3',
        userName: 'Charlie Brown',
        role: 'student',
        borrowDate: '2025-04-01',
        dueDate: '2025-05-01'
      }
    ]
  },
  {
    id: '3',
    title: 'English Literature Classics',
    author: 'William Parker',
    category: 'Literature',
    availableCopies: 0,
    totalCopies: 2,
    borrowedBy: [
      {
        userId: 'u4',
        userName: 'Diana Evans',
        role: 'student',
        borrowDate: '2025-03-25',
        dueDate: '2025-04-25'
      },
      {
        userId: 't1',
        userName: 'Prof. Robert Davis',
        role: 'teacher',
        borrowDate: '2025-04-05',
        dueDate: '2025-05-05'
      }
    ]
  },
  {
    id: '4',
    title: 'World History: Volume 1',
    author: 'Elizabeth Thomas',
    category: 'History',
    availableCopies: 4,
    totalCopies: 4,
    borrowedBy: []
  },
  {
    id: '5',
    title: 'Chemistry Fundamentals',
    author: 'James Richardson',
    category: 'Science',
    availableCopies: 1,
    totalCopies: 3,
    borrowedBy: [
      {
        userId: 'u5',
        userName: 'Eva Martinez',
        role: 'student',
        borrowDate: '2025-02-20',
        dueDate: '2025-03-20'
      },
      {
        userId: 'u6',
        userName: 'Frank Lee',
        role: 'student',
        borrowDate: '2025-03-10',
        dueDate: '2025-04-10'
      }
    ]
  }
];

const LibraryPage = () => {
  const [activeTab, setActiveTab] = useState('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const isMobile = useMobile();
  
  const categories = ['all', 'Mathematics', 'Science', 'Literature', 'History', 'Geography', 'Art'];
  
  const filteredBooks = MOCK_LIBRARY_ITEMS.filter(item => {
    const matchesSearch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.author.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });
  
  // Get all borrowed books
  const borrowedBooks = MOCK_LIBRARY_ITEMS.flatMap(item => 
    item.borrowedBy.map(borrower => ({
      bookId: item.id,
      bookTitle: item.title,
      ...borrower
    }))
  );
  
  // Get overdue books (those past their due date)
  const overdueBooks = borrowedBooks.filter(book => {
    const dueDate = new Date(book.dueDate);
    return dueDate < new Date();
  });

  return (
    <MainLayout>
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold tracking-tight">Library Management</h1>
          <Button>
            <FilePlus className="h-4 w-4 mr-2" />
            Add New Book
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Books</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {MOCK_LIBRARY_ITEMS.reduce((acc, item) => acc + item.totalCopies, 0)}
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Available Books</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {MOCK_LIBRARY_ITEMS.reduce((acc, item) => acc + item.availableCopies, 0)}
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Borrowed Books</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                {borrowedBooks.length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Overdue Returns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">
                {overdueBooks.length}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="catalog" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-1 sm:grid-cols-3 w-full mb-4">
            <TabsTrigger value="catalog">
              <Book className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Book Catalog</span>}
            </TabsTrigger>
            <TabsTrigger value="borrowed">
              <BookOpen className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Borrowed Books</span>}
            </TabsTrigger>
            <TabsTrigger value="management">
              <List className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Library Management</span>}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="catalog" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Book Catalog</CardTitle>
                <CardDescription>Browse and manage the library collection</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4 justify-between">
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search books..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category} value={category}>
                            {category === 'all' ? 'All Categories' : category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-1" />
                      Export
                    </Button>
                  </div>
                </div>
                
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Author</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead className="text-center">Availability</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredBooks.map((book) => (
                        <TableRow key={book.id}>
                          <TableCell className="font-medium">{book.title}</TableCell>
                          <TableCell>{book.author}</TableCell>
                          <TableCell>{book.category}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={book.availableCopies > 0 ? "outline" : "secondary"}>
                              {book.availableCopies}/{book.totalCopies}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="sm">View</Button>
                              <Button variant="ghost" size="sm">Issue</Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="borrowed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Borrowed Books</CardTitle>
                <CardDescription>Track books currently checked out</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Book Title</TableHead>
                        <TableHead>Borrower</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Borrow Date</TableHead>
                        <TableHead>Due Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {borrowedBooks.map((book, index) => {
                        const dueDate = new Date(book.dueDate);
                        const isOverdue = dueDate < new Date();
                        
                        return (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{book.bookTitle}</TableCell>
                            <TableCell>{book.userName}</TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {book.role === 'teacher' ? 'Teacher' : 'Student'}
                              </Badge>
                            </TableCell>
                            <TableCell>{new Date(book.borrowDate).toLocaleDateString()}</TableCell>
                            <TableCell>{new Date(book.dueDate).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <Badge variant={isOverdue ? "destructive" : "default"}>
                                {isOverdue ? 'Overdue' : 'Active'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm">
                                <Check className="h-4 w-4 mr-1" />
                                Return
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="management" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Book</CardTitle>
                <CardDescription>Enter details to add a new book to the library</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Book Title</label>
                    <Input placeholder="Enter book title" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Author</label>
                    <Input placeholder="Enter author name" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.filter(c => c !== 'all').map(category => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Number of Copies</label>
                    <Input type="number" min="1" defaultValue="1" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button>
                  <LibraryBig className="h-4 w-4 mr-2" />
                  Add to Library
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Library Settings</CardTitle>
                <CardDescription>Configure library policies and operations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Lending Policies</h3>
                    <Separator />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Maximum Books per Student</label>
                        <Input type="number" defaultValue="3" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Maximum Books per Teacher</label>
                        <Input type="number" defaultValue="5" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Loan Period for Students (days)</label>
                        <Input type="number" defaultValue="14" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Loan Period for Teachers (days)</label>
                        <Input type="number" defaultValue="30" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Fine Policies</h3>
                    <Separator />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Late Return Fine (per day)</label>
                        <Input type="text" defaultValue="₹5" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Damaged Book Fine</label>
                        <Input type="text" defaultValue="₹100" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button>Save Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default LibraryPage;
