
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Preloader } from '@/components/ui/preloader';
import { Users, Building, Database, HardDrive, GraduationCap, ClipboardCheck, MessageSquare, Bus, Shield, HelpCircle, Palette } from 'lucide-react';
import { useMobile } from '@/hooks/use-mobile';
import UserManagement from '@/components/settings/UserManagement';
import SchoolProfile from '@/components/settings/SchoolProfile';
import BackupRestore from '@/components/settings/BackupRestore';
import DataManagement from '@/components/settings/DataManagement';
import AcademicSettings from '@/components/settings/AcademicSettings';
import AttendanceSettings from '@/components/settings/AttendanceSettings';
import CommunicationPreferences from '@/components/settings/CommunicationPreferences';
import TransportBoarding from '@/components/settings/TransportBoarding';
import SecuritySettings from '@/components/settings/SecuritySettings';
import SoftwareSupport from '@/components/settings/SoftwareSupport';
import CustomizationThemes from '@/components/settings/CustomizationThemes';
import SiteSettingsPanel from '@/components/settings/SiteSettingsPanel';
import StorageMonitoring from '@/components/settings/StorageMonitoring';

const Settings = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = React.useState("users");
  const [isLoading, setIsLoading] = React.useState(false);
  const isMobile = useMobile();

  React.useEffect(() => {
    // Get section from URL hash or default to "users"
    const section = location.hash.replace('#', '') || 'users';
    setActiveTab(section);
  }, [location]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    navigate(`/settings#${value}`);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
            <p className="text-muted-foreground">
              Manage your school system settings and preferences.
            </p>
          </div>
        </div>

        {/* Storage Monitoring - Always visible at top */}
        <StorageMonitoring />

        <div className="overflow-x-auto pb-2 -mx-4 px-4">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="mb-6 inline-flex flex-nowrap h-auto p-1 min-w-max">
              <TabsTrigger value="users" className="flex-shrink-0">
                <Users className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Users</span>}
              </TabsTrigger>
              <TabsTrigger value="school" className="flex-shrink-0">
                <Building className="h-4 w-4" />
                {!isMobile && <span className="ml-2">School</span>}
              </TabsTrigger>
              <TabsTrigger value="backup" className="flex-shrink-0">
                <Database className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Backup</span>}
              </TabsTrigger>
              <TabsTrigger value="data" className="flex-shrink-0">
                <HardDrive className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Data</span>}
              </TabsTrigger>
              <TabsTrigger value="academic" className="flex-shrink-0">
                <GraduationCap className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Academic</span>}
              </TabsTrigger>
              <TabsTrigger value="attendance" className="flex-shrink-0">
                <ClipboardCheck className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Attendance</span>}
              </TabsTrigger>
              <TabsTrigger value="communication" className="flex-shrink-0">
                <MessageSquare className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Comms</span>}
              </TabsTrigger>
              <TabsTrigger value="transport" className="flex-shrink-0">
                <Bus className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Transport</span>}
              </TabsTrigger>
              <TabsTrigger value="security" className="flex-shrink-0">
                <Shield className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Security</span>}
              </TabsTrigger>
              <TabsTrigger value="support" className="flex-shrink-0">
                <HelpCircle className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Support</span>}
              </TabsTrigger>
              <TabsTrigger value="customization" className="flex-shrink-0">
                <Palette className="h-4 w-4" />
                {!isMobile && <span className="ml-2">Theme</span>}
              </TabsTrigger>
            </TabsList>
            
            <Card className="p-6">
              {isLoading ? (
                <div className="w-full h-96 flex items-center justify-center">
                  <Preloader size="lg" text="Loading settings..." />
                </div>
              ) : (
                <>
                  {activeTab === "users" && <UserManagement />}
                  {activeTab === "school" && <SchoolProfile />}
                  {activeTab === "backup" && <BackupRestore />}
                  {activeTab === "data" && <DataManagement />}
                  {activeTab === "academic" && <AcademicSettings />}
                  {activeTab === "attendance" && <AttendanceSettings />}
                  {activeTab === "communication" && <CommunicationPreferences />}
                  {activeTab === "transport" && <TransportBoarding />}
                  {activeTab === "security" && <SecuritySettings />}
                  {activeTab === "support" && <SoftwareSupport />}
                  {activeTab === "customization" && (
                    <>
                      <SiteSettingsPanel />
                      <CustomizationThemes />
                    </>
                  )}
                </>
              )}
            </Card>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

export default Settings;
