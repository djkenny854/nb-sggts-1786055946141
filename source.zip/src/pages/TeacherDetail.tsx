
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import TeacherProfile from '@/components/teachers/TeacherProfile';
import TeacherDetailSkeleton from '@/components/teachers/TeacherDetailSkeleton';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { fetchTeacherById } from '@/utils/supabaseHelpers';

const TeacherDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const { data: teacher, isLoading, error } = useQuery({
    queryKey: ['teacher', id],
    queryFn: async () => {
      if (!id) throw new Error('Teacher ID is required');
      return await fetchTeacherById(id);
    },
    enabled: !!id,
  });
  
  if (isLoading) {
    return <TeacherDetailSkeleton />;
  }
  
  if (error || !teacher) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <h2 className="text-xl font-semibold mb-2">Teacher not found</h2>
          <p className="text-muted-foreground mb-4">The teacher you're looking for doesn't exist or was removed.</p>
          <Button onClick={() => navigate('/teachers')}>Back to Teachers</Button>
        </div>
      </MainLayout>
    );
  }
  
  // Transform teacher data to match TeacherProfile component props
  const teacherProfileData = {
    id: teacher.id,
    name: teacher.name,
    email: teacher.email || '',
    phone: teacher.phone || '',
    address: teacher.address || '',
    dateJoined: teacher.joinDate || teacher.hireDate || '',
    qualification: teacher.qualification || '',
    department: teacher.specialization || 'General',
    subjects: [], // This would need to be populated from actual subject data
    classes: [], // This would need to be populated from actual class data
    profileImage: teacher.profileImage,
    profile_image_url: teacher.profileImage,
    specialization: teacher.specialization,
    status: (teacher.status as 'active' | 'on leave' | 'former') || 'active',
    biography: teacher.biography,
  };
  
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => navigate('/teachers')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">Teacher Details</h1>
        </div>
        
        <TeacherProfile teacher={teacherProfileData} />
      </div>
    </MainLayout>
  );
};

export default TeacherDetail;
