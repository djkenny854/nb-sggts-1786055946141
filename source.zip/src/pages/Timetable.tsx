import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Download, FileSpreadsheet } from 'lucide-react';
import WeeklyTimetable from '@/components/timetable/WeeklyTimetable';
import TimetableControls from '@/components/timetable/TimetableControls';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const Timetable = () => {
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const { toast } = useToast();
  
  // Fetch available classes from students table
  const { data: classes = [], isLoading: classesLoading } = useQuery({
    queryKey: ['available-classes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('available_classes')
        .select('*');
      
      if (error) throw error;
      return data || [];
    },
  });

  // Auto-select first class when classes load
  React.useEffect(() => {
    if (classes.length > 0 && !selectedClass) {
      setSelectedClass(classes[0].class_name);
    }
  }, [classes, selectedClass]);

  const exportTimetable = async (exportType: 'current' | 'all') => {
    try {
      let timetableData;
      
      if (exportType === 'current') {
        const { data, error } = await supabase
          .from('timetable')
          .select(`
            *,
            subjects(name, code),
            teachers(name)
          `)
          .eq('class_name', selectedClass)
          .order('day_of_week')
          .order('period_number');
        
        if (error) throw error;
        timetableData = data;
      } else {
        const { data, error } = await supabase
          .from('timetable')
          .select(`
            *,
            subjects(name, code),
            teachers(name)
          `)
          .order('class_name')
          .order('day_of_week')
          .order('period_number');
        
        if (error) throw error;
        timetableData = data;
      }

      // Convert to CSV
      const headers = ['Class', 'Day', 'Period', 'Start Time', 'End Time', 'Subject', 'Teacher', 'Room'];
      const csvContent = [
        headers.join(','),
        ...timetableData.map(entry => [
          entry.class_name,
          ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][entry.day_of_week],
          entry.period_number,
          entry.start_time,
          entry.end_time,
          entry.subjects?.name || 'Unknown Subject',
          entry.teachers?.name || 'Unknown Teacher',
          entry.room || ''
        ].join(','))
      ].join('\n');

      // Download file
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `timetable_${exportType === 'current' ? selectedClass : 'all_classes'}_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `Timetable exported for ${exportType === 'current' ? selectedClass : 'all classes'}`
      });
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export timetable data",
        variant: "destructive"
      });
    }
  };

  if (classesLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent mx-auto mb-2"></div>
            <p className="text-sm text-muted-foreground">Loading classes...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Class Timetable</h1>
          <p className="text-muted-foreground mt-2">
            View and manage class schedules and time allocations for all classes.
          </p>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Timetable View {isEditMode && '(Editing Mode)'}</CardTitle>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                <Select value={selectedClass} onValueChange={setSelectedClass} disabled={isEditMode}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((classItem) => (
                      <SelectItem key={classItem.class_name} value={classItem.class_name}>
                        {classItem.class_name} ({classItem.student_count} students)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => exportTimetable('current')}
                    disabled={!selectedClass}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export {selectedClass}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => exportTimetable('all')}
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Export All
                  </Button>
                </div>
              </div>
              
              <TimetableControls 
                isEditMode={isEditMode} 
                setIsEditMode={setIsEditMode} 
                selectedClass={selectedClass}
              />
            </div>
          </CardHeader>
          <CardContent>
            {selectedClass ? (
              <WeeklyTimetable selectedClass={selectedClass} />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                Please select a class to view the timetable
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default Timetable;
