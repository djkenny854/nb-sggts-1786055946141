
import { Student, PaymentRecord } from '@/types';
import { supabase, insertData, updateData, deleteData } from '@/lib/supabase';

// Database configuration
const DB_NAME = 'school_management_system';
const DB_VERSION = 1;
const STUDENTS_STORE = 'students';
const PAYMENTS_STORE = 'payments';

// Open database connection
const openDatabase = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = (event) => {
      reject('Error opening database');
    };
    
    request.onsuccess = (event) => {
      const db = request.result;
      resolve(db);
    };
    
    request.onupgradeneeded = (event) => {
      const db = request.result;
      
      // Create students store if it doesn't exist
      if (!db.objectStoreNames.contains(STUDENTS_STORE)) {
        const studentsStore = db.createObjectStore(STUDENTS_STORE, { keyPath: 'id' });
        studentsStore.createIndex('classId', 'classId', { unique: false });
        studentsStore.createIndex('enrollmentNumber', 'enrollmentNumber', { unique: true });
      }
      
      // Create payments store if it doesn't exist
      if (!db.objectStoreNames.contains(PAYMENTS_STORE)) {
        const paymentsStore = db.createObjectStore(PAYMENTS_STORE, { keyPath: 'id' });
        paymentsStore.createIndex('studentId', 'studentId', { unique: false });
        paymentsStore.createIndex('date', 'date', { unique: false });
      }
    };
  });
};

// Load all students from IndexedDB
export const loadStudentsFromDB = (): Promise<Student[]> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readonly');
      const store = transaction.objectStore(STUDENTS_STORE);
      const request = store.getAll();
      
      request.onsuccess = () => {
        resolve(request.result);
      };
      
      request.onerror = () => {
        reject('Error loading students from database');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Save multiple students to IndexedDB
export const saveStudentsToDB = (students: Student[]): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
      const store = transaction.objectStore(STUDENTS_STORE);
      
      // Clear existing students
      store.clear();
      
      // Add each student
      students.forEach(student => {
        store.add(student);
      });
      
      transaction.oncomplete = () => {
        resolve();
      };
      
      transaction.onerror = () => {
        reject('Error saving students to database');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Add a single student to IndexedDB
export const addStudentToDB = (student: Student): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      if (!student || !student.id) {
        reject('Invalid student data: Missing ID');
        return;
      }
      
      console.log('Adding student to DB:', student);
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
      const store = transaction.objectStore(STUDENTS_STORE);
      
      const request = store.add(student);
      
      request.onsuccess = () => {
        console.log('Student added to DB successfully with ID:', student.id);
        
        // Sync with Supabase
        syncStudentToSupabase(student, 'insert')
          .then(() => {
            console.log('Student synced with Supabase successfully');
            resolve();
          })
          .catch((syncError) => {
            console.warn('Student saved locally but failed to sync with Supabase:', syncError);
            resolve(); // Still resolve as local save was successful
          });
      };
      
      request.onerror = (event) => {
        console.error('Error adding student to DB:', event);
        reject('Error adding student to database');
      };
    } catch (error) {
      console.error('Exception adding student to DB:', error);
      reject(error);
    }
  });
};

// Update a student in IndexedDB
export const updateStudentInDB = (student: Student): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
      const store = transaction.objectStore(STUDENTS_STORE);
      
      const request = store.put(student);
      
      request.onsuccess = () => {
        console.log('Student updated in IndexedDB successfully');
        
        // Sync with Supabase
        syncStudentToSupabase(student, 'update')
          .then(() => {
            console.log('Student update synced with Supabase successfully');
            resolve();
          })
          .catch((syncError) => {
            console.warn('Student updated locally but failed to sync with Supabase:', syncError);
            resolve(); // Still resolve as local update was successful
          });
      };
      
      request.onerror = () => {
        reject('Error updating student in database');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Delete a student from IndexedDB
export const deleteStudentFromDB = (studentId: string): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
      const store = transaction.objectStore(STUDENTS_STORE);
      
      const request = store.delete(studentId);
      
      request.onsuccess = () => {
        console.log('Student deleted from IndexedDB successfully');
        
        // Delete associated payments and sync deletion with Supabase
        deletePaymentsByStudentId(studentId)
          .then(() => {
            // Sync deletion with Supabase
            syncStudentDeletionToSupabase(studentId)
              .then(() => {
                console.log('Student deletion synced with Supabase successfully');
                resolve();
              })
              .catch((syncError) => {
                console.warn('Student deleted locally but failed to sync deletion with Supabase:', syncError);
                resolve(); // Still resolve as local deletion was successful
              });
          })
          .catch(reject);
      };
      
      request.onerror = () => {
        reject('Error deleting student from database');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Sync a student to Supabase
const syncStudentToSupabase = async (student: Student, operation: 'insert' | 'update'): Promise<void> => {
  try {
    console.log(`Syncing student to Supabase with operation: ${operation}`, student);
    
    // Check if Supabase is configured
    if (!supabase || typeof supabase.from !== 'function') {
      console.warn('Supabase not configured, skipping sync');
      return;
    }
    
    if (operation === 'insert') {
      // Insert new student
      await insertData<Student>('students', student);
      console.log('Student inserted in Supabase:', student.id);
    } else {
      // Update existing student
      await updateData<Student>('students', student.id, student);
      console.log('Student updated in Supabase:', student.id);
    }
  } catch (error) {
    console.error('Error syncing student with Supabase:', error);
    throw error;
  }
};

// Sync student deletion to Supabase
const syncStudentDeletionToSupabase = async (studentId: string): Promise<void> => {
  try {
    console.log('Syncing student deletion to Supabase:', studentId);
    
    // Check if Supabase is configured
    if (!supabase || typeof supabase.from !== 'function') {
      console.warn('Supabase not configured, skipping deletion sync');
      return;
    }
    
    // Delete from Supabase
    await deleteData('students', studentId);
    console.log('Student deleted from Supabase:', studentId);
  } catch (error) {
    console.error('Error syncing student deletion with Supabase:', error);
    throw error;
  }
};

// Get a student by ID - updated for better error handling
export const getStudentById = (studentId: string): Promise<Student | null> => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(`Fetching student with ID: ${studentId}`);
      
      if (!studentId) {
        console.error("Invalid student ID provided:", studentId);
        resolve(null);
        return;
      }
      
      const db = await openDatabase();
      const transaction = db.transaction([STUDENTS_STORE], 'readonly');
      const store = transaction.objectStore(STUDENTS_STORE);
      
      const request = store.get(studentId);
      
      request.onsuccess = () => {
        const student = request.result;
        console.log("Student fetch result:", student);
        resolve(student || null);
      };
      
      request.onerror = (event) => {
        console.error("Error fetching student:", event);
        reject('Error getting student by ID');
      };
    } catch (error) {
      console.error("Exception fetching student:", error);
      reject(error);
    }
  });
};

// Add a payment record
export const addPaymentRecord = (payment: PaymentRecord): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([PAYMENTS_STORE], 'readwrite');
      const store = transaction.objectStore(PAYMENTS_STORE);
      
      const request = store.add(payment);
      
      request.onsuccess = () => {
        resolve();
      };
      
      request.onerror = () => {
        reject('Error adding payment record');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Update a payment record
export const updatePaymentRecord = (payment: PaymentRecord): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([PAYMENTS_STORE], 'readwrite');
      const store = transaction.objectStore(PAYMENTS_STORE);
      
      const request = store.put(payment);
      
      request.onsuccess = () => {
        resolve();
      };
      
      request.onerror = () => {
        reject('Error updating payment record');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Delete a payment record
export const deletePaymentRecord = (paymentId: string): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([PAYMENTS_STORE], 'readwrite');
      const store = transaction.objectStore(PAYMENTS_STORE);
      
      const request = store.delete(paymentId);
      
      request.onsuccess = () => {
        resolve();
      };
      
      request.onerror = () => {
        reject('Error deleting payment record');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Delete all payments for a student
export const deletePaymentsByStudentId = (studentId: string): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([PAYMENTS_STORE], 'readwrite');
      const store = transaction.objectStore(PAYMENTS_STORE);
      const index = store.index('studentId');
      
      const request = index.openCursor(IDBKeyRange.only(studentId));
      
      request.onsuccess = (event) => {
        const cursor = request.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        } else {
          resolve();
        }
      };
      
      request.onerror = () => {
        reject('Error deleting student payments');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Get all payments for a student
export const getPaymentsByStudentId = (studentId: string): Promise<PaymentRecord[]> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDatabase();
      const transaction = db.transaction([PAYMENTS_STORE], 'readonly');
      const store = transaction.objectStore(PAYMENTS_STORE);
      const index = store.index('studentId');
      
      const request = index.getAll(IDBKeyRange.only(studentId));
      
      request.onsuccess = () => {
        resolve(request.result);
      };
      
      request.onerror = () => {
        reject('Error getting payments by student ID');
      };
    } catch (error) {
      reject(error);
    }
  });
};

// Add a payment to a student
export const addPaymentToStudent = async (studentId: string, payment: PaymentRecord): Promise<Student | null> => {
  try {
    // Get the student
    const student = await getStudentById(studentId);
    if (!student) {
      throw new Error('Student not found');
    }
    
    // Initialize payments array if it doesn't exist
    if (!student.payments) {
      student.payments = [];
    }
    
    // Add the payment
    student.payments.push(payment);
    
    // Update the student's fees paid and due
    student.fees = {
      ...student.fees,
      paid: (student.fees.paid || 0) + payment.amount,
      due: (student.fees.due || 0) - payment.amount
    };
    
    // Update the student in the database
    await updateStudentInDB(student);
    
    return student;
  } catch (error) {
    console.error('Error adding payment to student:', error);
    throw error;
  }
};

// Update a payment for a student
export const updatePaymentInStudent = async (
  studentId: string,
  paymentId: string,
  updatedPayment: Partial<PaymentRecord>
): Promise<Student | null> => {
  try {
    // Get the student
    const student = await getStudentById(studentId);
    if (!student || !student.payments) {
      throw new Error('Student not found or has no payments');
    }
    
    // Find the payment
    const paymentIndex = student.payments.findIndex(p => p.id === paymentId);
    if (paymentIndex === -1) {
      throw new Error('Payment not found');
    }
    
    // Calculate the difference in amount
    const oldAmount = student.payments[paymentIndex].amount;
    const newAmount = updatedPayment.amount !== undefined ? updatedPayment.amount : oldAmount;
    const amountDifference = newAmount - oldAmount;
    
    // Update the payment
    student.payments[paymentIndex] = {
      ...student.payments[paymentIndex],
      ...updatedPayment
    };
    
    // Update the student's fees paid and due if amount changed
    if (amountDifference !== 0) {
      student.fees = {
        ...student.fees,
        paid: (student.fees.paid || 0) + amountDifference,
        due: (student.fees.due || 0) - amountDifference
      };
    }
    
    // Update the student in the database
    await updateStudentInDB(student);
    
    return student;
  } catch (error) {
    console.error('Error updating payment in student:', error);
    throw error;
  }
};

// Delete a payment from a student
export const deletePaymentFromStudent = async (
  studentId: string,
  paymentId: string
): Promise<Student | null> => {
  try {
    // Get the student
    const student = await getStudentById(studentId);
    if (!student || !student.payments) {
      throw new Error('Student not found or has no payments');
    }
    
    // Find the payment
    const paymentIndex = student.payments.findIndex(p => p.id === paymentId);
    if (paymentIndex === -1) {
      throw new Error('Payment not found');
    }
    
    // Get the amount that will be removed
    const amount = student.payments[paymentIndex].amount;
    
    // Remove the payment
    student.payments = student.payments.filter(p => p.id !== paymentId);
    
    // Update the student's fees paid and due
    student.fees = {
      ...student.fees,
      paid: Math.max(0, (student.fees.paid || 0) - amount),
      due: (student.fees.due || 0) + amount
    };
    
    // Update the student in the database
    await updateStudentInDB(student);
    
    return student;
  } catch (error) {
    console.error('Error deleting payment from student:', error);
    throw error;
  }
};
