
import { supabase } from '@/integrations/supabase/client';
import { Message, MessageTemplate, CommunicationSettings, MessageLog, ContactGroup, MessageTrigger } from '@/types/messaging';

export class MessagingService {
  // Message operations
  static async fetchMessages(): Promise<Message[]> {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return (data || []) as Message[];
    } catch (error) {
      console.error('Error fetching messages:', error);
      return [];
    }
  }

  static async createMessage(messageData: Omit<Message, 'id' | 'created_at' | 'updated_at'>): Promise<Message | null> {
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert(messageData)
        .select()
        .single();
      
      if (error) throw error;
      return data as Message;
    } catch (error) {
      console.error('Error creating message:', error);
      return null;
    }
  }

  // Add the missing sendMessage method
  static async sendMessage(messageData: any): Promise<Message | null> {
    try {
      const formattedData = {
        title: messageData.title,
        content: messageData.content,
        channel: messageData.channel,
        recipient_type: messageData.recipient_type,
        recipient_ids: messageData.recipient_ids,
        status: 'pending' as const,
        scheduled_at: messageData.scheduled_at,
        delivery_status: {},
        metadata: messageData.metadata || {},
      };

      const { data, error } = await supabase
        .from('messages')
        .insert(formattedData)
        .select()
        .single();
      
      if (error) throw error;
      return data as Message;
    } catch (error) {
      console.error('Error sending message:', error);
      return null;
    }
  }

  static async updateMessageStatus(messageId: string, status: Message['status'], deliveryStatus?: Record<string, any>): Promise<boolean> {
    try {
      const updateData: any = { status };
      if (status === 'sent') updateData.sent_at = new Date().toISOString();
      if (deliveryStatus) updateData.delivery_status = deliveryStatus;

      const { error } = await supabase
        .from('messages')
        .update(updateData)
        .eq('id', messageId);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating message status:', error);
      return false;
    }
  }

  // Template operations
  static async fetchTemplates(): Promise<MessageTemplate[]> {
    try {
      const { data, error } = await supabase
        .from('message_templates')
        .select('*')
        .order('category', { ascending: true });
      
      if (error) throw error;
      return (data || []) as MessageTemplate[];
    } catch (error) {
      console.error('Error fetching templates:', error);
      return [];
    }
  }

  static async createTemplate(template: Omit<MessageTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<MessageTemplate | null> {
    try {
      const { data, error } = await supabase
        .from('message_templates')
        .insert(template)
        .select()
        .single();
      
      if (error) throw error;
      return data as MessageTemplate;
    } catch (error) {
      console.error('Error creating template:', error);
      return null;
    }
  }

  // Communication settings
  static async fetchCommunicationSettings(): Promise<CommunicationSettings[]> {
    try {
      const { data, error } = await supabase
        .from('communication_settings')
        .select('*')
        .order('setting_type', { ascending: true });
      
      if (error) throw error;
      return (data || []) as CommunicationSettings[];
    } catch (error) {
      console.error('Error fetching communication settings:', error);
      return [];
    }
  }

  static async updateCommunicationSettings(settingId: string, configuration: Record<string, any>, isActive?: boolean): Promise<boolean> {
    try {
      const updateData: any = { configuration };
      if (isActive !== undefined) updateData.is_active = isActive;

      const { error } = await supabase
        .from('communication_settings')
        .update(updateData)
        .eq('id', settingId);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating communication settings:', error);
      return false;
    }
  }

  // Contact groups
  static async fetchContactGroups(): Promise<ContactGroup[]> {
    try {
      const { data, error } = await supabase
        .from('contact_groups')
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      return (data || []) as ContactGroup[];
    } catch (error) {
      console.error('Error fetching contact groups:', error);
      return [];
    }
  }

  static async createContactGroup(group: Omit<ContactGroup, 'id' | 'created_at' | 'updated_at'>): Promise<ContactGroup | null> {
    try {
      const { data, error } = await supabase
        .from('contact_groups')
        .insert(group)
        .select()
        .single();
      
      if (error) throw error;
      return data as ContactGroup;
    } catch (error) {
      console.error('Error creating contact group:', error);
      return null;
    }
  }

  // Message logs and analytics
  static async fetchMessageLogs(messageId?: string): Promise<MessageLog[]> {
    try {
      let query = supabase
        .from('message_logs')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (messageId) {
        query = query.eq('message_id', messageId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return (data || []) as MessageLog[];
    } catch (error) {
      console.error('Error fetching message logs:', error);
      return [];
    }
  }

  static async createMessageLog(log: Omit<MessageLog, 'id' | 'created_at'>): Promise<MessageLog | null> {
    try {
      const { data, error } = await supabase
        .from('message_logs')
        .insert(log)
        .select()
        .single();
      
      if (error) throw error;
      return data as MessageLog;
    } catch (error) {
      console.error('Error creating message log:', error);
      return null;
    }
  }

  // Dynamic group resolution
  static async resolveDynamicGroup(groupType: ContactGroup['group_type']): Promise<string[]> {
    try {
      switch (groupType) {
        case 'all_parents':
          const { data: students } = await supabase
            .from('students')
            .select('id, parent_contact')
            .not('parent_contact', 'is', null);
          return students?.map(s => s.id) || [];

        case 'all_teachers':
          const { data: teachers } = await supabase
            .from('teachers')
            .select('id');
          return teachers?.map(t => t.id) || [];

        case 'fee_defaulters':
          const { data: defaulters } = await supabase
            .from('student_fees')
            .select('student_id')
            .gt('balance', 0);
          return defaulters?.map(d => d.student_id) || [];

        default:
          return [];
      }
    } catch (error) {
      console.error('Error resolving dynamic group:', error);
      return [];
    }
  }

  // Template variable replacement
  static replaceTemplateVariables(content: string, variables: Record<string, string>): string {
    let processedContent = content;
    Object.entries(variables).forEach(([key, value]) => {
      const placeholder = `[${key}]`;
      processedContent = processedContent.replace(new RegExp(placeholder, 'g'), value);
    });
    return processedContent;
  }

  // Message composition helper
  static async composeMessage(
    templateId: string,
    recipients: string[],
    channel: Message['channel'],
    variables: Record<string, string> = {},
    scheduledAt?: string
  ): Promise<Message | null> {
    try {
      const { data: template, error: templateError } = await supabase
        .from('message_templates')
        .select('*')
        .eq('id', templateId)
        .single();

      if (templateError || !template) {
        console.error('Template not found:', templateError);
        return null;
      }

      const processedContent = this.replaceTemplateVariables(template.content, variables);
      const processedTitle = this.replaceTemplateVariables(template.title, variables);

      const messageData: Omit<Message, 'id' | 'created_at' | 'updated_at'> = {
        title: processedTitle,
        content: processedContent,
        channel,
        recipient_type: recipients.length === 1 ? 'individual' : 'group',
        recipient_ids: recipients,
        status: 'pending',
        scheduled_at: scheduledAt,
        delivery_status: {},
        metadata: {
          template_id: templateId,
          variables,
        },
      };

      return await this.createMessage(messageData);
    } catch (error) {
      console.error('Error composing message:', error);
      return null;
    }
  }
}
