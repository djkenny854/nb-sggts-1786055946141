import { supabase } from '@/integrations/supabase/client';
import { Student, Teacher, PaymentRecord } from '@/types';

// Student Operations
export const fetchStudentsWithFees = async (): Promise<Student[]> => {
  try {
    console.log('Fetching students from Supabase...');
    const { data, error } = await supabase
      .from('students')
      .select(`
        *,
        student_fees (
          total_assigned_fees,
          total_paid,
          balance
        )
      `)
      .order('full_name');
    
    if (error) {
      console.error('Error fetching students:', error);
      throw error;
    }
    
    console.log('Successfully fetched students:', data?.length || 0);
    return (data || []).map(student => ({
      id: student.id,
      name: student.full_name,
      enrollmentNumber: student.student_id,
      className: student.class,
      classId: student.class, // Add missing classId field
      dateOfBirth: student.date_of_birth || '',
      gender: student.gender || '',
      parentName: student.parent_name || '',
      parentContact: student.parent_contact || '',
      address: student.address || '',
      joinDate: student.join_date || '',
      boardingStatus: student.boarding_status as 'Boarding' | 'Day',
      transportUse: student.transport as 'Yes' | 'No',
      email: student.email || '',
      bloodGroup: student.blood_group || '',
      emergencyContact: student.emergency_contact || '',
      medicalConditions: student.medical_conditions || '',
      bestColor: student.best_color || '',
      clubsActivities: student.clubs_activities || [],
      profileImage: student.profile_image_url || '',
      fees: {
        paid: student.student_fees?.[0]?.total_paid || 0,
        due: student.student_fees?.[0]?.balance || 0,
        lastPaymentDate: null
      }
    }));
  } catch (error) {
    console.error('Error in fetchStudents:', error);
    return [];
  }
};

// Use fetchStudentsWithFees as the main fetchStudents function
export const fetchStudents = fetchStudentsWithFees;

export const fetchStudentById = async (id: string): Promise<Student> => {
  try {
    console.log(`Fetching student with ID: ${id}`);
    const { data, error } = await supabase
      .from('students')
      .select(`
        *,
        payments(*),
        student_fees (
          total_assigned_fees,
          total_paid,
          balance
        )
      `)
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching student:', error);
      throw error;
    }
    
    console.log('Successfully fetched student:', data?.full_name || id);
    return transformStudentFromDB(data) as Student;
  } catch (error) {
    console.error('Error in fetchStudentById:', error);
    throw error;
  }
};

export const insertStudent = async (studentData: Omit<Student, 'id'>): Promise<Student> => {
  try {
    // Transform Student type to match database schema
    const dbStudentData = {
      full_name: studentData.name,
      student_id: studentData.enrollmentNumber,
      class: studentData.className,
      date_of_birth: studentData.dateOfBirth,
      gender: studentData.gender,
      parent_name: studentData.parentName,
      parent_contact: studentData.parentContact,
      address: studentData.address,
      join_date: studentData.joinDate,
      boarding_status: studentData.boardingStatus,
      transport: studentData.transportUse,
      email: studentData.email,
      blood_group: studentData.bloodGroup,
      emergency_contact: studentData.emergencyContact,
      medical_conditions: studentData.medicalConditions,
      best_color: studentData.bestColor,
      clubs_activities: studentData.clubsActivities,
      profile_image_url: studentData.profileImage,
      fee_status: 'Unpaid'
    };

    const { data, error } = await supabase
      .from('students')
      .insert([dbStudentData])
      .select()
      .single();

    if (error) throw error;

    // Transform back to Student type
    const student: Student = {
      id: data.id,
      name: data.full_name,
      enrollmentNumber: data.student_id,
      className: data.class,
      classId: data.class,
      dateOfBirth: data.date_of_birth || '',
      gender: data.gender || '',
      parentName: data.parent_name || '',
      parentContact: data.parent_contact || '',
      address: data.address || '',
      joinDate: data.join_date || '',
      boardingStatus: data.boarding_status as 'Boarding' | 'Day',
      transportUse: data.transport as 'Yes' | 'No',
      email: data.email || '',
      bloodGroup: data.blood_group || '',
      emergencyContact: data.emergency_contact || '',
      medicalConditions: data.medical_conditions || '',
      bestColor: data.best_color || '',
      clubsActivities: data.clubs_activities || [],
      profileImage: data.profile_image_url || '',
      fees: { paid: 0, due: 0, lastPaymentDate: null }
    };

    return student;
  } catch (error) {
    console.error('Error inserting student:', error);
    throw error;
  }
};

export const updateStudent = async (id: string, student: Partial<Student>): Promise<Student> => {
  try {
    const dbStudent = transformStudentToDB(student);
    console.log('Updating student with id:', id, 'Data:', dbStudent);
    
    const { data, error } = await supabase
      .from('students')
      .update(dbStudent)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating student:', error);
      throw error;
    }
    
    console.log('Student updated successfully:', data);
    return transformStudentFromDB(data) as Student;
  } catch (error) {
    console.error('Error in updateStudent:', error);
    throw error;
  }
};

export const deleteStudent = async (id: string): Promise<void> => {
  try {
    console.log('Deleting student with ID:', id);
    const { error } = await supabase
      .from('students')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting student:', error);
      throw error;
    }
    
    console.log('Student deleted successfully:', id);
  } catch (error) {
    console.error('Error in deleteStudent:', error);
    throw error;
  }
};

// Teacher Operations
export const fetchTeachers = async (): Promise<Teacher[]> => {
  try {
    console.log('Fetching teachers from Supabase...');
    const { data, error } = await supabase
      .from('teachers')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching teachers:', error);
      throw error;
    }
    
    console.log('Successfully fetched teachers:', data?.length || 0);
    return data.map(transformTeacherFromDB) as Teacher[];
  } catch (error) {
    console.error('Error in fetchTeachers:', error);
    return [];
  }
};

export const fetchTeacherById = async (id: string): Promise<Teacher> => {
  try {
    console.log(`Fetching teacher with ID: ${id}`);
    const { data, error } = await supabase
      .from('teachers')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching teacher:', error);
      throw error;
    }
    
    console.log('Successfully fetched teacher:', data?.name || id);
    return transformTeacherFromDB(data) as Teacher;
  } catch (error) {
    console.error('Error in fetchTeacherById:', error);
    throw error;
  }
};

export const insertTeacher = async (teacher: Omit<Teacher, 'id'>): Promise<Teacher> => {
  try {
    console.log('Inserting teacher:', teacher);
    const dbTeacher = transformTeacherToDB(teacher);
    console.log('Transformed for DB:', dbTeacher);
    
    const { data, error } = await supabase
      .from('teachers')
      .insert(dbTeacher)
      .select()
      .single();
    
    if (error) {
      console.error('Error inserting teacher:', error);
      throw error;
    }
    
    console.log('Teacher inserted successfully:', data);
    return transformTeacherFromDB(data) as Teacher;
  } catch (error) {
    console.error('Error in insertTeacher:', error);
    throw error;
  }
};

export const updateTeacher = async (id: string, teacher: Partial<Teacher>): Promise<Teacher> => {
  try {
    const dbTeacher = transformTeacherToDB(teacher);
    console.log('Updating teacher with id:', id, 'Data:', dbTeacher);
    
    const { data, error } = await supabase
      .from('teachers')
      .update(dbTeacher)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating teacher:', error);
      throw error;
    }
    
    console.log('Teacher updated successfully:', data);
    return transformTeacherFromDB(data) as Teacher;
  } catch (error) {
    console.error('Error in updateTeacher:', error);
    throw error;
  }
};

export const deleteTeacher = async (id: string): Promise<void> => {
  try {
    console.log('Deleting teacher with ID:', id);
    const { error } = await supabase
      .from('teachers')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting teacher:', error);
      throw error;
    }
    
    console.log('Teacher deleted successfully:', id);
  } catch (error) {
    console.error('Error in deleteTeacher:', error);
    throw error;
  }
};

// Subjects Operations
export const fetchSubjects = async () => {
  try {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .order('name');
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching subjects:', error);
    return [];
  }
};

export const fetchTimetable = async (classId?: string, dayOfWeek?: number) => {
  try {
    let query = supabase
      .from('timetable')
      .select(`
        *,
        subject:subjects(name, code),
        teacher:teachers(name)
      `)
      .order('day_of_week')
      .order('start_time');
    
    if (classId) query = query.eq('class_name', classId);
    if (dayOfWeek !== undefined) query = query.eq('day_of_week', dayOfWeek);
    
    const { data, error } = await query;
    if (error) throw error;
    
    return data || [];
  } catch (error) {
    console.error('Error fetching timetable:', error);
    return [];
  }
};

// Class Streams Operations
export const fetchClassStreams = async () => {
  try {
    const { data, error } = await supabase
      .from('class_streams')
      .select('*')
      .order('class_level', { ascending: true });
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching class streams:', error);
    return [];
  }
};

// Payment Operations
export const fetchPayments = async (studentId?: string): Promise<PaymentRecord[]> => {
  let query = supabase
    .from('payments')
    .select('*')
    .order('date', { ascending: false });
  
  if (studentId) {
    query = query.eq('student_id', studentId);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching payments:', error);
    throw error;
  }
  
  return data.map(transformPaymentFromDB) as PaymentRecord[];
};

export const insertPayment = async (payment: Omit<PaymentRecord, 'id' | 'createdAt'>): Promise<PaymentRecord> => {
  try {
    const dbPayment = transformPaymentToDB(payment);
    console.log('Inserting payment:', dbPayment);
    
    const { data, error } = await supabase
      .from('payments')
      .insert(dbPayment)
      .select()
      .single();
    
    if (error) {
      console.error('Error inserting payment:', error);
      throw error;
    }
    
    console.log('Payment inserted successfully:', data);
    return transformPaymentFromDB(data) as PaymentRecord;
  } catch (error) {
    console.error('Error in insertPayment:', error);
    throw error;
  }
};

// Record a fee payment
export const recordFeePayment = async (studentId: string, paymentData: {
  amount: number;
  paymentMethod: string;
  receiptNumber?: string;
  notes?: string;
  academicYear?: string;
  academicTerm?: string;
}) => {
  try {
    // First, get or create student_fees record
    const { data: studentFees, error: feesError } = await supabase
      .from('student_fees')
      .select('id')
      .eq('student_id', studentId)
      .eq('academic_year', paymentData.academicYear || new Date().getFullYear().toString())
      .eq('academic_term', paymentData.academicTerm || 'Term 1')
      .single();

    if (feesError && feesError.code !== 'PGRST116') throw feesError;

    let studentFeeId = studentFees?.id;

    // If no student_fees record exists, the trigger should create one
    // But we'll insert the transaction anyway
    
    const transactionData = {
      student_id: studentId,
      student_fee_id: studentFeeId,
      amount: paymentData.amount,
      payment_method: paymentData.paymentMethod,
      receipt_number: paymentData.receiptNumber,
      notes: paymentData.notes,
      academic_year: paymentData.academicYear || new Date().getFullYear().toString(),
      academic_term: paymentData.academicTerm || 'Term 1',
      created_by: 'admin' // This should ideally be the current user
    };

    const { data, error } = await supabase
      .from('fee_transactions')
      .insert([transactionData])
      .select()
      .single();

    if (error) throw error;

    return data;
  } catch (error) {
    console.error('Error recording payment:', error);
    throw error;
  }
};

// Get student fee summary
export const getStudentFeeSummary = async (studentId: string) => {
  try {
    const { data, error } = await supabase
      .from('student_fees')
      .select(`
        *,
        fee_transactions (
          amount,
          payment_date,
          payment_method,
          receipt_number
        )
      `)
      .eq('student_id', studentId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data;
  } catch (error) {
    console.error('Error fetching student fee summary:', error);
    throw error;
  }
};

// Add this near other export functions
export const fetchClasses = async () => {
  try {
    const { data, error } = await supabase
      .from('class_streams')
      .select('id, full_name, stream_name, class_level')
      .order('class_level', { ascending: true });

    if (error) {
      console.error('Error fetching classes:', error);
      return [];
    }
    return (data || []).map((cls) => ({
      id: cls.id,
      name: [cls.class_level, cls.stream_name].filter(Boolean).join(' ') || cls.full_name || 'Unnamed',
    }));
  } catch (error) {
    console.error('Error fetching classes:', error);
    return [];
  }
};

// Generate next unique student enrollment number (e.g., STU2025001)
export const generateNextStudentEnrollmentNumber = async (): Promise<string> => {
  // Fetch the max existing enrollmentNumber
  const { data, error } = await supabase
    .from('students')
    .select('student_id')
    .order('student_id', { ascending: false })
    .limit(1);

  // Use current year for prefix
  const year = new Date().getFullYear();
  let nextNumber = 1;
  let prefix = `STU${year}`;

  if (data && data.length > 0) {
    const match = data[0].student_id?.match(/^STU(\d{4})(\d+)$/);
    if (match && match[1] === String(year)) {
      nextNumber = parseInt(match[2], 10) + 1;
    } else if (match) {
      // Existing, but older year -- start at 1 for new year
      nextNumber = 1;
    }
  }
  // e.g. STU2025001
  return prefix + String(nextNumber).padStart(3, '0');
};

// Transform functions to map between frontend and database schemas
function transformStudentFromDB(dbStudent: any): Student {
  if (!dbStudent) {
    console.error('Cannot transform null or undefined student from DB');
    throw new Error('Student data is null or undefined');
  }

  console.log('DB Student data received:', dbStudent);
  
  // Calculate fees from payment data or use defaults
  let fees = { 
    paid: 0, 
    due: 0, 
    lastPaymentDate: null 
  };
  
  if (dbStudent.payments && dbStudent.payments.length > 0) {
    const totalPaid = dbStudent.payments.reduce((sum: number, payment: any) => sum + (payment.amount || 0), 0);
    const lastPayment = dbStudent.payments.sort((a: any, b: any) => 
      new Date(b.date || b.created_at).getTime() - new Date(a.date || a.created_at).getTime()
    )[0];
    
    fees = {
      paid: totalPaid,
      due: 0, // This would need to be calculated based on total fees
      lastPaymentDate: lastPayment?.date || lastPayment?.created_at
    };
  }

  return {
    id: dbStudent.id,
    name: dbStudent.full_name || '',
    enrollmentNumber: dbStudent.student_id || '',
    dateOfBirth: dbStudent.date_of_birth || '',
    gender: dbStudent.gender || '',
    classId: dbStudent.class || '',
    className: dbStudent.class || '',
    parentName: dbStudent.parent_name || '',
    parentContact: dbStudent.parent_contact || '',
    address: dbStudent.address || '',
    joinDate: dbStudent.join_date || '',
    fees: fees,
    profileImage: dbStudent.profile_image_url || dbStudent.profile_image || '',
    email: dbStudent.email || '',
    bloodGroup: dbStudent.blood_group || '',
    emergencyContact: dbStudent.emergency_contact || '',
    medicalConditions: dbStudent.medical_conditions || '',
    boardingStatus: dbStudent.boarding_status || 'Day',
    transportUse: dbStudent.transport || 'No',
    bestColor: dbStudent.best_color || '',
    clubsActivities: dbStudent.clubs_activities || [],
    payments: dbStudent.payments?.map(transformPaymentFromDB) || [],
  };
}

function transformStudentToDB(student: Partial<Student>): any {
  if (!student) {
    console.error('Cannot transform null or undefined student to DB');
    throw new Error('Student data is null or undefined');
  }

  console.log('Student data to transform:', student);

  // Create dbStudent object with correct Supabase column names
  const dbStudent: any = {
    // Map frontend property names to database column names
    full_name: student.name,
    student_id: student.enrollmentNumber,
    date_of_birth: student.dateOfBirth,
    gender: student.gender,
    class: student.classId || student.className,
    parent_name: student.parentName,
    parent_contact: student.parentContact,
    address: student.address,
    join_date: student.joinDate,
    profile_image_url: student.profileImage,
    email: student.email,
    blood_group: student.bloodGroup,
    emergency_contact: student.emergencyContact,
    medical_conditions: student.medicalConditions,
    boarding_status: student.boardingStatus,
    transport: student.transportUse,
    best_color: student.bestColor,
    clubs_activities: student.clubsActivities,
    // Set fee_status based on student fees data
    fee_status: student.fees?.due > 0 ? 'Partial' : (student.fees?.paid > 0 ? 'Paid' : 'Unpaid')
  };

  // Remove undefined fields to avoid overwriting with null values
  Object.keys(dbStudent).forEach(key => {
    if (dbStudent[key] === undefined) {
      delete dbStudent[key];
    }
  });
  
  console.log('Final transformed student for DB:', dbStudent);
  return dbStudent;
}

function transformTeacherFromDB(dbTeacher: any): Teacher {
  if (!dbTeacher) {
    console.error('Cannot transform null or undefined teacher from DB');
    throw new Error('Teacher data is null or undefined');
  }

  return {
    id: dbTeacher.id,
    name: dbTeacher.name,
    email: dbTeacher.email,
    phone: dbTeacher.phone,
    subjects: dbTeacher.subjects || [],
    classTeacherFor: dbTeacher.class_teacher_for,
    joinDate: dbTeacher.join_date,
    qualification: dbTeacher.qualification,
    specialization: dbTeacher.specialization,
    biography: dbTeacher.biography,
    gender: dbTeacher.gender,
    dateOfBirth: dbTeacher.date_of_birth,
    employeeId: dbTeacher.employee_id,
    salary: dbTeacher.salary,
    hireDate: dbTeacher.hire_date,
    address: dbTeacher.address,
    emergencyContact: dbTeacher.emergency_contact,
    profileImage: dbTeacher.profile_image_url || dbTeacher.profile_image,
    status: dbTeacher.status || 'active',
  };
}

function transformTeacherToDB(teacher: Partial<Teacher>): any {
  const dbTeacher: any = {};
  
  if (teacher.name !== undefined) dbTeacher.name = teacher.name;
  if (teacher.email !== undefined) dbTeacher.email = teacher.email;
  if (teacher.phone !== undefined) dbTeacher.phone = teacher.phone;
  if (teacher.subjects !== undefined) dbTeacher.subjects = teacher.subjects;
  if (teacher.classTeacherFor !== undefined) dbTeacher.class_teacher_for = teacher.classTeacherFor;
  if (teacher.joinDate !== undefined) dbTeacher.join_date = teacher.joinDate;
  if (teacher.qualification !== undefined) dbTeacher.qualification = teacher.qualification;
  if (teacher.specialization !== undefined) dbTeacher.specialization = teacher.specialization;
  if (teacher.biography !== undefined) dbTeacher.biography = teacher.biography;
  if (teacher.gender !== undefined) dbTeacher.gender = teacher.gender;
  if (teacher.dateOfBirth !== undefined) dbTeacher.date_of_birth = teacher.dateOfBirth;
  if (teacher.employeeId !== undefined) dbTeacher.employee_id = teacher.employeeId;
  if (teacher.salary !== undefined) dbTeacher.salary = teacher.salary;
  if (teacher.hireDate !== undefined) dbTeacher.hire_date = teacher.hireDate;
  if (teacher.address !== undefined) dbTeacher.address = teacher.address;
  if (teacher.emergencyContact !== undefined) dbTeacher.emergency_contact = teacher.emergencyContact;
  if (teacher.profileImage !== undefined) dbTeacher.profile_image_url = teacher.profileImage;
  if (teacher.status !== undefined) dbTeacher.status = teacher.status;
  
  return dbTeacher;
}

function transformPaymentFromDB(dbPayment: any): PaymentRecord {
  return {
    id: dbPayment.id,
    date: dbPayment.date || dbPayment.created_at,
    amount: dbPayment.amount,
    method: dbPayment.method,
    receiptNo: dbPayment.receipt_no || '',
    description: dbPayment.description || dbPayment.notes,
    notes: dbPayment.notes,
    createdAt: dbPayment.created_at,
    createdBy: dbPayment.created_by,
    updatedAt: dbPayment.updated_at,
    updatedBy: dbPayment.updated_by,
  };
}

function transformPaymentToDB(payment: Partial<PaymentRecord>): any {
  const dbPayment: any = {};
  
  if (payment.date !== undefined) dbPayment.date = payment.date;
  if (payment.amount !== undefined) dbPayment.amount = payment.amount;
  if (payment.method !== undefined) dbPayment.method = payment.method;
  if (payment.receiptNo !== undefined) dbPayment.receipt_no = payment.receiptNo;
  if (payment.description !== undefined) dbPayment.notes = payment.description;
  if (payment.notes !== undefined) dbPayment.notes = payment.notes;
  if (payment.createdBy !== undefined) dbPayment.created_by = payment.createdBy;
  if (payment.updatedBy !== undefined) dbPayment.updated_by = payment.updatedBy;
  
  return dbPayment;
}

// Real-time subscriptions - Fixed subscription syntax
export const subscribeToStudents = (callback: (payload: any) => void) => {
  console.log('Setting up subscription to students table');
  return supabase
    .channel('students-changes')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'students' },
      callback
    )
    .subscribe();
};

export const subscribeToTeachers = (callback: (payload: any) => void) => {
  console.log('Setting up subscription to teachers table');
  return supabase
    .channel('teachers-changes')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'teachers' },
      callback
    )
    .subscribe();
};

export const subscribeToPayments = (callback: (payload: any) => void, studentId?: string) => {
  console.log('Setting up subscription to payments table', studentId ? `for student: ${studentId}` : 'for all payments');
  
  let channel = supabase.channel('payments-changes');
  
  if (studentId) {
    channel = channel.on(
      'postgres_changes',
      { 
        event: '*', 
        schema: 'public', 
        table: 'payments',
        filter: `student_id=eq.${studentId}`
      },
      callback
    );
  } else {
    channel = channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'payments' },
      callback
    );
  }
  
  return channel.subscribe();
};
