import React from 'react';
import { HashRouter as Router, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { TooltipProvider } from '@/components/ui/tooltip';

import { AuthProvider } from '@/context/AuthContext';
import { DataSyncProvider } from '@/context/DataSyncContext';
import { SiteSettingsProvider } from '@/context/SiteSettingsContext';

import Index from '@/pages/Index';
import Dashboard from '@/pages/Dashboard';
import Students from '@/pages/Students';
import StudentDetail from '@/pages/StudentDetail';
import StudentEdit from '@/pages/StudentEdit';
import Teachers from '@/pages/Teachers';
import TeacherDetail from '@/pages/TeacherDetail';
import Classes from '@/pages/Classes';
import ClassDetail from '@/pages/ClassDetail';
import Subjects from '@/pages/Subjects';
import SubjectDetail from '@/pages/SubjectDetail';
import Attendance from '@/pages/Attendance';
import Examinations from '@/pages/Examinations';
import Grades from '@/pages/Grades';
import Fees from '@/pages/Fees';
import HRPayroll from '@/pages/HRPayroll';
import Inventory from '@/pages/Inventory';
import Library from '@/pages/Library';
import Transport from '@/pages/Transport';
import Timetable from '@/pages/Timetable';
import Reports from '@/pages/Reports';
import Settings from '@/pages/Settings';
import Authentication from '@/pages/Authentication';
import NotFound from '@/pages/NotFound';
import Messaging from '@/pages/Messaging';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SiteSettingsProvider>
          <DataSyncProvider>
            <AuthProvider>
              <div className="min-h-screen bg-background font-sans antialiased">
                <Router>
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/students" element={<Students />} />
                    <Route path="/students/:id" element={<StudentDetail />} />
                    <Route path="/students/:id/edit" element={<StudentEdit />} />
                    <Route path="/teachers" element={<Teachers />} />
                    <Route path="/teachers/:id" element={<TeacherDetail />} />
                    <Route path="/classes" element={<Classes />} />
                    <Route path="/classes/:id" element={<ClassDetail />} />
                    <Route path="/subjects" element={<Subjects />} />
                    <Route path="/subjects/:id" element={<SubjectDetail />} />
                    <Route path="/attendance" element={<Attendance />} />
                    <Route path="/examinations" element={<Examinations />} />
                    <Route path="/grades" element={<Grades />} />
                    <Route path="/fees" element={<Fees />} />
                    <Route path="/messaging" element={<Messaging />} />
                    <Route path="/hr-payroll" element={<HRPayroll />} />
                    <Route path="/inventory" element={<Inventory />} />
                    <Route path="/library" element={<Library />} />
                    <Route path="/transport" element={<Transport />} />
                    <Route path="/timetable" element={<Timetable />} />
                    <Route path="/reports" element={<Reports />} />
                    <Route path="/settings" element={<Settings />} />
                    <Route path="/auth" element={<Authentication />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </Router>
              </div>
              <Toaster />
            </AuthProvider>
          </DataSyncProvider>
        </SiteSettingsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
